'''
Created on 03.01.2015

@author: axp
'''


from gi.repository import Gtk


class Demo:
    def __init__(self):
        self.window = Gtk.Window()
        self.window.set_default_size(640, 480)
        self.window.connect('delete-event', self.on_app_exit)

        scrolledwindow = Gtk.ScrolledWindow()
        self.window.add(scrolledwindow)

        self.liststore = Gtk.ListStore(str, str, int, str)

        # You need to use self.fillStore() instead.
        self.liststore.append(['Debian', 'i386', 0, 'ok'])
        self.liststore.append(['Fedora', 'amd64', 1, 'ok'])
        self.liststore.append(['Ubuntu', 'i386', 2, 'ok'])

        treeview = Gtk.TreeView(model=self.liststore)
        scrolledwindow.add(treeview)

        names = ('Name', 'URL', 'Bitrate', 'Format')
        for i in range(4):
            renderer_text = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(names[i], renderer_text, text=i)
            treeview.append_column(column)

    def fillStore(self):
        pass

    def run(self):
        self.window.show_all()
        Gtk.main()

    def on_app_exit(self, widget, event=None):
        Gtk.main_quit()


if __name__ == '__main__':
    demo = Demo()
    demo.run()




# from gi.repository import Gtk, Gio
# import gettext
# import locale

# locale.setlocale(locale.LC_ALL, '')
# locale.bindtextdomain('messages', './locale')
# gettext.bindtextdomain('messages', './locale')
# gettext.textdomain('messages')
# _ = gettext.gettext


# class Handler:
#     
#     def _onWindowClosed(self, *args):
#         Gtk.main_quit(*args)
# 
#     def _consumeRoomComboboxChanged(self, combobox):
#         print combobox
#         pass
#     
#     def _cautionRoom1Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom2Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom3Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom4Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom5Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom6Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom7Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom8Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom9Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom10Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom11Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom12Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom13Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom14Changed(self, switch, active):
#         print switch, active
#         pass
#     
#     def _cautionRoom15Changed(self, switch, active):
#         print switch, active
#         pass
# 
# 
# builder = Gtk.Builder()
# builder.add_from_file("assets/ui.glade")
# builder.connect_signals(Handler())
# 
# window = builder.get_object("applicationwindow")
# 
# hb = Gtk.HeaderBar()
# hb.set_show_close_button(True)
# hb.props.title = "HeaderBar example"
# window.set_titlebar(hb)
# 
# button = Gtk.Button()
# icon = Gio.ThemedIcon(name="mail-send-receive-symbolic")
# image = Gtk.Image.new_from_gicon(icon, Gtk.IconSize.BUTTON)
# button.add(image)
# hb.pack_end(button)
#  
# box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
# Gtk.StyleContext.add_class(box.get_style_context(), "linked")
# 
# button = Gtk.Button()
# button.add(Gtk.Arrow(Gtk.ArrowType.LEFT, Gtk.ShadowType.NONE))
# box.add(button)
# 
# button = Gtk.Button()
# button.add(Gtk.Arrow(Gtk.ArrowType.RIGHT, Gtk.ShadowType.NONE))
# box.add(button)
# 
# hb.pack_start(box)
# 
# window.show_all()
# Gtk.main()




# import MySQLdb


# if __name__ == '__main__':
#     db = MySQLdb.connect(host="localhost",
#                          user="",
#                          passwd="")
#     cur = db.cursor()
#     cur.execute ("SELECT VERSION()")
#     row = cur.fetchone ()
#     print "server version:", row[0]
#     cur.close ()
#     db.close ()
#     pass

# from gi.repository import Gtk, Gio
# 
# class HeaderBarWindow(Gtk.Window):
# 
#     def __init__(self):
#         Gtk.Window.__init__(self, title="Stack Demo")
#         self.set_border_width(10)
#         self.set_default_size(400, 200)
# 
#         hb = Gtk.HeaderBar()
#         hb.set_show_close_button(True)
#         hb.props.title = "HeaderBar example"
#         self.set_titlebar(hb)
# 
#         button = Gtk.Button()
#         icon = Gio.ThemedIcon(name="mail-send-receive-symbolic")
#         image = Gtk.Image.new_from_gicon(icon, Gtk.IconSize.BUTTON)
#         button.add(image)
#         hb.pack_end(button)
#         
#         box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
#         Gtk.StyleContext.add_class(box.get_style_context(), "linked")
# 
#         button = Gtk.Button()
#         button.add(Gtk.Arrow(Gtk.ArrowType.LEFT, Gtk.ShadowType.NONE))
#         box.add(button)
# 
#         button = Gtk.Button()
#         button.add(Gtk.Arrow(Gtk.ArrowType.RIGHT, Gtk.ShadowType.NONE))
#         box.add(button)
# 
#         hb.pack_start(box)
#         
#         self.add(Gtk.TextView())
# 
# win = HeaderBarWindow()
# win.connect("delete-event", Gtk.main_quit)
# win.show_all()
# Gtk.main()
