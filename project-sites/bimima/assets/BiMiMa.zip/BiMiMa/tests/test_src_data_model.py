import sys
import unittest

import data
from data.model import Model


sys.path.append(r'../src/')


class TestModel(unittest.TestCase):
    
    
    def setUp(self):
        '''
        Create database connection.
        Use separate file.
        '''
        data.database.DATABASE_FILE = "./testDB.db"
        self.model = Model()
        pass
    
    def tearDown(self):
        self.model.finish()
        pass
    
    def test_finish(self):
        pass

    def test_register_observer(self):
        pass

    def test_notify(self):
        pass

    def test_is_changed(self):
        pass

    def test_check_out(self):
        pass

    def test_clear_all(self):
        self.model.addProduct("test", 1000)
        self.model.clearAll()
        assert self.model.getMarketPriceFor("test") == None

    def test_get_available_cash(self):
        self.model.setAvailableCash(1000)
        print(self.model.getAvailableCash())
        assert self.model.getAvailableCash() == 1000

    def test_set_available_cash(self):
        pass

    def test_get_balance_of(self):
        self.model.setBalanceOf(1, 100)
        assert self.model.getBalanceOf(1) == 100

    def test_set_balance_of(self):
        pass

    def test_compute_credit_sum(self):
        for i in range(15):
            self.model.setBalanceOf(i + 1, 10)
        assert self.model.computeCreditSum() == 150

    def test_compute_credit_of(self):
        pass

    def test_compute_earned_cash(self):
        pass

    def test_compute_caution_sum(self):
        pass

    def test_compute_debt(self):
        pass

    def test_compute_debt_of(self):
        pass

    def test_compute_debt_for(self):
        pass

    def test_compute_future_earnings(self):
        pass

    def test_compute_future_earnings_for(self):
        pass

    def test_add_product(self):
        pass

    def test_remove_product(self):
        pass

    def test_get_product_list(self):
        pass

    def test_compute_pay_price_for(self):
        pass

    def test_get_market_price_for(self):
        pass

    def test_set_market_price_for(self):
        pass

    def test_compute_consume_for(self):
        pass

    def test_get_consume(self):
        pass

    def test_set_consume(self):
        pass

    def test_is_caution_paid_of(self):
        pass

    def test_set_caution_paid_of(self):
        pass

    def test_get_caution_price(self):
        pass

    def test_set_caution_price(self):
        pass

if __name__ == '__main__':
    unittest.main()
