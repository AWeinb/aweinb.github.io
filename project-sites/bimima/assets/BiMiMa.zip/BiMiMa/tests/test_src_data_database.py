import sys
import unittest

import data
from data.database import DatabaseManager


sys.path.append(r'../src/')


class TestDatabaseManager(unittest.TestCase):
    '''
    Tests the database adapter.
    '''
    
    
    def setUp(self):
        '''
        Create database connection.
        Use separate file.
        '''
        self.database_manager = DatabaseManager()
        data.database.DATABASE_FILE = "./testDB.db"
        self.database_manager.connect()
        pass
    
    
    def tearDown(self):
        '''
        Maybe useful to clear the database before the next test.
        Other method is to remove all made entries again.
        '''
        # self.database_manager.dropTables()
        self.database_manager.disconnect()
        pass
    
    
    def test_addProduct(self):
        '''
        '''
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.assertEqual(PRICE, self.database_manager.getProductPrice(NAME))
        if not NAME in self.database_manager.getAllProducts():
            assert False
        self.database_manager.removeProduct(NAME)
        pass


    def test_beginNewConsumeTable(self):
        '''
        '''
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.database_manager.setConsume(1, NAME, 3)
        self.database_manager.beginNewConsumeTable()
        self.assertEqual(0, self.database_manager.getConsume(1, NAME))
        self.database_manager.removeProduct(NAME)
        pass


    def test_getProductPrice(self):
        '''
        Add product and compare price.
        '''
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.assertEqual(PRICE, self.database_manager.getProductPrice(NAME))
        self.database_manager.removeProduct(NAME)
        pass


    def test_getAllProducts(self):
        '''
        Check if all products were added and therefore in the all stuff list.
        '''
        PRODUCTS = [("NAME1", 1), ("NAME2", 2), ("NAME3", 3), ("NAME4", 4)]
        for prod in PRODUCTS:
            self.database_manager.addProduct(prod[0], prod[1])
        self.assertEqual(4, len(self.database_manager.getAllProducts()))
        for i in range(len(PRODUCTS)):
            self.assertEqual(self.database_manager.getAllProducts()[i], PRODUCTS[i][0])
        for prod in PRODUCTS:
            self.database_manager.removeProduct(prod[0])
        pass


    def test_getCautionAmount(self):
        self.database_manager.setCautionAmount(111)
        self.assertEqual(111, self.database_manager.getCautionAmount())
        pass

    def test_getCautionPaid(self):
        self.database_manager.setCautionAmount(111)
        self.assertEqual(111, self.database_manager.getCautionAmount())
        pass

    def test_getConsume(self):
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.database_manager.setConsume(1, NAME, 11)
        self.assertEqual(11, self.database_manager.getConsume(1, NAME))
        self.database_manager.removeProduct(NAME)
        pass

    def test_getCredit(self):
        CREDIT = 100
        self.database_manager.setCredit(CREDIT)
        self.assertEqual(CREDIT, self.database_manager.getCredit())
        pass

    def test_getCreditOf(self):
        CREDIT = 100
        self.database_manager.setCreditOf(1, CREDIT)
        self.assertEqual(CREDIT, self.database_manager.getCreditOf(1))
        pass

    def test_hasUncommitedChanges(self):
        # TODO:
        pass

    def test_removeProduct(self):
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.database_manager.removeProduct(NAME)
        self.assertEqual(None, self.database_manager.getConsume(1, NAME))
        self.assertEqual(None, self.database_manager.getProductPrice(NAME))
        pass

    def test_setProductPrice(self):
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.database_manager.setProductPrice(NAME, 130)
        self.assertEqual(130, self.database_manager.getProductPrice(NAME))
        self.database_manager.removeProduct(NAME)
        pass

    def test_setCautionAmount(self):
        AMOUNT = 111
        self.database_manager.setCautionAmount(AMOUNT)
        self.assertEqual(AMOUNT, self.database_manager.getCautionAmount())
        pass

    def test_setCautionPaid(self):
        self.database_manager.setCautionPaid(1, True)
        self.assertEqual(True, self.database_manager.getCautionPaid(1))
        self.database_manager.setCautionPaid(10, False)
        self.assertEqual(False, self.database_manager.getCautionPaid(10))
        pass

    def test_setConsume(self):
        NAME = "NAME"
        PRICE = 111
        self.database_manager.addProduct(NAME, PRICE)
        self.database_manager.setConsume(1, NAME, 10)
        self.assertEqual(10, self.database_manager.getConsume(1, NAME))
        self.database_manager.removeProduct(NAME)
        pass

    def test_setCredit(self):
        CREDIT = 100
        self.database_manager.setCredit(CREDIT)
        self.assertEqual(CREDIT, self.database_manager.getCredit())
        pass

    def test_setCreditOf(self):
        CREDIT = 100
        self.database_manager.setCreditOf(1, CREDIT)
        self.assertEqual(CREDIT, self.database_manager.getCreditOf(1))
        pass

if __name__ == '__main__':
    unittest.main()
