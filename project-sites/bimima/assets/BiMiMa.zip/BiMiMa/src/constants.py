'''
Created on 07.01.2015

@author: axp
'''


DATABASE_FILE = '../data.db'
DATABASE_DUMP_DIR = '../history/dumps/'
DATABASE_PDF_DIR = '../history/pdfs/'
TBL_PRICES = 'PricesTbl'
TBL_CURRENTCONSUME = 'ConsumeTbl'
TBL_CAUTIONS = 'CautionsTbl'
TBL_CREDITS = 'CreditTbl'
TBL_MISC = 'MiscTbl'

NUM_ROOMS = 15

GUI_GLADE_FILE = "../assets/ui.glade"
GUI_TITLE = "BiMiMa"

CONFIG = "../config/config.conf"

PRODUCTS_ONLINE_PRICES = 'https://voodoomail.de/bimik4/bimik4.php?what=drink'
PRODUCTS_ONLINE_CAUTIONS = 'https://voodoomail.de/bimik4/bimik4.php?what=box'
