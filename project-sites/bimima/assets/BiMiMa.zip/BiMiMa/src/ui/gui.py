'''
Created on 06.01.2015

@author: axp
'''
import ast
import datetime
import os
import threading

from gi.repository import Gtk, Gio

import constants
from util.pdf import PDFCreator
from util.web import ProductsInfo


DATABASE_PDF_DIR = constants.DATABASE_PDF_DIR
GUI_GLADE_FILE = constants.GUI_GLADE_FILE
GUI_TITLE = constants.GUI_TITLE
NUM_ROOMS = constants.NUM_ROOMS


def _centToEuro(amount):
    return amount / 100.0
    pass
    
def _euroToCent(amount):
    return amount * 100
    pass

def _checkProductName(name):
    '''
    This function checks the inserted product name in the addProduct Dialog.
    '''
    return len(name) >= 5
    pass

"""
===================================================================================================
"""

class GUISignalHandler:
    '''
    This class is given to the gtk builder and provides some button callbacks. The names were
    provided in the glade file.
    '''
    
    def __init__(self, gui):
        # Actual work is done in the gui class.
        self._gui = gui
        pass
    
    def _pageChanged(self, notebook, widget, pageNumber):
        '''
        Callback which is triggered when the main notebook page is changed.
        '''
        self._gui._setShownPage(pageNumber)
        self._gui.update(True)
        pass
    
    def _onWindowClosed(self, *args):
        self._gui.quit(*args)
        pass


"""
===================================================================================================
"""
    
class GUI(object):
    '''
    This class connects the gui elements to the backparts of the program. Every button and dialog
    is connected in this class. Changes are send to the model and become visible after an update of
    the gui. When the ui is closed everything is cleaned up except for the provided model.
    '''
    # The gui is build with gtkBuilder and a glade file. The different pages of the main notebook 
    # are distributed over some classes to keep the code simpler.

    def __init__(self, model):
        '''
        The model takes the changes which are made in the gui. Changes should trigger an update of
        the gui.
        '''
        self._model = model
        # Var to store the current notebook page.
        self._currentPageNumber = 0
        
        # The handler provides some predefined methods for the gui.
        self._handler = GUISignalHandler(self)
        
        # The builder builds the gui from a glade file.
        builder = Gtk.Builder()
        builder.add_from_file(GUI_GLADE_FILE)
        builder.connect_signals(self._handler)
        
        self._window = builder.get_object('applicationWindow')
        self._notebook = builder.get_object('appWinNotebook')
        
        # The menubar is added here for better control. It provides some common control elements
        # or some for the page important controls.
        self._menubar = MenuBar(model, GUI_TITLE, builder)
        self._window.set_titlebar(self._menubar.getWidget())
        
        self._notebookPages = []
        self._notebookPages.append(NotebookPageOne(self._menubar, model, builder))
        self._notebookPages.append(NotebookPageTwo(self._menubar, model, builder))
        self._notebookPages.append(NotebookPageThree(self._menubar, model, builder))
        self._notebookPages.append(NotebookPageFour(self._menubar, model, builder))
        self._notebookPages.append(NotebookPageFive(self._menubar, model, builder))
        
        self.update(True)
        pass
    
    def show(self):
        '''
        Starts the main loop of gtk.
        '''
        self._window.show_all()
        Gtk.main()
        pass
    
    def quit(self, *args):
        '''
        Ends the loop and clears everything.
        '''
        Gtk.main_quit(*args)
        
        for page in self._notebookPages:
            page.destroy()
        self._notebookPages.clear()
        self._menubar.destroy()
        self._window.destroy()
        
        self._window = None
        self._menubar = None
        pass
    
    def update(self, complete=False):
        '''
        Updates the current visible page of the ui. A complete update rebuilds everything while
        the soft update only changes texts or such.
        '''
        for page in self._notebookPages:
            if page.getPageNumber() == self._currentPageNumber:
                page.update(complete)
        
        # Some menubars provide an subtitle field.
        subtitle = self._notebook.get_tab_label(self._notebook.get_nth_page(self._currentPageNumber)).get_text()
        self._menubar.setSubTitle(subtitle)
        self._menubar.showAll()
        pass
    
    def _setShownPage(self, pageNumber):
        '''
        Sets the pagenumber of the current notebook page. This method is used intern.
        '''
        self._currentPageNumber = pageNumber
        pass
    
"""
===================================================================================================
"""

class MenuBar(object):
    '''
    This class creates the menubar which is used in the gui. It is updateable by the different
    notebook pages to fit to the page. 
    '''
    
    def __init__(self, model, title, builder):
        self._model = model
        
        # Used to create pdf files of the tables.
        self._pdfCreator = PDFCreator()
        
        # At the moment there is only the headerbar implemented. With the Gnome DE it is working
        # very well but other environments may have problems with it.
        self._headerbar = Gtk.HeaderBar()
        self._headerbar.set_title(title)
        self._headerbar.set_show_close_button(True)
        
        # The menubutton, which stays on the bar for all pages, is defined in the glade file.
        self._headerbarMenuBtn = builder.get_object('applicationMenuButton')
        self._headerbarPopover = Gtk.Popover()
        appPopoverMenu = builder.get_object('applicationMenuBox')
        appPopoverMenu.show_all()
        self._headerbarPopover.add(appPopoverMenu)
        self._headerbarPopover.set_relative_to(self._headerbarMenuBtn)
        self._headerbarMenuBtn.set_popover(self._headerbarPopover)
        self._headerbar.pack_end(self._headerbarMenuBtn)
        
        # All dialogs are stored for later use. Important is to not destroy them.
        self._filechooserDialog = builder.get_object('filechooserDialog')
        self._filechooserDialog.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
        self._filechooserDialog.add_button(Gtk.STOCK_SAVE, Gtk.ResponseType.ACCEPT)
        self._checkOutDialog = builder.get_object('checkOutDialog')
        self._clearAllDialog = builder.get_object('clearAllDialog')
        self._aboutDialog = builder.get_object('aboutDialog')
        
        # The menubuttons are connected to the callbacks.
        exportPdfBtn = builder.get_object('appMenuExportPdfBtn')
        exportPdfBtn.connect('clicked', self._handleExportOverviewPdf)
        exportChecklistPdfBtn = builder.get_object('appMenuExportChecklistBtn')
        exportChecklistPdfBtn.connect('clicked', self._handleExportChecklistPdf)
        checkOutBtn = builder.get_object('appMenuCheckOutBtn')
        checkOutBtn.connect('clicked', self._handleCheckOut)
        clearAllBtn = builder.get_object('appMenuClearAllBtn')
        clearAllBtn.connect('clicked', self._handleClearAll)
        aboutBtn = builder.get_object('appMenuAboutBtn')
        f = lambda b: (
            self._headerbarMenuBtn.set_active(False),
            self._aboutDialog.run(),
            self._aboutDialog.hide()
        )
        aboutBtn.connect('clicked', f)
        pass
    
    def getWidget(self):
        '''
        Returns the menubar gtk widget which can be added as menubar.
        '''
        return self._headerbar
        pass
    
    def showAll(self):
        '''
        Function that calls show_all on the widget.
        '''
        self._headerbar.show_all()
        pass
    
    def reset(self):
        '''
        Removes every added button from the bar except for the menubutton. The removed elements
        are destroyed.
        '''
        # Clean up the bar. Remove all children and destroy them. Except for the menu button.
        for child in self._headerbar.get_children():
            if not child == self._headerbarMenuBtn:
                self._headerbar.remove(child)
                child.destroy()
        pass
    
    def setSubTitle(self, subtitle):
        '''
        Sets the subtitle for the menubar. The headerbar has the possibility to show it.
        '''
        self._headerbar.set_subtitle(subtitle)
        pass
    
    def addElement(self, element, packtype):
        '''
        Adds an ui element to the bar.
        '''
        if packtype == Gtk.PackType.START:
            self._headerbar.pack_start(element)
        elif packtype == Gtk.PackType.END:
            self._headerbar.pack_end(element)
        pass
    
    def addButton(self, imageName, function, packtype):
        '''
        This function creates the button and connects it before it is added.
        '''
        button = Gtk.Button()
        image = Gtk.Image.new_from_gicon(Gio.ThemedIcon(name=imageName), Gtk.IconSize.BUTTON)
        button.add(image)
        button.connect('clicked', function)
        self.addElement(button, packtype)
        pass
    
    def destroy(self):
        '''
        Function to destroy all created instances.
        '''
        pass
    
    def _handleExportOverviewPdf(self, btn):
        '''
        This function handles the process of creating a pdf file with the overview data.
        '''
        # Close the menu.
        self._headerbarMenuBtn.set_active(False)
        
        # Run the filechooser and check the return signal.
        if self._filechooserDialog.run() == Gtk.ResponseType.ACCEPT:
            path = self._filechooserDialog.get_filename()
            # Its not needed to end the filename with pdf. So it is added here if needed.
            if not path.endswith('.pdf'):
                path += '.pdf'
            # Use the date as a simple heading.
            date = str(datetime.datetime.now().date())
            # This creates a list of list. (Java 2D array)
            data = self._computeOverviewPDFData()
            self._pdfCreator.writeTable(date, 100, data, path)
            
        # Needs to be hidden again. No destroy.
        self._filechooserDialog.hide()
        pass
    
    def _handleExportChecklistPdf(self, btn):
        '''
        Handles the pdf file creation of the checklist template. That is a page with an empty
        table.
        '''
        # Close the menu.
        self._headerbarMenuBtn.set_active(False)
        
        # Run the chooser and receive the path.
        if self._filechooserDialog.run() == Gtk.ResponseType.ACCEPT:
            path = self._filechooserDialog.get_filename()
            # Add pdf if needed.
            if not path.endswith('.pdf'):
                path += '.pdf'
            # Get the data as 2D array or list of lists.
            data = self._computeCheckListPDFData()
            self._pdfCreator.writeTable("", 30, data, path)
        
        # No destroy, just hide.
        self._filechooserDialog.hide()
        pass
    
    def _handleCheckOut(self, btn):
        '''
        This method handles the checkout. This is probably the moment where new stuff was bought and
        the money needs to be paid. This here creates the overview pdf with what is to pay and
        sets up new tables and so on. 
        '''
        self._headerbarMenuBtn.set_active(False)
        
        if self._checkOutDialog.run() == Gtk.ResponseType.YES:
            # If the user has confirmed create the pdf.
            date = str(datetime.datetime.now().date())
            data = self._computeOverviewPDFData()
            if not os.path.exists(DATABASE_PDF_DIR):
                os.makedirs(DATABASE_PDF_DIR)
            path = DATABASE_PDF_DIR + str(date) + '.pdf'
            self._pdfCreator.writeTable(date, 100, data, path)
            # And tell the model to do what is needed.
            self._model.checkOut()
            
        self._checkOutDialog.hide()
        pass
    
    def _handleClearAll(self, btn):
        '''
        This method wipes everything.
        '''
        self._headerbarMenuBtn.set_active(False)
        
        if self._clearAllDialog.run() == Gtk.ResponseType.YES:
            self._model.clearAll()
            
        self._clearAllDialog.hide()
        pass
    
    def _computeOverviewPDFData(self):
        '''
        Computes a list of list with data which can then be used to fill a table. Most of it is
        hardcoded. Modify the method to add information to the pdf. You may need to modify the
        pdf creator too.
        '''
        data = []
        # First line are the rooms.
        tmp = ['', '']
        for i in range(NUM_ROOMS):
            tmp.append(i + 1)
        data.append(tmp)
        
        # After that the block with all products.
        for prod in self._model.getProductList():
            tmp = [prod, '{0} \u20AC'.format(_centToEuro(self._model.computePayPriceFor(prod)))]
            for room in range(1, NUM_ROOMS + 1):
                tmp.append(self._model.getConsume(room, prod))
            data.append(tmp)
        
        # Blank line
        tmp = [''] * (NUM_ROOMS + 1 + 1)
        data.append(tmp)
        
        # To pay line
        tmp = ['Zu Bezahlen', '']
        for i in range(NUM_ROOMS):
            tmp.append(u'{0} \u20AC'.format(_centToEuro(self._model.computeDebtOf(i + 1))))
        data.append(tmp)
        
        # Caution paid line
        tmp = ['Kaution?', '']
        for i in range(NUM_ROOMS):
            tmp.append(self._model.isCautionPaidOf(i + 1) and u'\u2714' or u'\u2716')
        data.append(tmp)
        
        # credit line
        tmp = ['Restguthaben', '']
        for i in range(NUM_ROOMS):
            tmp.append(u'{0} \u20AC'.format(_centToEuro(self._model.computeCreditOf(i + 1))))
        data.append(tmp)
        
        return data
        pass
    
    def _computeCheckListPDFData(self):
        '''
        Creates a simple table with the rooms and the products at the borders. Returns a list of
        lists.
        '''
        data = []
        
        # Product and price build the two first lines.
        tmp = ['']
        tmp2 = ['']
        for prod in self._model.getProductList():
            tmp.append(prod)
            tmp2.append(u'{0} \u20AC'.format(_centToEuro(self._model.computePayPriceFor(prod))))
        data.append(tmp)
        data.append(tmp2)
        
        # After that come the rooms as lines.
        for i in range(NUM_ROOMS):
            tmp = [str(i + 1)]
            tmp.extend([''] * len(self._model.getProductList()))
            data.append(tmp)
        
        return data
        pass
    
"""
===================================================================================================
"""

class NotebookPageBase(object):
    '''
    This class is the base class of the notebook page classes. It defines the basic structure.
    '''
    
    def __init__(self, model):
        self._model = model
        # Each page has a unique id which corresponds with the notebook page index.
        self._notebookPage = -1
        pass
    
    def getPageNumber(self):
        '''
        Returns the page number which can be used as page index.
        '''
        return self._notebookPage
        pass
    
    def update(self, complete=False):
        '''
        Updates the elements of the page.
        '''
        pass
    
    def destroy(self):
        '''
        Destroys the created instances.
        '''
        pass

"""
===================================================================================================
"""

class NotebookPageOne(NotebookPageBase):
    '''
    '''
    
    def __init__(self, menubar, model, builder):
        '''
        The menubar is used to display context dependent buttons. The model is used to change data.
        The builder is needed to get the page elements.
        '''
        super(NotebookPageOne, self).__init__(model)
        self._menubar = menubar
        self._notebookPage = 0
        
        # Store the first block of textfields.
        self._overview1Cash = builder.get_object('appWinOverviewAInfoCashText')
        self._overview1Credits = builder.get_object('appWinOverviewAInfoCreditText')
        self._overview1Earnings = builder.get_object('appWinOverviewAInfoEarningsText')
        self._overview1Cautions = builder.get_object('appWinOverviewAInfoCautionsText')
        self._overview1Debt = builder.get_object('appWinOverviewAInfoDebtText')
        self._overview1PossblEarnings = builder.get_object('appWinOverviewAInfoPsbEarningsText')
        
        # The balance fields have similar ids.
        self._overview1Balances = []
        for i in range(NUM_ROOMS):
            self._overview1Balances.append(builder.get_object('appWinOverviewA_rO_{0}'.format(i + 1)))
        
        # The viewport is on the second page of the sub notebook. It displays a table with data.
        self._overview2Viewport = builder.get_object('appWinOverviewBViewport')
        self._overview2Liststore = Gtk.ListStore()
        
        # Creates the table structure and models.
        names = ['Produkt', 'Kaufpreis', 'Marktpreis', 'Kosten', 'Gewinn', 'Verbrauch']
        colTypes = [str, str, str, str, str, int]
        # Create the renderer for the above data.
        columns = []
        modelCol = 0
        for name in names:
            renderer_text = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(name, renderer_text, text=modelCol)
            column.set_sort_column_id(modelCol)
            column.set_min_width(70)
            column.set_resizable(True)
            columns.append(column)
            modelCol += 1
        
        # Create renderer for the rooms. They display the consume.
        for i in range(NUM_ROOMS):
            name = str(i + 1)
            renderer_text = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(name, renderer_text, text=modelCol)
            column.set_sort_column_id(modelCol)
            column.set_min_width(25)
            column.set_resizable(True)
            # Its important to append the correct type.
            colTypes.append(int)
            columns.append(column)
            modelCol += 1
        
        # Create a treeview that displays the data.
        self._overview2Liststore.set_column_types(colTypes)
        treeview = Gtk.TreeView(model=self._overview2Liststore)
        treeview.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
        for col in columns:
            # Add all columns.
            treeview.append_column(col)
        self._overview2Viewport.add(treeview)
        
        self._k4ProductsInfoLabel = builder.get_object('appWinOverviewCK4ProductsLabel')
        info = ProductsInfo()
        try:
            thread = threading.Thread(target=self._formatInfo, args=(self._k4ProductsInfoLabel, info))
            thread.start()
        except Exception as e:
            print(e)
            pass
        pass
    
    def _formatInfo(self, label, info):
        # Input is a string of a list of dicts. Remove the [{}] and split with },{.
        productsStr = info.getK4Products()[2:-3]
        cautionsStr = info.getK4ProductCautions()[2:-3]
        productsStr = productsStr.split(sep='},{')
        cautionsStr = cautionsStr.split(sep='},{')
        # Get the dicts. {} need to be added before.
        products = []
        for s in productsStr:
            products.append(ast.literal_eval('{' + s + '}'))
        cautions = {}
        for s in cautionsStr:
            tmp = ast.literal_eval('{' + s + '}')
            _id = tmp['ID']
            cautions[_id] = (tmp['Name'], tmp['Pfand'])
        # Sort the list by product name.
        products = sorted(products, key=lambda k: k['name'])
        # Format a string to display.
        formattedStr = u""
        for i, e in enumerate(products):
            sep = '   -   '
            name = e['name'].replace('\/', '\\')
            price = _centToEuro(int(e['Preis']))
            cautionInfo = '[{0}, {1} \u20AC]'.format(cautions[e['kasten']][0], _centToEuro(int(cautions[e['kasten']][1])))
            formattedStr += u'{1}: {2} {0} {3} \u20AC {0} {4}\n'.format(sep, i, name, price, cautionInfo)
            
        label.set_text(formattedStr)
        pass
    
    def update(self, complete=False):
        '''
        Updates the page. In this case the complete argument would be useless.
        '''
        # Delete all buttons from the bar.
        self._menubar.reset()
        # Page 1 A
        # Update the first block of textfields. Because the amounts are stored in cents they need
        # to be transformed.
        präfix = _centToEuro(self._model.getAvailableCash()) >= 0 and '+' or ''
        self._overview1Cash.set_text(u'{0}{1} \u20AC'.format(präfix, _centToEuro(self._model.getAvailableCash())))
        präfix = _centToEuro(self._model.computeCreditSum()) >= 0 and '+' or ''
        self._overview1Credits.set_text(u'{0}{1} \u20AC'.format(präfix, _centToEuro(self._model.computeCreditSum())))
        präfix = _centToEuro(self._model.computeCautionSum()) >= 0 and '+' or ''
        self._overview1Cautions.set_text(u'{0}{1} \u20AC'.format(präfix, _centToEuro(self._model.computeCautionSum())))
        präfix = _centToEuro(self._model.computeEarnedCash()) >= 0 and '+' or ''
        self._overview1Earnings.set_text(u'{0}{1} \u20AC'.format(präfix, _centToEuro(self._model.computeEarnedCash())))
        präfix = _centToEuro(self._model.computeDebt()) >= 0 and '+' or ''
        self._overview1Debt.set_text(u'{0}{1} \u20AC'.format(präfix, _centToEuro(self._model.computeDebt())))
        präfix = _centToEuro(self._model.computeFutureEarnings()) >= 0 and '+' or ''
        self._overview1PossblEarnings.set_text(u'{0}{1} \u20AC'.format(präfix, round(_centToEuro(self._model.computeFutureEarnings()), 2)))
        
        # Update the room costs.
        for i in range(NUM_ROOMS):
            roomStr = str(i + 1)
            if i + 1 < 10:
                roomStr = '0' + str(i + 1)
            self._overview1Balances[i].set_text(u'{0} {1}:    {2} \u20AC'
                                .format('Zimmer', roomStr, _centToEuro(self._model.computeDebtOf(i + 1))))
            
        # Page 1 B
        # Fills the model of the table with fresh data.
        self._overview2Liststore.clear()
        for prod in self._model.getProductList():
            # Product Name
            values = [prod]
            # PayPrice
            values.append(str(round(_centToEuro(self._model.computePayPriceFor(prod)), 2)) + ' \u20AC')
            # Price
            values.append(str(round(_centToEuro(self._model.getMarketPriceFor(prod)), 2)) + ' \u20AC')
            # Costs
            values.append(str(round(_centToEuro(self._model.computeDebtFor(prod)), 2)) + ' \u20AC')
            # Earnings
            values.append(str(round(_centToEuro(self._model.computeFutureEarningsFor(prod)), 2)) + ' \u20AC')
            # Complete Consume
            values.append(self._model.computeConsumeFor(prod))
            # Rooms
            for i in range(NUM_ROOMS):
                values.append(self._model.getConsume(i + 1, prod))
            self._overview2Liststore.append(values)
        pass    

"""
===================================================================================================
"""

class NotebookPageTwo(NotebookPageBase):
    '''
    '''
    
    def __init__(self, menubar, model, builder):
        '''
        The menubar is used to display context dependent buttons. The model is used to change data.
        The builder is needed to get the page elements.
        '''
        super(NotebookPageTwo, self).__init__(model)
        self._menubar = menubar
        self._notebookPage = 1
        
        # The listbox contains the products and elements to set the consume.
        self._consumeListbox = builder.get_object('appWinConsumeListbox')
        # Thist list stores the spinbuttons.
        self._consumeListboxStore = []
        # The combobox is used to change the room.
        self._consumeComboboxtext = builder.get_object('appWinConsumeComboboxtext')
        self._consumeListboxSelectedRoom = 1
        f = lambda b: (
            self.setSelectedRoom(b.get_active() + 1),
            self.update()
        )
        self._consumeComboboxtext.connect('changed', f)
        # Sets the consume of the room to zero.
        self._consumeResetPageBtn = builder.get_object('appWinConsumeReset')
        f = lambda b: (
            # The list creation calls the functions.
            list(map(lambda prod: self._model.setConsume(self._consumeListboxSelectedRoom, prod, 0), self._model.getProductList())),
        )
        self._consumeResetPageBtn.connect('clicked', f)
        pass
    
    def setSelectedRoom(self, room):
        '''
        Sets the selected room. The room is an Integer from 1 to x.
        '''
        self._consumeListboxSelectedRoom = room
        pass
    
    def update(self, complete=False):
        '''
        Updates the page. A complete rebuild recreates the product entries of the listbox. A simple
        update just changes the entries.
        '''
        # Remove the buttons from the bar.
        self._menubar.reset()
        # And add a button that clears the consume of every room.
        f = lambda b: (
            [self._model.setConsume(room, product, 0) for room in range(1, NUM_ROOMS + 1) for product in self._model.getProductList()]
        )
        self._menubar.addButton('edit-clear-all-symbolic', f, Gtk.PackType.END)
        self._menubar.showAll()
        
        if complete:
            # Delete all elements.
            self._consumeListboxStore.clear()
            for child in self._consumeListbox.get_children():
                self._consumeListbox.remove(child)
                child.destroy()
            
            # For each product create a line.
            products = self._model.getProductList()
            for prod in products:
                box = Gtk.Box()
                box.set_spacing(5)
                box.set_margin_top(10)
                box.set_margin_bottom(10)
                box.set_margin_left(10)
                box.set_margin_right(10)
                box.set_homogeneous(True)
                
                # Product name
                box.add(Gtk.Label(str(prod)))
                
                # Spinbutton to set the consume.
                adj = Gtk.Adjustment(0, 0.0, 100.0, 1.0, 5.0, 0.0)
                btn = Gtk.SpinButton()
                btn.set_adjustment(adj)
                btn.set_digits(0)
                btn.set_vexpand(False)
                btn.set_valign(Gtk.Align.CENTER)
                consume = self._model.getConsume(self._consumeListboxSelectedRoom, prod)
                btn.set_value(consume)
                # The buttons stores some associated infos.
                btn._product = prod
                f = lambda spin: (
                    self._model.setConsume(self._consumeListboxSelectedRoom, spin._product, spin.get_value()),
                )
                btn.connect('value-changed', f)
                box.add(btn)
                
                # Label to show the costs.
                sumLabel = Gtk.Label(str(_centToEuro(self._model.computePayPriceFor(prod) * consume)))
                box.add(sumLabel)
                btn._resLabel = sumLabel
                
                self._consumeListbox.add(box)
                self._consumeListboxStore.append(btn)
            
            self._consumeListbox.show_all()
        else:
            # Reset the text of the elements.
            for btn in self._consumeListboxStore:
                prod = btn._product
                consume = self._model.getConsume(self._consumeListboxSelectedRoom, prod)
                sumLabel = str(_centToEuro(self._model.computePayPriceFor(prod) * consume))
                btn.set_value(consume)
                btn._resLabel.set_text(sumLabel)
        pass    

"""
===================================================================================================
"""

class NotebookPageThree(NotebookPageBase):
    
    def __init__(self, menubar, model, builder):
        '''
        The menubar is used to display context dependent buttons. The model is used to change data.
        The builder is needed to get the page elements.
        '''
        super(NotebookPageThree, self).__init__(model)
        self._notebookPage = 2
        self._menubar = menubar
        
        # Listbox with name and price.
        self._productsListbox = builder.get_object('appWinProductsListbox')
        self._productsListboxStore = []
        
        # The dialog is used to ask the user for a new product name.
        self._addProductDialog = builder.get_object('addProductDialog')
        self._addProductDialog.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
        self._addProductDialog.add_button(Gtk.STOCK_ADD, Gtk.ResponseType.ACCEPT)
        self._addProductDialog._productEntry = builder.get_object('aPDialogFieldsEntry')
        self._addProductDialog._productSpin = builder.get_object('aPDialogFieldsSpin')
        self._addProductDialog._warning = builder.get_object('aPDialogDescriptionWarningRevealer')
        adj = Gtk.Adjustment(0.0, 0.0, 250.0, 0.1, 10.0, 0.0)
        self._addProductDialog._productSpin.set_adjustment(adj)
        
        # This dialog is used to confirm a deletion.
        self._removeProductDialog = builder.get_object('deleteProductDialog')
        pass
    
    def update(self, complete=False):
        '''
        Updates the page. If complete everything is removed and rebuild. If not only the texts are
        changed.
        '''
        self._menubar.reset()
        # Add the addProduct button to the menubar.
        self._menubar.addButton('list-add-symbolic', self._handleAddProduct, Gtk.PackType.END)
        self._menubar.showAll()
        
        if complete:
            # Remove everything.
            self._productsListboxStore.clear()
            for child in self._productsListbox.get_children():
                self._productsListbox.remove(child)
                child.destroy()
            
            # Create a line for each product.
            products = self._model.getProductList()
            for prod in products:
                box = Gtk.Box()
                box.set_spacing(5)
                box.set_margin_top(10)
                box.set_margin_bottom(10)
                box.set_margin_left(10)
                box.set_margin_right(10)
                box.set_homogeneous(True)
                
                # Name label
                box.add(Gtk.Label(str(prod)))
                price = round(_centToEuro(self._model.getMarketPriceFor(prod)), 4)
                box.add(Gtk.Label(str(price) + ' \u20AC'))
                sellingPrice = _centToEuro(self._model.computePayPriceFor(prod))
                box.add(Gtk.Label(str(sellingPrice) + ' \u20AC'))
                earning = round(sellingPrice - price, 4)
                box.add(Gtk.Label(str(earning) + ' \u20AC'))
                
                # Delete button.
                deleteBtn = Gtk.Button()
                image = Gtk.Image.new_from_gicon(Gio.ThemedIcon(name='edit-delete-symbolic'), Gtk.IconSize.BUTTON)
                deleteBtn.add(image)
                deleteBtn.set_halign(Gtk.Align.CENTER)
                deleteBtn.set_hexpand(False)
                deleteBtn.set_relief(Gtk.ReliefStyle.NONE)
                deleteBtn._product = prod
                deleteBtn.connect('clicked', self._handleDeleteProduct)
                box.add(deleteBtn)
                
                self._productsListbox.add(box)
                
            self._productsListbox.show_all()
        pass
    
    
    def _handleAddProduct(self, btn):
        '''
        Shows the dialog and reads a new product name and price. If all is ok the product is added.
        If not a hint is shown.
        '''
        res = self._addProductDialog.run()
        if res == Gtk.ResponseType.ACCEPT:
            name = self._addProductDialog._productEntry.get_text()
            price = round(_euroToCent(self._addProductDialog._productSpin.get_value()), 2)
            if not _checkProductName(name):
                self._addProductDialog._warning.set_reveal_child(True)
                self._handleAddProduct(btn)
                return
            else:
                self._model.addProduct(name, price)
                self.update(True)
        
        # Reset the dialog.
        self._addProductDialog._productEntry.set_text(''),
        self._addProductDialog._productSpin.set_value(0),
        self._addProductDialog._warning.set_reveal_child(False)
        self._addProductDialog.hide()
        pass
    
    def _handleDeleteProduct(self, btn):
        '''
        Shows a dialog to confirm that the selected product should be deleted. If yes it is deleted
        and the page is updated.
        '''
        if self._removeProductDialog.run() == Gtk.ResponseType.OK:
            self._model.removeProduct(btn._product)
        self._removeProductDialog.hide()
        self.update(True)
        pass

"""
===================================================================================================
"""

class NotebookPageFour(NotebookPageBase):
    
    def __init__(self, menubar, model, builder):
        '''
        The menubar is used to display context dependent buttons. The model is used to change data.
        The builder is needed to get the page elements.
        '''
        super(NotebookPageFour, self).__init__(model)
        self._notebookPage = 3
        self._menubar = menubar
        
        # Collect all switches and set the callback.
        self._cautionSwitches = []
        for i in range(NUM_ROOMS):
            self._cautionSwitches.append(builder.get_object('appWinCautionGridSwitch{0}'.format(i + 1)))
            self._cautionSwitches[i]._connectedRoom = i + 1
            
            f = lambda btn, data: self._model.setCautionPaidOf(btn._connectedRoom, btn.get_active())
            self._cautionSwitches[i].connect('notify::active', f)
        
        # Set up the spin that sets the amount.
        self._cautionSetSpin = builder.get_object('appWinCautionAmountSpin')
        adj = Gtk.Adjustment(0.0, 0.0, 250.0, 0.1, 10.0, 0.0)
        self._cautionSetSpin.set_adjustment(adj)
        f = lambda b: (
            self._model.setCautionPrice(round(_euroToCent(b.get_value()), 2))
        )
        self._cautionSetSpin.connect('value-changed', f)
        pass
    
    def update(self, complete=False):
        '''
        Update the page. If complete the switches are reset.
        '''
        self._menubar.reset()
        # Add a button that clears all switches.
        f = lambda clearBtn: (
            list(map(lambda i: self._model.setCautionPaidOf(i + 1, False), range(NUM_ROOMS))),
            self.update(True)
        )
        self._menubar.addButton('edit-clear-all-symbolic', f, Gtk.PackType.END)
        self._menubar.showAll()
        
        if complete:
            for switch in self._cautionSwitches:
                switch.set_state(self._model.isCautionPaidOf(switch._connectedRoom))
        
        # The spin can be updated each run.
        self._cautionSetSpin.set_value(_centToEuro(self._model.getCautionPrice()))
        pass

"""
===================================================================================================
"""

class NotebookPageFive(NotebookPageBase):
    
    def __init__(self, menubar, model, builder):
        '''
        The menubar is used to display context dependent buttons. The model is used to change data.
        The builder is needed to get the page elements.
        '''
        super(NotebookPageFive, self).__init__(model)
        self._notebookPage = 4
        self._menubar = menubar
        
        # Collect the spin buttons and set the callback.
        self._creditSpins = []
        for i in range(NUM_ROOMS):
            self._creditSpins.append(builder.get_object('appWinCreditsGridSpin{0}'.format(i + 1)))
            adj = Gtk.Adjustment(0.0, -250.0, 250.0, 0.1, 10.0, 0.0)
            self._creditSpins[i].set_adjustment(adj)
            self._creditSpins[i]._connectedRoom = i + 1
            
            f = lambda b: self._model.setBalanceOf(b._connectedRoom, int(round(_euroToCent(b.get_value()))))
            self._creditSpins[i].connect('value-changed', f)
        
        # Set up the spin that changes the cash amount.
        self._cashSpin = builder.get_object('appWinCreditsCashSpin')
        adj = Gtk.Adjustment(0.0, 0.0, 250.0, 0.1, 10.0, 0.0)
        self._cashSpin.set_adjustment(adj)
        f = lambda b: (
            self._model.setAvailableCash(round(_euroToCent(b.get_value()), 2))
        )
        self._cashSpin.connect('value-changed', f)
        pass
    
    def update(self, complete=False):
        '''
        Updates the page. Complete doesn't do anything.
        '''
        self._menubar.reset()
        # Add a clear button which removes all entries from the spins.
        f = lambda b: (
            # list() runs the functions.
            list(map(lambda i: self._model.setBalanceOf(i + 1, 0), range(NUM_ROOMS))),
        )
        self._menubar.addButton('edit-clear-all-symbolic', f, Gtk.PackType.END)
        self._menubar.showAll()
        
        # Update the spins.
        for spin in self._creditSpins:
            spin.set_value(_centToEuro(self._model.getBalanceOf(spin._connectedRoom)))
            
        self._cashSpin.set_value(_centToEuro(self._model.getAvailableCash()))
        pass
    
    
    
    
    
    