'''
Created on 16.01.2015

@author: axp
'''
from reportlab.lib import pagesizes, colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.doctemplate import SimpleDocTemplate
from reportlab.platypus.paragraph import Paragraph
from reportlab.platypus.tables import Table, TableStyle


class PDFCreator(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        
    def writeTable(self, heading, firstColWidth, data, outFile):
        if data is None or len(data) == 0:
            return
        
        doc = SimpleDocTemplate(outFile,
                                rightMargin=10,
                                leftMargin=10,
                                topMargin=10,
                                bottomMargin=10,
                                title="",
                                author="",
                                pagesize=pagesizes.landscape(pagesizes.A4))
        elems = []
        para = Paragraph(heading, getSampleStyleSheet()["Italic"])
        elems.append(para)
        
        style = TableStyle([('INNERGRID', (0, 0), (-1, -1), 1, colors.black),
                                        ('BOX', (0, 0), (-1, -1), 1, colors.black),
                                        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
                                        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                                        ('LINEBELOW', (0, 0), (-1, 0), 2, colors.black),
                                        ('LINEAFTER', (0, 0), (0, -1), 2, colors.black),
                                        ('FONTSIZE', (0, 0), (0, -1), 12),
                                        ('FONTSIZE', (0, 0), (-1, 0), 12),
                                        ('FONTSIZE', (1, 1), (-1, -1), 10),
                                        ])
        
        a4Height = A4[1]
        colWidth = [firstColWidth]
        colWidth.extend([((a4Height - colWidth[0]) / (len(data[0]) - 1)) - 5] * (len(data[0]) - 1))
        table = Table(data, style=style, rowHeights=30, colWidths=colWidth)
        elems.append(table)
        
        doc.build(elems)
        pass

