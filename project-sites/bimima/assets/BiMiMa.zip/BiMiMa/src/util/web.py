'''
Created on 20.01.2015

@author: axp
'''
import urllib.request
import constants

PRODUCTS_ONLINE_PRICES = constants.PRODUCTS_ONLINE_PRICES
PRODUCTS_ONLINE_CAUTIONS = constants.PRODUCTS_ONLINE_CAUTIONS


class ProductsInfo(object):
    '''
    Reads product infos from a website.
    '''

        
    def getK4Products(self):
        '''
        Reads products and prices. Is expected to be a short list of "json" elements.
        '''
        f = urllib.request.urlopen(PRODUCTS_ONLINE_PRICES)
        return str(f.read().decode('utf-8'))
        pass
        
    def getK4ProductCautions(self):
        '''
        Reads box types and cautions. Is expected to be a short list of "json" elements.
        '''
        f = urllib.request.urlopen(PRODUCTS_ONLINE_CAUTIONS)
        return str(f.read().decode('utf-8'))
        pass