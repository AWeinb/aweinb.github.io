'''
Created on 06.01.2015

@author: axp
'''


class Observer():
    
    def __init__(self):
        self.clear()
        pass
    
    def add(self, updateable):
        self._updateables.append(updateable)
        pass
    
    def clear(self):
        self._updateables = []
        pass
        
    def update(self):
        for updateable in self._updateables:
            updateable.update()
        pass
