'''
Created on 07.01.2015

@author: axp
'''

from constants import NUM_ROOMS
from data.database import DatabaseManager


class Model():
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self._observer = None
        
        self._dbManager = DatabaseManager()
        self._dbManager.connect()
        pass
    
    def finish(self):
        self._dbManager.disconnect()
        pass
    
    
    def registerObserver(self, observer):
        self._observer = observer
        pass
    
    
    def notify(self):
        if self._observer:
            self._observer.update()
        pass
    
            
    '''
    ---------------------------------------------------------------------------
    '''
    
    def isChanged(self):
        return self._dbManager.hasUncommitedChanges()
        pass
    
    def checkOut(self):
        for room in range(1, NUM_ROOMS):
            costs = 0
            for prod in self.getProductList():
                costs += self.getConsume(room, prod) * self.computePayPriceFor(prod)
            newCredit = self.getBalanceOf(room) - costs
            self.setBalanceOf(room, newCredit)
        self._dbManager.beginNewConsumeTable()
        self.notify()
        pass
    
    def clearAll(self):
        self._dbManager.clearTables()
        self.notify()
        pass
    
    # -------------------------------------------------------------------------
    
    def getAvailableCash(self):
        '''
        Returns the amount of money that is available. Needs to be set to the correct value
        manually. After the first set it may be updated by the program correctly.
        '''
        return self._dbManager.getCredit()
        pass
    
    def setAvailableCash(self, credit):
        '''
        Sets the amount of available money in Cents (Integer). You need to set this the first time.
        '''
        return self._dbManager.setCredit(int(credit))
        pass
    
    # -------------------------------------------------------------------------
    
    def getBalanceOf(self, room):
        '''
        Returns the amount of money a room paid for future expenses. The room is a number above zero.
        The returned amount are Cents (Integer).
        '''
        return self._dbManager.getCreditOf(room)
        pass
    
    def setBalanceOf(self, room, balance):
        '''
        Sets the balance of a room. This is the amount of money a person has as plus. The credit
        is a Integer and represents Cents.
        '''
        self._dbManager.setCreditOf(room, int(balance))
        self.notify()
        pass
    
    def computeCreditSum(self):
        creditSum = 0
        for i in range(NUM_ROOMS):
            credit = self.getBalanceOf(i + 1)
            if credit > 0:
                creditSum += credit
        return creditSum
        pass
    
    def computeCreditOf(self, room):
        debt = 0
        # Debt for all products.
        for prod in self.getProductList():
            num = self.getConsume(room, prod)
            price = self.computePayPriceFor(prod)
            debt += num * price
        # Subtract the credit.
        credit = self.getBalanceOf(room)
        if credit <= debt:
            return 0
        return credit - debt
        pass
    
    # -------------------------------------------------------------------------
    
    def computeEarnedCash(self):
        return self.getAvailableCash() - self.computeCreditSum() - self.computeCautionSum()
        pass
    
    # -------------------------------------------------------------------------
    
    def computeCautionSum(self):
        '''
        Computes how much cautions are paid. Depends on the caution price which should be set
        correctly. The returned value is in Cents.
        '''
        res = 0
        for i in range(NUM_ROOMS):
            res += self.isCautionPaidOf(i + 1)
        res *= self.getCautionPrice()
        return res
        pass
    
    # -------------------------------------------------------------------------
    
    def computeDebt(self):
        '''
        Returns the sum of all debts. The returned amount are Cents.
        '''
        res = 0
        for i in range(NUM_ROOMS):
            res += self.computeDebtOf(i + 1)
        return res
        pass
     
    def computeDebtOf(self, room):
        '''
        Computes the debt of a room. This are the costs of the consumed goods freed from possibly
        left credits. The returned amount are Cents and the value is negative.
        '''
        debt = 0
        # Debt for all products.
        for prod in self.getProductList():
            num = self.getConsume(room, prod)
            price = self.computePayPriceFor(prod)
            debt += num * price
        # Subtract the credit.
        credit = self.getBalanceOf(room)
        if credit > debt:
            return 0
        return credit - debt
        pass
    
    def computeDebtFor(self, productName):
        productName = str(productName).replace(' ', '_')
        return self.computeConsumeFor(productName) * self.computePayPriceFor(productName)
        pass
    
    # -------------------------------------------------------------------------
    
    def computeFutureEarnings(self):
        '''
        Computes the earnings.
        '''
        earnings = 0
        for prod in self.getProductList():
            earnings += self.computeFutureEarningsFor(prod)
        return round(earnings + self.computeEarnedCash(), 2)
        pass
    
    def computeFutureEarningsFor(self, productName):
        productName = str(productName).replace(' ', '_')
        earnings = 0
        for i in range(NUM_ROOMS):
            earnings += self.getConsume(i + 1, productName)
            
        realPrice = self.getMarketPriceFor(productName)
        price = self.computePayPriceFor(productName)
        if realPrice > price:
            raise ValueError()
        diff = price - realPrice
        earnings *= diff
        
        return round(earnings, 2)
        pass
    
    # -------------------------------------------------------------------------
    
    def addProduct(self, productName, price):
        '''
        Adds a product to the data. The productName is a string and the price a float value. 
        Already existing products get replaced.
        '''
        productName = str(productName).replace(' ', '_')
        self._dbManager.addProduct(productName, float(price))
        pass
    
    def removeProduct(self, productName):
        '''
        Removes a product from the data by id. The productName is a string.
        '''
        productName = str(productName).replace(' ', '_')
        self._dbManager.removeProduct(productName)
        pass
    
    def getProductList(self):
        '''
        Returns the available products in a list.
        '''
        tmp = self._dbManager.getAllProducts()
        for i in range(len(tmp)):
            tmp[i] = str(tmp[i]).replace('_', ' ')
        return tmp
        pass
    
    # -------------------------------------------------------------------------
    
    def computePayPriceFor(self, productName):
        '''
        Returns the smoothed price of the product in Cents (Float).
        '''
        productName = str(productName).replace(' ', '_')
        price = self.getMarketPriceFor(productName)
        if price:
            if price % 10 > 5:
                price -= price % 10
                price += 10
            elif  price % 10 > 0:
                price -= price % 10
                price += 5
        return price
        pass
    
    def getMarketPriceFor(self, productName):
        productName = str(productName).replace(' ', '_')
        return self._dbManager.getProductPrice(productName)
        pass
    
    def setMarketPriceFor(self, productName, price):
        '''
        Sets the price of a product in Cents. This is a float for lower Cent amounts (Float).
        '''
        productName = str(productName).replace(' ', '_')
        self._dbManager.setProductPrice(productName, float(price))
        self.notify()
        pass
    
    # -------------------------------------------------------------------------
    
    def computeConsumeFor(self, productName):
        '''
        Returns the complete consume of a product.
        '''
        productName = str(productName).replace(' ', '_')
        res = 0
        for i in range(NUM_ROOMS):
            res += self.getConsume((i + 1), productName)
        return res
        pass
    
    def getConsume(self, room, productName):
        '''
        Returns the consume of a product for the given room.
        '''
        productName = str(productName).replace(' ', '_')
        return self._dbManager.getConsume(room, productName)
        pass
    
    def setConsume(self, room, productName, consume):
        '''
        Sets the consume of a product for a room.
        '''
        productName = str(productName).replace(' ', '_')
        self._dbManager.setConsume(room, productName, int(consume))
        self.notify()
        pass
    
    # -------------------------------------------------------------------------
    
    def isCautionPaidOf(self, room):
        '''
        Checks if the caution for a room was paid.
        '''
        return self._dbManager.getCautionPaid(room)
        pass
    
    def setCautionPaidOf(self, room, paid):
        '''
        Sets the paid flag for a room.
        '''
        self._dbManager.setCautionPaid(room, paid)
        self.notify()
        pass
    
    # -------------------------------------------------------------------------
    
    def getCautionPrice(self):
        '''
        Returns the amount of money in Cents that needs to be paid as Caution (Integer).
        '''
        return self._dbManager.getCautionAmount()
        pass
    
    def setCautionPrice(self, caution):
        '''
        Sets the Caution amount in Cents (Integer).
        '''
        self._dbManager.setCautionAmount(int(caution))
        self.notify()
        pass
    
    # -------------------------------------------------------------------------
    
    
