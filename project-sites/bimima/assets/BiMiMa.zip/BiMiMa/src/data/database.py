'''
Created on 03.01.2015

@author: axp
'''

import datetime
import os
import shutil
import sqlite3

import constants


DATABASE_FILE = constants.DATABASE_FILE
DATABASE_DUMP_DIR = constants.DATABASE_DUMP_DIR
TBL_PRICES = constants.TBL_PRICES
TBL_CURRENTCONSUME = constants.TBL_CURRENTCONSUME
TBL_CAUTIONS = constants.TBL_CAUTIONS
TBL_CREDITS = constants.TBL_CREDITS
TBL_MISC = constants.TBL_MISC

NUM_ROOMS = constants.NUM_ROOMS


class DatabaseManager(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructs only the instance. Use connect to connect to the database.
        '''
        self._dbCursor = None
        self._dbConnection = None
        pass
        
        
    def connect(self):
        '''
        Connects to the database and initializes the module.
        '''
        # I want to prevent double connects.
        self.disconnect()
        
        if os.path.exists(DATABASE_FILE):
            db = sqlite3.connect(DATABASE_FILE)
        else:
            return False
        
        self._dbConnection = db
        self._dbCursor = db.cursor()
        
        self._controlTables()
        
        return True
        pass
    
    
    def disconnect(self):
        '''
        Disconnects the program from the database and triggers a commit.
        '''
        if self._dbCursor:
            self._dbCursor.close()
            self._dbCursor = None
            
        if self._dbConnection:
            self._dbConnection.commit()
            self._dbConnection.close()
            self._dbConnection = None
        pass


    '''
    ------------------------------------------------------------------------
    '''

    
    def _controlTables(self):
        '''
        Checks if all needed tables are available and if not creates/inits them.
        '''
        exists = lambda tablename: self._dbCursor.execute('''SELECT count(*) 
                                                            FROM sqlite_master 
                                                            WHERE type='table' AND name=?;''',
                                                            (tablename,)).fetchone()[0] > 0


        # Create the price product table.
        if not exists(TBL_PRICES):
            self._dbCursor.execute('''CREATE TABLE IF NOT EXISTS `{0}` (
                                        `product` VARCHAR(100), 
                                        `productPrice` DOUBLE, 
                                        UNIQUE(`product`) ON CONFLICT REPLACE);'''
                                        .format(TBL_PRICES))
            print("Created", TBL_PRICES)
        # --

        # Create the room consume table. The room number is fix and is initialized here.
        if not exists(TBL_CURRENTCONSUME):
            tmp = '''CREATE TABLE IF NOT EXISTS `{0}` (
                        `product` VARCHAR(100), '''.format(TBL_CURRENTCONSUME)
                        
            for i in range(0, NUM_ROOMS):
                tmp += '''`{0}` INTEGER DEFAULT 0'''.format(i + 1)
                if i < NUM_ROOMS - 1:
                    tmp += ', '
                    
            tmp += ', UNIQUE(`product`) ON CONFLICT REPLACE);'
            self._dbCursor.execute(tmp)
            print("Created", TBL_CURRENTCONSUME)
        # --


        # Create the room caution table. The room number is fix and is initialized here.
        if not exists(TBL_CAUTIONS):
            self._dbCursor.execute('''CREATE TABLE IF NOT EXISTS `{0}` (
                                        `room` INTEGER, 
                                        `paid` TINYINT DEFAULT 0, 
                                        UNIQUE(`room`) ON CONFLICT REPLACE);'''
                                        .format(TBL_CAUTIONS))
            
            for i in range(0, NUM_ROOMS):
                self._dbCursor.execute('''INSERT INTO `{0}` 
                                            (`room`) VALUES ({1});'''
                                            .format(TBL_CAUTIONS, (i + 1)))
            print("Created", TBL_CAUTIONS)
        # --
        
        
        # Create the room credit table. The room number is fix and is initialized here.
        if not exists(TBL_CREDITS):
            self._dbCursor.execute('''CREATE TABLE IF NOT EXISTS `{0}` (
                                        `room` INTEGER, 
                                        `credit` INTEGER DEFAULT 0, 
                                        UNIQUE(`room`) ON CONFLICT REPLACE);'''
                                        .format(TBL_CREDITS))
            
            for i in range(0, NUM_ROOMS):
                self._dbCursor.execute('''INSERT INTO `{0}` 
                                            (`room`) VALUES ({1});'''
                                            .format(TBL_CREDITS, (i + 1)))
            print("Created", TBL_CREDITS)
        # --
            
            
        if not exists(TBL_MISC):
            self._dbCursor.execute('''CREATE TABLE IF NOT EXISTS `{0}` (
                                        `id` VARCHAR(100), 
                                        `ints` INTEGER DEFAULT 0, 
                                        UNIQUE(`id`));'''.format(TBL_MISC))
            
            self._dbCursor.execute('''INSERT INTO `{0}` 
                                        (`id`, `ints`) VALUES ("{1}", {2});'''
                                        .format(TBL_MISC, "allCredit", 0))
            
            self._dbCursor.execute('''INSERT INTO `{0}` 
                                        (`id`, `ints`) VALUES ("{1}", {2});'''
                                        .format(TBL_MISC, "cautionAmount", 0))
            print("Created", TBL_MISC)
        # --
        pass
    
    def clearTables(self):
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_PRICES))
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_CURRENTCONSUME))
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_CAUTIONS))
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_CREDITS))
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_MISC))
        self._controlTables()
        pass


    def beginNewConsumeTable(self):
        '''
        Stores the old database in a backup directory and creates a new consume table.
        '''
        if not os.path.exists(DATABASE_DUMP_DIR):
            os.makedirs(DATABASE_DUMP_DIR)
        
        date = str(datetime.datetime.now().date())
        filepath = os.path.abspath(os.path.join(DATABASE_DUMP_DIR, '{0}.db'.format(date)))
        shutil.copyfile(DATABASE_FILE, filepath)
        
        self._dbCursor.execute('''DROP TABLE IF EXISTS `{0}`;'''.format(TBL_CURRENTCONSUME))
        # Creates the table again. But it is empty now!
        self._controlTables()
        # Add the products again. The prices are less likely to change completely.
        productsToReadd = self.getAllProducts()
        for prod in productsToReadd:
            self._dbCursor.execute('''INSERT INTO `{0}` 
                                    (`product`) VALUES (?);'''
                                    .format(TBL_CURRENTCONSUME), (prod,))
        pass
    

    def hasUncommitedChanges(self):
        '''
        Returns if the database has changes since the last commit.
        '''
        # Incorrect
        return self._dbConnection.total_changes > 0
        pass


    def addProduct(self, productName, price):
        '''
        Adds a product to the database. The name is used as id for the product. The price is the
        value in cents, floats are allowed. If you add an already existing product it will replace 
        the existing one with default values.
        '''
        if not self._checkProductName(productName) or not self._checkPrice(price):
            raise ValueError("productName[{0}] or price[{1}] are not valid!".format(productName, price))
        
        self._dbCursor.execute('''INSERT INTO `{0}` 
                                    (`product`, `productPrice`) VALUES (?, ?);'''
                                    .format(TBL_PRICES), (productName, price))
        self._dbCursor.execute('''INSERT INTO `{0}` 
                                    (`product`) VALUES (?);'''
                                    .format(TBL_CURRENTCONSUME), (productName,))
        return True
        pass
    
    def removeProduct(self, productName):
        '''
        Removes a product from the database using the name as an id. All connected information
        will be lost.
        '''
        if not self._checkProductName(productName):
            raise ValueError("productName[{0}] is not valid!".format(productName))
        
        self._dbCursor.execute('''DELETE FROM `{0}` WHERE `product`=?;'''.format(TBL_PRICES), (productName,))
        self._dbCursor.execute('''DELETE FROM `{0}` WHERE `product`=?;'''.format(TBL_CURRENTCONSUME), (productName,))
        return True
        pass
    
    def setProductPrice(self, productName, price):
        '''
        Lets you update the price of the product. The price is given in Cents (float or int).
        '''
        if not self._checkProductName(productName) or not self._checkPrice(price):
            raise ValueError("productName[{0}] or price[{1}] are not valid!".format(productName, price))
        
        self._dbCursor.execute('''UPDATE `{0}` SET `productPrice`=? 
                                    WHERE `{0}`.`product`=?;'''
                                    .format(TBL_PRICES), (price, productName))
        pass
    
    def getProductPrice(self, productName):
        '''
        Returns the actual price of the product. It happens that this price is not suitable for
        trading because of small cent amounts. It returns Cents.
        '''
        if not self._checkProductName(productName):
            raise ValueError("productName[{0}] is not valid!".format(productName))
        
        res = self._dbCursor.execute('''SELECT `productPrice` FROM `{0}` 
                                        WHERE `{0}`.`product`=?;'''
                                        .format(TBL_PRICES), (productName,)).fetchone()
        if res:
            return res[0]
        return None
        pass
    
    def getAllProducts(self):
        '''
        Returns a list of all available products.
        '''
        # Gets from the server the column with the product names. The values are tuples in a list.
        tupList = self._dbCursor.execute('''SELECT `product` FROM `{0}`;'''.format(TBL_PRICES)).fetchall()
        tupList = [str(tup[0]) for tup in tupList]
        return tupList
        pass
    
    
    def getConsume(self, room, productName):
        '''
        Returns the consume of a room for a specific product.
        '''
        if not self._checkRoom(room) or not self._checkProductName(productName):
            raise ValueError("room[{0}] or productName[{1}] are not valid!".format(room, productName))
        
        res = self._dbCursor.execute('''SELECT `{0}` FROM `{1}` WHERE `product`=?;'''
                                     .format(room, TBL_CURRENTCONSUME), (productName,)).fetchone()
        if res:
            return res[0]
        return None
        pass
    
    def setConsume(self, room, productName, consume):
        '''
        Sets the consume of a room for a product.
        '''
        if not self._checkRoom(room) or not self._checkProductName(productName) or not self._checkConsume(consume):
            raise ValueError("room[{0}], productName[{1}] or consume[{2}] are not valid!".format(room, productName, consume))
        
        self._dbCursor.execute('''UPDATE `{0}` SET `{1}`=? WHERE `product`=?;'''
                               .format(TBL_CURRENTCONSUME, room), (consume, productName))
        return True
        pass
    
    
    def getCreditOf(self, room):
        '''
        Returns the personal credit of the given room in Cents (Integer). 
        '''
        if not self._checkRoom(room):
            raise ValueError("room[{0}] is not valid!".format(room))
        
        res = self._dbCursor.execute('''SELECT `credit` FROM `{0}` WHERE `room`=?;'''
                                     .format(TBL_CREDITS), (room,)).fetchone()
        if res:
            return res[0]
        return None
        pass
    
    def setCreditOf(self, room, credit):
        '''
        Sets the personal credit of a room. Use Cents (Integer).
        '''
        if not self._checkRoom(room) or not self._checkCredit(credit):
            raise ValueError("room[{0}] or credit[{1}] are not valid!".format(room, credit))
        
        self._dbCursor.execute('''UPDATE `{0}` SET `credit`=? WHERE `room`=?;'''
                               .format(TBL_CREDITS), (credit, room))
        pass
    
    
    def getCredit(self):
        '''
        Returns the amount of money available in Cents (Integer).
        '''
        res = self._dbCursor.execute('''SELECT `ints` FROM `{0}` WHERE `id`='allCredit';'''
                                     .format(TBL_MISC)).fetchone()
        if res:
            return res[0]
        return None
        pass
    
    def setCredit(self, credit):
        '''
        Sets the available amount of money. Use Cents (Integer).
        '''
        if not self._checkCredit(credit):
            raise ValueError("credit[{1}] are not valid!".format(credit))
        
        self._dbCursor.execute('''UPDATE `{0}` SET `ints`=? WHERE `id`='allCredit';'''
                               .format(TBL_MISC), (credit,))
        print(credit, self.getCredit())
        pass
    
    
    def getCautionPaid(self, room):
        '''
        Returns if the caution for room x was paid.
        '''
        if not self._checkRoom(room):
            raise ValueError("room[{0}] is not valid!".format(room))
        
        res = self._dbCursor.execute('''SELECT `paid` FROM `{0}` WHERE `room`=?;'''
                                     .format(TBL_CAUTIONS), (room,)).fetchone()
        if res:
            return res[0] > 0
        return False
        pass
    
    def setCautionPaid(self, room, paid):
        '''
        Sets the caution flag for the room x.
        '''
        if not self._checkRoom(room):
            raise ValueError("room[{0}] is not valid!".format(room))
        
        flag = 0
        if paid:
            flag = 1
        
        self._dbCursor.execute('''UPDATE `{0}` SET `paid`=? WHERE `room`=?;'''
                               .format(TBL_CAUTIONS), (flag, room))
        return True
        pass
    
    def getCautionAmount(self):
        '''
        Returns the used caution value in Cents.
        '''
        res = self._dbCursor.execute('''SELECT `ints` FROM `{0}` WHERE `id`='cautionAmount';'''
                                     .format(TBL_MISC)).fetchone()
        if res:
            return res[0]
        return None
        pass
    
    def setCautionAmount(self, caution):
        '''
        Sets the used caution value in Cents.
        '''
        self._dbCursor.execute('''UPDATE `{0}` SET `ints`=? WHERE `id`='cautionAmount';'''
                               .format(TBL_MISC), (caution,))
        pass
    
    
    def _checkProductName(self, productName):
        res = productName is not None and isinstance(productName, str) and not len(productName) < 1 
        res &= not len(productName) > 100 and (' ' not in productName)
        if not res:
            print("_checkProductName failed!")
        return res
        pass
    
    def _checkPrice(self, price):
        res = price is not None and isinstance(price, (int, float)) and price >= 0
        if not res:
            print("_checkPrice failed!")
        return res
        pass
    
    def _checkRoom(self, room):
        res = room is not None and isinstance(room, (int)) and room > 0 and room <= NUM_ROOMS
        if not res:
            print("_checkRoom failed!")
        return res
        pass
    
    def _checkConsume(self, consume):
        res = consume is not None and isinstance(consume, (int)) and consume >= 0
        if not res:
            print("_checkConsume failed!")
        return res
        pass
    
    def _checkCredit(self, credit):
        res = credit is not None and isinstance(credit, (int))
        if not res:
            print("_checkCredit failed!")
        return res
        pass
