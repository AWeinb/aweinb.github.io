'''
Created on 03.01.2015

@author: axp
'''

from controller import Observer
from data.model import Model
from ui.gui import GUI


class BiMiMa(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        model = Model()
        gui = GUI(model)
        obs = Observer()
        obs.add(gui)
        model.registerObserver(obs)
        
        gui.show()
        model.finish()
        pass
    
    
if __name__ == '__main__':
    bimima = BiMiMa()
    pass