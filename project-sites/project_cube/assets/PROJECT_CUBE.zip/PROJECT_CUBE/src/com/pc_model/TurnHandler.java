package com.pc_model;

/**
 * Der Turnhandler verwaltet Turn-Objekte, sowie undo- und redo-Vorgaenge. Eine
 * zentrale Komponente des Models, verantwortlich fuer die Steuerungs des
 * logischen Wuerfels sowie der Automatisierung der Winkelrepraesentation des
 * Wuerfels und der Aktualisierung der Spielstatistik.
 * 
 * */
final class TurnHandler {
  
	
	private static Cube cube;
	private static GraphicCube grCube;
	
	/*
	 * Privater Konstruktor
	 */
	private TurnHandler() {
	}
	
	/*
	 * Diese Methode steuert den Ablauf eines Turns basierend auf den in einem Turn-Objektes befindlichen Daten.
	 * So wird das Protokoll wenn gewuenscht aktualisiert, der Turn gegenfalls konvertiert,
	 * die Permutation auf dem Wuerfel ausgefuehrt und der Grafik-Wuerfel zur Animation angeleitet.
	 */
	private static boolean manageTurn(Turn turn, boolean addToProtocol) {
		try {
			
			
			int frontFace = cube.getFrontID();
			int sideFace = cube.getSideID();
		  
		  turn.convert(frontFace, sideFace);
		  
		  } catch(NullPointerException e) {
			  System.out.println("TurnHandler: Cube und/oder GraphicCube nicht gesetzt. Oder Turn Object null.");
		  }
		  
		  
		  //Ablauf fuer Turns ohne Benutzereingabe (z.B.: automatische Loesung)
		  if(grCube.getCurrentAngle() == 0) {
			  int cubeSize = cube.getSize();
			  //Ich sezte einen Grad, damit der GraphicCube weiss, welchen Winkel er animieren soll.
			  switch(turn.getValue()) {
			  	case F             : grCube.setAngle(2, 0, 1); break;
			  	case FPRIME        : grCube.setAngle(2, 0, -1); break;
			  	case B             : grCube.setAngle(2, cubeSize - 1, -1); break;
			  	case BPRIME        : grCube.setAngle(2, cubeSize - 1, 1); break;
			  	case L             : grCube.setAngle(0, 0, 1); break;
			  	case LPRIME        : grCube.setAngle(0, 0, -1); break;
			  	case R             : grCube.setAngle(0, cubeSize - 1, -1); break;
			  	case RPRIME        : grCube.setAngle(0, cubeSize - 1, 1); break;
			  	case U             : grCube.setAngle(1, 0, 1); break;
			  	case UPRIME        : grCube.setAngle(1, 0, -1); break;
			  	case D             : grCube.setAngle(1, cubeSize - 1, -1); break;
			  	case DPRIME        : grCube.setAngle(1, cubeSize - 1, 1); break; 
			  }
			  if(cubeSize % 2 == 1) {
				  int middle = (cubeSize - 1) / 2;
				  switch(turn.getValue()) {
				  
		            case E         : grCube.setAngle(1, middle, -1); break;
		            case EPRIME    : grCube.setAngle(1, middle, 1); break;
		            case M         : grCube.setAngle(0, middle, 1); break;
		            case MPRIME    : grCube.setAngle(0, middle, -1); break;
		            case S         : grCube.setAngle(2, middle, 1); break;
		            case SPRIME    : grCube.setAngle(2, middle, -1); break;
		            }
				  
			  } else if(cubeSize > 3) {
				  //Platz fuer groessere Cubes
			  }
			  
		  }
		  
		  switch(turn.getValue()) {
		     case ROTX      :  grCube.animRotation(false, 0);
		     				   cube.applyTurn(turn.getValue());
		     				   grCube.reset();
		                       break;
		     case ROTXPRIME :  grCube.animRotation(true, 0);
		                       cube.applyTurn(turn.getValue());
		                       grCube.reset();
		                       break;
		     case ROTY      :  grCube.animRotation(true , 1);
		                       cube.applyTurn(turn.getValue());
		                       grCube.reset();
		                       break;
		     case ROTYPRIME :  grCube.animRotation(false , 1);
		                       cube.applyTurn(turn.getValue());
		                       grCube.reset();
		                       break;
		     case ROTZ      :  grCube.animRotation(true, 2);
		                       cube.applyTurn(turn.getValue());
		                       grCube.reset();
		                       break;
		     case ROTZPRIME :  grCube.animRotation(false, 2);
		                       cube.applyTurn(turn.getValue());
		                       grCube.reset();
		                       break;
		     //Der default Fall ist das, was bei regulaeren Verdrehungen immer passiert
		     default : grCube.animate(false);
		               cube.applyTurn(turn.getValue());
		               grCube.reset();
		               if(addToProtocol) {
		   				GameProtocol.setNextTurn(turn);
		   				}  
		  }
		  return true;
		
	}
	/**
   * Die manageTurn-Methode liest Informationen des Turn-Objekts, sorgt
   * gegebenfalls fuer eine Konvertierung dessen und leitet die noetigen
   * Informationen an die jeweiligen Interessenten weiter. So wird das logische
   * Modell ueber die Art des Zuges informiert, damit dieser angewendet werden
   * kann, die Winkelrepraesentation des GraphicCubes dazu aufgefordert,
   * automatisiert eine neutrale Position einzunehmen und die Statistik ueber den
   * neuen Spielzug informiert. Auch das Abspielen eines Tons wird durch den
   * TurnHandler initialisiert.
   * 
   * @param turn
   *          Ein Turn-object, welches genauere Details, noetig fuer die eigene
   *          Verarbeitung, beinhaltet.
   * @return Nachdem alle noetigen Schritte fuer die Verarbeitung eines
   *         Turn-Objectes erfolgreich abgeschlossen wurden, erhaelt man ein
   *         true.
   * */
  static boolean manageTurn(Turn turn) {
	  return manageTurn(turn, true);
  }

  /**
   * Greift auf den naechst ausfuehrbaren Turn im Protokoll zu und verarbeitet
   * diesen.
   * 
   * @return true wenn der Vorgang erfolgreich rar. false, falls Misserfolg oder kein weiter Turn im Protocol.
   * */
  static boolean redo() {
	
	  boolean success;
	  
	  Turn nextTurn = GameProtocol.getNextTurn();
	  if(nextTurn != null) {
		  int frontFace = cube.getFrontID();
		  int sideFace = cube.getSideID();
		  nextTurn.invert();
		  nextTurn.convert(frontFace, sideFace);
		  manageTurn(nextTurn, false);
		  success = true;
	  } else {
		  success = false;
	  }
	  return success;
  }

  /**
   * Nimmt den letzten Turn aus dem Protokoll, invertiert diesen, fuehrt ihn aus.
   * 
   * @return true, ist der Vorgang erfolgreich. false, falls Misserfolg oder kein vorheriger Turn im Protocol.
   * */
  static boolean undo() {
	
	  boolean success;
	  
	  Turn lastTurn = GameProtocol.getLastTurn();
	  if(lastTurn != null) {
		  int frontFace = cube.getFrontID();
		  int sideFace = cube.getSideID();
		  lastTurn.convert(frontFace, sideFace);
		  lastTurn.invert();
		  manageTurn(lastTurn, false);
		  success = true;
	  } else {
		  success = false;
	  }
	  return success;
  }
  
  /**
   * Erteilt dem TurnHandler einen Wuerfel zu, mit dem er arbeiten kann.
   * @param newCube Der zu bearbeitende Wuerfel
   */
  static void setCube(Cube newCube) {
		cube = newCube;
	}
  
  /**
   * Einfache getter-Methode, um den aktuell bearbeiteten Wuerfel zu erhalten
   * @return Das im Moment bearbeitete Wuerfel-Objekt
   */
  static Cube getCube() {
	  
	  return cube;
	  
  }
  
  /**
   * Erteilt dem TurnHandler einen Graphic-Wuerfel zu, mit dem er arbeiten kann.
   * @param newGrCube Der zu bearbeitende Graphic-Wuerfel
   */
  static void setGrCube(GraphicCube newGrCube) {
	  grCube = newGrCube;
  }
  
  /**
   * Einfache getter-Methode, um den aktuell bearbeiteten Graphic-Wuerfel zu erhalten
   * @return Das im Moment bearbeitete Graphic-Wuerfel-Objekt
   */
  static GraphicCube getGrCube() {
	  return grCube;
  }
  
}
