package com.pc_model;

import java.lang.Integer;
import java.lang.IllegalArgumentException;

import android.util.Log;

import com.pc_controller.FileHandler;
import com.pc_util.Constants;

/** Repraesentiert die Bestenliste des Zauberwuerfelspiels. */
public class Highscores {

  /* den zuletzt gespeicherten Spielstand des Zugzaehlers */
  private int aktCount = 0;
  /* die zuletzt gespeicherte Zeit in Millisekunden */
  private long aktTime = 0;
  /*
   * die zuletzt gespeicherte Highscoretabelle der Form [Platzierung][{name, counter, time}]
   */
  private String[][] aktScore = Constants.DUMMY;
  /* Einzige Instanz dieser Klasse */
  private static Highscores instance = null;

  /* Privater Konstruktor verhindert das Erstellen von Aussen. Singleton. */
  private Highscores() {
    aktScore = FileHandler.loadHighScore();
  }

  /**
   * Ermoeglicht das referenzieren der einzigen Instanz dieser Klasse. Singleton.
   * 
   * @return die einzige Instanz dieser Klasse.
   */
  public static Highscores getInstance() {
    if (instance == null) {
      instance = new Highscores();
    }

    return instance;
  }

  /**
   * Liest die alte Highscoretabelle aus und ueberprueft, ob die aktuelle Spielloesung den Highscore sprengt, also ob der
   * Counter oder die Zeit kleiner ist als ein Wert in der aktellen Liste. Speichert den Counter und die Zeit zwischen.
   * Ist die aktuelle Liste nicht voll, wird immer true zurueck gegeben.
   * 
   * @param time
   *          die Spielzeit in Millisekunden
   * @param count
   *          die benoetigten Zuege
   * @return true, falls der Spieler in der Highscoreliste eingetragen werden kann. false falls nicht.
   */
  public boolean check(long time, int count) throws IllegalArgumentException {
    if ((time < 0) || (count < 0)) {
      throw new IllegalArgumentException("Zeit und Zuege koennen nicht kleiner als 0 sein.");
    }

    this.aktTime = time;
    this.aktCount = count;

    return isHighscore(time, count);
  }

  /**
   * Traegt den Spieler in die Highscoreliste ein. Der Spielcounter und Spielstand sind zwischengepeichert. Die neue
   * Liste ist nach Count sortiert und wird in aktScore gespeichert, um dann vom Filehandler in die Datei geschrieben zu
   * werden.
   * 
   * @param name
   *          der Name des Spielers
   * @return ob der Spieler erfolgreich in der Bestenliste eingetragen wurde.
   */
  public boolean sign(String name) {
    
    if(name.contains(Constants.SEPARATOR)|| name.equals("")){
      name = "anonymus";
    }
    
    // Form ist [Platzierung][{name, counter, time}]
    String a = "" + aktCount; // Hilfsvariable zur Konvertierung von int nach String
    String b = "" + aktTime; // Hilfsvariable zur Konvertierung von int nach String
    String[] score = { name, a, b };
    boolean set = false;
    boolean signed = false;

    if (aktScore.equals(Constants.DUMMY)) {
      aktScore = new String[1][3];
      aktScore[0] = score; // sollte die Laenge 3 haben...s.o.
      return true;
    }
    // sort by count
    for (int i = 0; (i < aktScore.length) && (!set); i++) { // !set erspart das break im if
      int oldCount = 0;
      try {
        oldCount = Integer.parseInt(aktScore[i][1]);

      } catch (NumberFormatException e) {
        oldCount = Integer.MAX_VALUE;
        e.printStackTrace();
        signed = false;
      }

      if ((aktCount >= oldCount) && (i == aktScore.length - 1)) {
        try {
          signed = setToPosition(i + 1, score);
          set = true; // ersetzt break
        } catch (IllegalArgumentException e) {
          e.printStackTrace();
          set = true;
          signed = false;
          break;
        }
      } else if (aktCount < oldCount) {
        try {
          signed = setToPosition(i, score);
          set = true; // ersetzt break
        } catch (IllegalArgumentException e) {
          e.printStackTrace();
          set = true;
          signed = false;
          break;
        }
      }
    }

    FileHandler.storeHighScore(aktScore);
    return signed;
  }

  /**
   * Stellt die aktuelle Bestenliste als menschenlesbaren String dar, um sie auszugeben.
   * 
   * @return die Bestenliste als String.
   */
  @Override
  public String toString() {
    if (aktScore == null || aktScore.equals(Constants.DUMMY)) { // error vermeiden, zum testen falls
                                            // FileHandler nicht funktionniert.
      return "Es liegt leider noch keine Bestenliste vor.";
    }

    StringBuilder builder = new StringBuilder();
    builder.append("Position \t Name \t Z�ge \t Zeit \n");

    for (int i = 0; i < aktScore.length; i++) {
      builder.append(i + 1).append("\t\t"); // Nummer in der Liste

      for (int j = 0; j < aktScore[i].length-1; j++) {
        builder.append(aktScore[i][j]).append("\t"); // Name, Count, Time
        Log.v("H","toString: aktScore["+i+"]["+j+"] = "+aktScore[i][j]);
      }
      if(aktScore[i].length >= 3){
        builder.append(timeToString(aktScore[i][aktScore[i].length-1]));
      }

      builder.append("\n");
    }
    return builder.toString();
  }

  private Object timeToString(String aktScore) {
    StringBuilder builder = new StringBuilder();
    long millis = 0;
    long seconds = 0;
    long minutes = 0;
    long hours = 0;
    try {
      millis = Long.parseLong(aktScore);
      seconds = millis / 1000;
      minutes = seconds / 60;
      hours = minutes / 60;
      millis = millis % 1000;
    } catch (NumberFormatException e) {

    }
    if (hours > 0) {
      builder.append("" + hours + ":");
    }
    if (minutes > 0) {
      builder.append("" + minutes + ":");
    } else {
      builder.append("00:");
    }
    builder.append("" + seconds + ":");
    builder.append("" + millis);
    return builder.toString();
  }

  /**
   * Gibt die aktuelle Bestenliste als Tabelle als Stringrepraesentation aus in der Form [Platzierung][{name, counter,
   * time}]
   * 
   * @return die aktuelle Bestenliste als Stringtabelle
   */
  public String[][] getScores() {
    return this.aktScore;
  }

  /**
   * Gibt die zuletzt zwischengespeicherte Anzahl an Zuegen zurueck.
   * 
   * @return die zuletzt gespeicherte Anzahl an Zuegen als int.
   */
  public int getAktCount() {
    return this.aktCount;
  }

  /**
   * Gibt die zuletzt zwischengespeicherte Zeit zurueck.
   * 
   * @return die zuletzt gespeicherte Zeit in Millisekunden.
   */
  public long getAktTime() {
    return this.aktTime;
  }

  /** Setzt die aktuelle Scoreliste zurueck. */
  public void reset() {
    this.aktCount = 0;
    this.aktScore = Constants.DUMMY;
    this.aktTime = 0;
    FileHandler.resetHighscore();
  }

  // ##### ##### #### #### ### ### ### ## # PRIVATE # ## ### ### ### #### ####

  /*
   * gleicht den aktuellen Count und die aktuelle Spielzeit mit denen aus der Bestenliste ab. Gibt nur dann true zurueck
   * falls Count oder Zeit kleiner als der groesste Wert der Liste ist.
   * 
   * @param time Die Spielzeit in Millisekunden
   * 
   * @param count die Anzahl der Zuege.
   * 
   * @return ob der aktuelle Spielstand eine Eintragung in der Bestenliste erlaubt.
   */
  private boolean isHighscore(long time, int count) {
    boolean isScore = false;

    if (aktScore.equals(Constants.DUMMY)) {
      System.out.println("Highscores isHighscore: aktScore == DUMMY");
      return true;
    }

    int oldCount = 0;
    long oldTime = 0;
    for (int i = 0; i < aktScore.length; i++) {
      try {
        oldCount = Integer.parseInt(aktScore[i][1]);
      } catch (NumberFormatException e) {
        oldCount = Integer.MAX_VALUE;
        e.printStackTrace();
      }
      try {
        oldTime = Long.parseLong(aktScore[i][2]);
      } catch (NumberFormatException e) {
        oldTime = Long.MAX_VALUE;
        e.printStackTrace();
      }

      if ((aktCount < oldCount) || (aktTime < oldTime)) {
        isScore = true;
      }
    }
    if (aktScore.length < Constants.HIGHSCORE_ENTRIES) {
      isScore = true;
    }
    return isScore;
  }

  /*
   * Bekommt einen Score und setzt ihn in der Bestenliste an die Position, die uebergeben wurde. Speichert die neue Liste
   * in aktScore.
   * 
   * @param pos die Position in der Liste, an der der Eintrag gespeichert werden soll. Groesser Null.
   * 
   * @param score der Eintrag, der gespeichert werden soll in der Form {name, count, time}.
   */
  private boolean setToPosition(int pos, String[] score) throws IllegalArgumentException {
    boolean set = false;
    if (pos < 0) {
      throw new IllegalArgumentException("Index muss groesser gleich null sein.");
    } else if (pos > Constants.HIGHSCORE_ENTRIES) {
      throw new IllegalArgumentException("Index ist zu gross.");
    }

    int length;
    if (aktScore.length < Constants.HIGHSCORE_ENTRIES) {
      length = aktScore.length + 1;
    } else {
      length = aktScore.length;
    }

    String[][] neu = new String[length][aktScore[0].length];
    for (int i = 0; i < pos; i++) {
      neu[i] = aktScore[i];
    }
    if (pos < length) {
      neu[pos] = score;
      set = true;
    }
    for (int j = pos + 1; j < neu.length; j++) {
      neu[j] = aktScore[j - 1];
      // aktScore[j] fliegt raus falls die maximale Anzahl der Eintraege in der
      // Liste ueberschritten wird.
    }
    aktScore = neu;
    return set;
  }

}
