package com.pc_model;


/**
 * Das Interface CubeObserver muss implementiert werden, um Drehung der Ebenen
 * und Faerbung der einzelnen Flaechen entgegen zu nehmen. Dabei enthaelt der
 * GraphicCube die Winkel fuer jede Ebene jeder Achse und der Cube die Faerbung
 * der Einzelflaechen als Enum. Die Werte muessen durch richtige Farben ersetzt
 * werden. Die Cube Darstellung ist abstrahiert.
 * 
 * @author AxP
 * 
 */
public interface CubeObserver {
  /**
   * Diese Update Methode aktualisiert die Ebenenrotation.
   * 
   * @param c Die abstrakte Darstellung eines Wuerfels der die Winkel der Ebenen enthaelt.
   */
  public void update(GraphicCube c);

  /**
   * Diese Update Methode aktualisiert die Flaechenfaerbung.
   * 
   * @param c Diese abstrakte Darstellung enthaelt eine abstrakte Faerbungsanweisung als Enums.
   */
 public void update(Cube c);
}
