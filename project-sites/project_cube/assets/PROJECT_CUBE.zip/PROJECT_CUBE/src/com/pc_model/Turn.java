package com.pc_model;

import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;

/** Diese Klasse stellt eine einzige Interaktion mit dem Wuerfel dar. */
public class Turn {
  /* Das Wert des Turns. */
  private TurnType turn;

  /* Das ID der forderen Seite des Wuerfels auf dem das Zug gemacht wurde. */
  private int frontFaceID;

  /* Das ID der linken Seite des Wuerfels auf dem das Zug gemacht wurde. */
  private int sideFaceID;

  /**
   * Das ist die Konstruktor Methode ueber die man einen neuen Turn definieren kann. Der turnWert muss gesetzt sein. Er
   * ist in Constants.TurnType definiert. Die Front/SideFace muss zwischen 0 und 5 liegen. Ist diese Auflage nicht
   * erf&#252;llt, wird eine IllegalArgumentException geworfen.
   * 
   * @param turnValue
   *          Das Wert des Zuges in die festgelegte Notation.
   * @param frontFaceID
   *          Der ID der vorderen Seite zum Zeitpunkt wo das Zug erstellt wurde.
   * @param sideFaceID
   *          Der ID der linken Seite zum Zeitpunkt wo das Zug erstellt wurde.
   * @throws IllegalArgumentException
   * 
   */
  public Turn(TurnType turnValue, int frontFaceID, int sideFaceID) throws IllegalArgumentException {

    if (frontFaceID > 5 || sideFaceID > 5) {
      throw new IllegalArgumentException("Der W&#252;rfel hat nicht mehr als 6 Seiten.");
    } else if (frontFaceID < 0 || sideFaceID < 0) {
      throw new IllegalArgumentException("Eine Seitenbezeichnung kann nicht negativ sein.");
    } else if (frontFaceID == sideFaceID) {
      throw new IllegalArgumentException("Die Vorderseite kann nicht gleichzeitig Seitenfl&#196;che sein!");
    }

    this.turn = turnValue;
    this.frontFaceID = frontFaceID;
    this.sideFaceID = sideFaceID;

  }

  /**
   * Das ist der zweite Konstruktor Methode ueber die man einen neuen Turn definieren kann. Sie wird benutzt, falls die
   * frontFaceID und sideFaceID des Turns der des aktuellen Wuerfels entsprechen. Ist der aktuelle W&#252;rfel nicht
   * gesetzt, wird eine NullpointerEception geworfen.
   * 
   * @param turnValue
   *          Das Wert des Zuges in die festgelegte Notation.
   */
  public Turn(TurnType turnValue) throws NullPointerException {

    this.turn = turnValue;

    Cube cube = TurnHandler.getCube(); // NullPointerException...
    this.frontFaceID = cube.getFrontID();
    this.sideFaceID = cube.getSideID();

  }

  /**
   * Diese Methode aendert den Wert des Turn Objektes in Abhaengigkeit von die frontFaceID und sideFaceID des Wuerfels
   * auf dem das Turn angewendet werden soll.
   * 
   * @param newFrontFaceID
   *          Die frontFaceID des Wuerfels fuer den ich das Turn konvertieren will.
   * @param newSideFaceID
   *          Die sideFaceID des Wuerfels fuer den ich das Turn konvertieren will.
   * 
   */
  public void convert(int newFrontFaceID, int newSideFaceID) {

    // If equal skip
    if ((newFrontFaceID == this.frontFaceID) && (newSideFaceID == this.sideFaceID)) {

      // System.out.println("no change in front face or side face ");
      return;
    } else {

      // uebersetzer
      int firstFace = faceRelationship(frontFaceID, sideFaceID, newFrontFaceID);
      int secondFace = faceRelationship(frontFaceID, sideFaceID, newSideFaceID);
      // System.out.println("Convert frontFace, sideFace: " + firstFace + ", "+ secondFace);

      TurnType newValue = TurnType.ENDOFLINE;

      switch (this.turn) {
      case F:
        newValue = this.tanslateF(firstFace, secondFace);
        break;
      case FPRIME:
        newValue = this.tanslateFPRIME(firstFace, secondFace);
        break;
      case L:
        newValue = this.tanslateL(firstFace, secondFace);
        break;
      case LPRIME:
        newValue = this.tanslateLPRIME(firstFace, secondFace);
        break;
      case R:
        newValue = this.tanslateR(firstFace, secondFace);
        break;
      case RPRIME:
        newValue = this.tanslateRPRIME(firstFace, secondFace);
        break;
      case B:
        newValue = this.tanslateB(firstFace, secondFace);
        break;
      case BPRIME:
        newValue = this.tanslateBPRIME(firstFace, secondFace);
        break;
      case U:
        newValue = this.tanslateU(firstFace, secondFace);
        break;
      case UPRIME:
        newValue = this.tanslateUPRIME(firstFace, secondFace);
        break;
      case D:
        newValue = this.tanslateD(firstFace, secondFace);
        break;
      case DPRIME:
        newValue = this.tanslateDPRIME(firstFace, secondFace);
        break;
      case M:
        newValue = this.tanslateM(firstFace, secondFace);
        break;
      case MPRIME:
        newValue = this.tanslateMPRIME(firstFace, secondFace);
        break;
      case E:
        newValue = this.tanslateE(firstFace, secondFace);
        break;
      case EPRIME:
        newValue = this.tanslateEPRIME(firstFace, secondFace);
        break;
      case S:
        newValue = this.tanslateS(firstFace, secondFace);
        break;
      case SPRIME:
        newValue = this.tanslateSPRIME(firstFace, secondFace);
        break;
      case ROTX:
        newValue = this.tanslateROTX(firstFace, secondFace);
        break;
      case ROTXPRIME:
        newValue = this.tanslateROTXPRIME(firstFace, secondFace);
        break;
      case ROTY:
        newValue = this.tanslateROTY(firstFace, secondFace);
        break;
      case ROTYPRIME:
        newValue = this.tanslateROTYPRIME(firstFace, secondFace);
        break;
      case ROTZ:
        newValue = this.tanslateROTZ(firstFace, secondFace);
        break;
      case ROTZPRIME:
        newValue = this.tanslateROTZPRIME(firstFace, secondFace);
        break;
      }

      // set Turntype
      this.turn = newValue;
      this.frontFaceID = newFrontFaceID;
      this.sideFaceID = newSideFaceID;

    }

  }

  /*
   * Die folgenden Hilfsmethoden dienen zur Konvertierung der spezifischen TurnType-Attribute eines Turn-Objektes. Dabei
   * wird zuerst ueberprueft, welche ID die erste Seite hat; und anhand dieser Information kann dann mit der ID der *
   * zweiten Seite ein eindeutiges, neues TurnType-Attribut zuordnen. Im Prinzip muss man einfach viele Moegliche
   * Kombinationen abfragen und den passenden TurnType finden.
   */

  /*
   * Uebersetzt F.
   */
  private TurnType tanslateF(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      translated = TurnType.F;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.B;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.L;
        break;
      case Constants.UP:
        translated = TurnType.U;
        break;
      case Constants.BACK:
        translated = TurnType.R;
        break;
      case Constants.DOWN:
        translated = TurnType.D;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.L;
        break;
      case Constants.UP:
        translated = TurnType.D;
        break;
      case Constants.BACK:
        translated = TurnType.R;
        break;
      case Constants.DOWN:
        translated = TurnType.U;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.L;
        break;
      case Constants.LEFT:
        translated = TurnType.D;
        break;
      case Constants.BACK:
        translated = TurnType.R;
        break;
      case Constants.RIGHT:
        translated = TurnType.U;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.L;
        break;
      case Constants.LEFT:
        translated = TurnType.U;
        break;
      case Constants.BACK:
        translated = TurnType.R;
        break;
      case Constants.RIGHT:
        translated = TurnType.D;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find F");
    }
    return translated;
  }

  /*
   * Uebersetzt FPRIME.
   */
  private TurnType tanslateFPRIME(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      translated = TurnType.FPRIME;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.BPRIME;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.LPRIME;
        break;
      case Constants.UP:
        translated = TurnType.UPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.RPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.DPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.LPRIME;
        break;
      case Constants.UP:
        translated = TurnType.DPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.RPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.UPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.LPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.DPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.RPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.UPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.LPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.UPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.RPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.DPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find FPRIME");
    }

    return translated;
  }

  /*
   * Uebersetzt L.
   */
  private TurnType tanslateL(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.L;
        break;
      case Constants.UP:
        translated = TurnType.D;
        break;
      case Constants.RIGHT:
        translated = TurnType.R;
        break;
      case Constants.DOWN:
        translated = TurnType.U;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.L;
        break;
      case Constants.UP:
        translated = TurnType.U;
        break;
      case Constants.RIGHT:
        translated = TurnType.R;
        break;
      case Constants.DOWN:
        translated = TurnType.D;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.F;
    } else if (firstFace == Constants.RIGHT) {
      translated = TurnType.B;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.U;
        break;
      case Constants.LEFT:
        translated = TurnType.L;
        break;
      case Constants.BACK:
        translated = TurnType.D;
        break;
      case Constants.RIGHT:
        translated = TurnType.R;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.D;
        break;
      case Constants.LEFT:
        translated = TurnType.L;
        break;
      case Constants.BACK:
        translated = TurnType.U;
        break;
      case Constants.RIGHT:
        translated = TurnType.R;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find L");
    }
    return translated;
  }

  /*
   * Uebersetzt LPRIME.
   */
  private TurnType tanslateLPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.LPRIME;
        break;
      case Constants.UP:
        translated = TurnType.DPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.RPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.UPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.LPRIME;
        break;
      case Constants.UP:
        translated = TurnType.UPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.RPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.DPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {

      translated = TurnType.FPRIME;
    } else if (firstFace == Constants.RIGHT) {

      translated = TurnType.BPRIME;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.UPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.LPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.DPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.RPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.DPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.LPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.UPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.RPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find LPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt R.
   */
  private TurnType tanslateR(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.R;
        break;
      case Constants.UP:
        translated = TurnType.U;
        break;
      case Constants.RIGHT:
        translated = TurnType.L;
        break;
      case Constants.DOWN:
        translated = TurnType.D;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.R;
        break;
      case Constants.UP:
        translated = TurnType.D;
        break;
      case Constants.RIGHT:
        translated = TurnType.L;
        break;
      case Constants.DOWN:
        translated = TurnType.U;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.B;
    } else if (firstFace == Constants.RIGHT) {
      translated = TurnType.F;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.D;
        break;
      case Constants.LEFT:
        translated = TurnType.R;
        break;
      case Constants.BACK:
        translated = TurnType.U;
        break;
      case Constants.RIGHT:
        translated = TurnType.L;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.U;
        break;
      case Constants.LEFT:
        translated = TurnType.R;
        break;
      case Constants.BACK:
        translated = TurnType.D;
        break;
      case Constants.RIGHT:
        translated = TurnType.L;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find R");
    }
    return translated;
  }

  /*
   * Uebersetzt RPRIME.
   */
  private TurnType tanslateRPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.RPRIME;
        break;
      case Constants.UP:
        translated = TurnType.UPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.LPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.DPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.RPRIME;
        break;
      case Constants.UP:
        translated = TurnType.DPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.LPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.UPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {

      translated = TurnType.BPRIME;
    } else if (firstFace == Constants.RIGHT) {

      translated = TurnType.FPRIME;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.DPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.RPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.UPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.LPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.UPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.RPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.DPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.LPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find RPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt B.
   */
  private TurnType tanslateB(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      translated = TurnType.B;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.F;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.R;
        break;
      case Constants.UP:
        translated = TurnType.D;
        break;
      case Constants.BACK:
        translated = TurnType.L;
        break;
      case Constants.DOWN:
        translated = TurnType.U;
        break;
      }
      return translated;
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.R;
        break;
      case Constants.UP:
        translated = TurnType.U;
        break;
      case Constants.BACK:
        translated = TurnType.L;
        break;
      case Constants.DOWN:
        translated = TurnType.D;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.R;
        break;
      case Constants.LEFT:
        translated = TurnType.U;
        break;
      case Constants.BACK:
        translated = TurnType.L;
        break;
      case Constants.RIGHT:
        translated = TurnType.D;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.R;
        break;
      case Constants.LEFT:
        translated = TurnType.D;
        break;
      case Constants.BACK:
        translated = TurnType.L;
        break;
      case Constants.RIGHT:
        translated = TurnType.U;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find B");
    }
    return translated;
  }

  /*
   * Uebersetzt BPRIME.
   */
  private TurnType tanslateBPRIME(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      translated = TurnType.BPRIME;
    } else if (firstFace == Constants.BACK) {

      translated = TurnType.FPRIME;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.RPRIME;
        break;
      case Constants.UP:
        translated = TurnType.DPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.LPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.UPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.RPRIME;
        break;
      case Constants.UP:
        translated = TurnType.UPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.LPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.DPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.RPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.UPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.LPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.DPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.RPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.DPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.LPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.UPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find BPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt U.
   */
  private TurnType tanslateU(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.U;
        break;
      case Constants.UP:
        translated = TurnType.L;
        break;
      case Constants.RIGHT:
        translated = TurnType.D;
        break;
      case Constants.DOWN:
        translated = TurnType.R;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.D;
        break;
      case Constants.UP:
        translated = TurnType.L;
        break;
      case Constants.RIGHT:
        translated = TurnType.U;
        break;
      case Constants.DOWN:
        translated = TurnType.R;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.D;
        break;
      case Constants.UP:
        translated = TurnType.L;
        break;
      case Constants.BACK:
        translated = TurnType.U;
        break;
      case Constants.DOWN:
        translated = TurnType.R;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.U;
        break;
      case Constants.UP:
        translated = TurnType.L;
        break;
      case Constants.BACK:
        translated = TurnType.D;
        break;
      case Constants.DOWN:
        translated = TurnType.R;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.F;
    } else if (firstFace == Constants.DOWN) {

      translated = TurnType.B;
    } else {
      System.out.println("ERROR couldn't find U");
    }
    return translated;
  }

  /*
   * Uebersetzt UPRIME.
   */
  private TurnType tanslateUPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.UPRIME;
        break;
      case Constants.UP:
        translated = TurnType.LPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.DPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.RPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.DPRIME;
        break;
      case Constants.UP:
        translated = TurnType.LPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.UPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.RPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.DPRIME;
        break;
      case Constants.UP:
        translated = TurnType.LPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.UPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.RPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.UPRIME;
        break;
      case Constants.UP:
        translated = TurnType.LPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.DPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.RPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.FPRIME;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.BPRIME;
    } else {
      System.out.println("ERROR couldn't find UPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt D.
   */
  private TurnType tanslateD(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.D;
        break;
      case Constants.UP:
        translated = TurnType.R;
        break;
      case Constants.RIGHT:
        translated = TurnType.U;
        break;
      case Constants.DOWN:
        translated = TurnType.L;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.U;
        break;
      case Constants.UP:
        translated = TurnType.R;
        break;
      case Constants.RIGHT:
        translated = TurnType.D;
        break;
      case Constants.DOWN:
        translated = TurnType.L;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.U;
        break;
      case Constants.UP:
        translated = TurnType.R;
        break;
      case Constants.BACK:
        translated = TurnType.D;
        break;
      case Constants.DOWN:
        translated = TurnType.L;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.D;
        break;
      case Constants.UP:
        translated = TurnType.R;
        break;
      case Constants.BACK:
        translated = TurnType.U;
        break;
      case Constants.DOWN:
        translated = TurnType.L;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.B;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.F;
    } else {
      System.out.println("ERROR couldn't find D");
    }
    return translated;
  }

  /*
   * Uebersetzt DPRIME.
   */
  private TurnType tanslateDPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.DPRIME;
        break;
      case Constants.UP:
        translated = TurnType.RPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.UPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.LPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.UPRIME;
        break;
      case Constants.UP:
        translated = TurnType.RPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.DPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.LPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.UPRIME;
        break;
      case Constants.UP:
        translated = TurnType.RPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.DPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.LPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.DPRIME;
        break;
      case Constants.UP:
        translated = TurnType.RPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.UPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.LPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.BPRIME;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.FPRIME;
    } else {
      System.out.println("ERROR couldn't find DPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt M.
   */
  private TurnType tanslateM(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.M;
        break;
      case Constants.UP:
        translated = TurnType.E;
        break;
      case Constants.RIGHT:
        translated = TurnType.MPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.EPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.M;
        break;
      case Constants.UP:
        translated = TurnType.EPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.MPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.E;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.S;
    } else if (firstFace == Constants.RIGHT) {
      translated = TurnType.SPRIME;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.EPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.M;
        break;
      case Constants.BACK:
        translated = TurnType.E;
        break;
      case Constants.RIGHT:
        translated = TurnType.MPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.E;
        break;
      case Constants.LEFT:
        translated = TurnType.M;
        break;
      case Constants.BACK:
        translated = TurnType.EPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.MPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find M");
    }
    return translated;
  }

  /*
   * Uebersetzt MPRIME.
   */
  private TurnType tanslateMPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.MPRIME;
        break;
      case Constants.UP:
        translated = TurnType.EPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.M;
        break;
      case Constants.DOWN:
        translated = TurnType.E;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.MPRIME;
        break;
      case Constants.UP:
        translated = TurnType.E;
        break;
      case Constants.RIGHT:
        translated = TurnType.M;
        break;
      case Constants.DOWN:
        translated = TurnType.EPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.SPRIME;
    } else if (firstFace == Constants.RIGHT) {
      translated = TurnType.S;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.E;
        break;
      case Constants.LEFT:
        translated = TurnType.MPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.EPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.M;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.EPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.MPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.E;
        break;
      case Constants.RIGHT:
        translated = TurnType.M;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find MPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt E.
   */
  private TurnType tanslateE(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.E;
        break;
      case Constants.UP:
        translated = TurnType.MPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.EPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.M;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.EPRIME;
        break;
      case Constants.UP:
        translated = TurnType.MPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.E;
        break;
      case Constants.DOWN:
        translated = TurnType.M;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.EPRIME;
        break;
      case Constants.UP:
        translated = TurnType.MPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.E;
        break;
      case Constants.DOWN:
        translated = TurnType.M;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.E;
        break;
      case Constants.UP:
        translated = TurnType.MPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.EPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.M;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.SPRIME;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.S;
    } else {
      System.out.println("ERROR couldn't find E");
    }
    return translated;
  }

  /*
   * Uebersetzt EPRIME.
   */
  private TurnType tanslateEPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.EPRIME;
        break;
      case Constants.UP:
        translated = TurnType.M;
        break;
      case Constants.RIGHT:
        translated = TurnType.E;
        break;
      case Constants.DOWN:
        translated = TurnType.MPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.E;
        break;
      case Constants.UP:
        translated = TurnType.M;
        break;
      case Constants.RIGHT:
        translated = TurnType.EPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.MPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.E;
        break;
      case Constants.UP:
        translated = TurnType.M;
        break;
      case Constants.BACK:
        translated = TurnType.EPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.MPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.EPRIME;
        break;
      case Constants.UP:
        translated = TurnType.M;
        break;
      case Constants.BACK:
        translated = TurnType.E;
        break;
      case Constants.DOWN:
        translated = TurnType.MPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.S;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.SPRIME;
    } else {
      System.out.println("ERROR couldn't find EPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt S.
   */
  private TurnType tanslateS(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      translated = TurnType.S;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.SPRIME;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.M;
        break;
      case Constants.UP:
        translated = TurnType.EPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.MPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.E;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.M;
        break;
      case Constants.UP:
        translated = TurnType.E;
        break;
      case Constants.BACK:
        translated = TurnType.MPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.EPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.M;
        break;
      case Constants.LEFT:
        translated = TurnType.E;
        break;
      case Constants.BACK:
        translated = TurnType.MPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.EPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.M;
        break;
      case Constants.LEFT:
        translated = TurnType.EPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.MPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.E;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find S");
    }
    return translated;
  }

  /*
   * Uebersetzt SPRIME.
   */
  private TurnType tanslateSPRIME(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      translated = TurnType.SPRIME;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.S;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.MPRIME;
        break;
      case Constants.UP:
        translated = TurnType.E;
        break;
      case Constants.BACK:
        translated = TurnType.M;
        break;
      case Constants.DOWN:
        translated = TurnType.EPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.MPRIME;
        break;
      case Constants.UP:
        translated = TurnType.EPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.M;
        break;
      case Constants.DOWN:
        translated = TurnType.E;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.MPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.EPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.M;
        break;
      case Constants.RIGHT:
        translated = TurnType.E;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.MPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.E;
        break;
      case Constants.BACK:
        translated = TurnType.M;
        break;
      case Constants.RIGHT:
        translated = TurnType.EPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find SPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTX.
   */
  private TurnType tanslateROTX(int firstFace, int secondFace) {

    TurnType translated = null;

    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTX;
        break;
      case Constants.UP:
        translated = TurnType.ROTY;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTX;
        break;
      case Constants.UP:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTY;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.ROTZPRIME;
    } else if (firstFace == Constants.RIGHT) {

      translated = TurnType.ROTZ;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTX;
        break;
      case Constants.BACK:
        translated = TurnType.ROTY;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTY;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTX;
        break;
      case Constants.BACK:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find ROTX");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTXPRIME.
   */
  private TurnType tanslateROTXPRIME(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTX;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTY;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTY;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTX;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      translated = TurnType.ROTZ;
    } else if (firstFace == Constants.RIGHT) {
      translated = TurnType.ROTZPRIME;
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTY;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTX;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTY;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTX;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find ROTXPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTY.
   */
  private TurnType tanslateROTY(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTY;
        break;
      case Constants.UP:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTX;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTY;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTX;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTY;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTX;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTY;
        break;
      case Constants.UP:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTX;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.ROTZ;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.ROTZPRIME;
    } else {
      System.out.println("ERROR couldn't find ROTY");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTYPRIME.
   */
  private TurnType tanslateROTYPRIME(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTX;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTY;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else if (firstFace == Constants.BACK) {
      switch (secondFace) {
      case Constants.LEFT:
        translated = TurnType.ROTY;
        break;
      case Constants.UP:
        translated = TurnType.ROTX;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTY;
        break;
      case Constants.UP:
        translated = TurnType.ROTX;
        break;
      case Constants.BACK:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTX;
        break;
      case Constants.BACK:
        translated = TurnType.ROTY;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTXPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      translated = TurnType.ROTZPRIME;
    } else if (firstFace == Constants.DOWN) {
      translated = TurnType.ROTZ;
    } else {
      System.out.println("ERROR couldn't find ROTYPRIME");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTZ.
   */
  private TurnType tanslateROTZ(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      translated = TurnType.ROTZ;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.ROTZPRIME;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTY;
        break;
      case Constants.BACK:
        translated = TurnType.ROTX;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.UP:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTX;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTY;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTX;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTY;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTY;
        break;
      case Constants.BACK:
        translated = TurnType.ROTX;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find ROTZ");
    }
    return translated;
  }

  /*
   * Uebersetzt ROTZPRIME.
   */
  private TurnType tanslateROTZPRIME(int firstFace, int secondFace) {
    TurnType translated = null;
    if (firstFace == Constants.FRONT) {
      translated = TurnType.ROTZPRIME;
    } else if (firstFace == Constants.BACK) {
      translated = TurnType.ROTZ;
    } else if (firstFace == Constants.LEFT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTX;
        break;
      case Constants.UP:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTY;
        break;
      }
    } else if (firstFace == Constants.RIGHT) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTX;
        break;
      case Constants.UP:
        translated = TurnType.ROTY;
        break;
      case Constants.BACK:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.DOWN:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else if (firstFace == Constants.UP) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTX;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTY;
        break;
      case Constants.BACK:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTYPRIME;
        break;
      }
    } else if (firstFace == Constants.DOWN) {
      switch (secondFace) {
      case Constants.FRONT:
        translated = TurnType.ROTX;
        break;
      case Constants.LEFT:
        translated = TurnType.ROTYPRIME;
        break;
      case Constants.BACK:
        translated = TurnType.ROTXPRIME;
        break;
      case Constants.RIGHT:
        translated = TurnType.ROTY;
        break;
      }
    } else {
      System.out.println("ERROR couldn't find ROTZPRIME");
    }
    return translated;
  }

  /*
	 * 
	 *
	 */
  private int faceRelationship(int oldFront, int oldLeft, int newSide) {
    int result = 0;
    if ((oldFront == 0) && (oldLeft == 1)) {
      switch (newSide) {
      case 0:
        result = Constants.FRONT;
        break;
      case 1:
        result = Constants.LEFT;
        break;
      case 2:
        result = Constants.BACK;
        break;
      case 3:
        result = Constants.RIGHT;
        break;
      case 4:
        result = Constants.DOWN;
        break;
      case 5:
        result = Constants.UP;
        break;
      }
    } else if ((oldFront == 0) && (oldLeft == 3)) {
      switch (newSide) {
      case 0:
        result = Constants.FRONT;
        break;
      case 1:
        result = Constants.RIGHT;
        break;
      case 2:
        result = Constants.BACK;
        break;
      case 3:
        result = Constants.LEFT;
        break;
      case 4:
        result = Constants.UP;
        break;
      case 5:
        result = Constants.DOWN;
        break;
      }
    } else if ((oldFront == 0) && (oldLeft == 4)) {
      switch (newSide) {
      case 0:
        result = Constants.FRONT;
        break;
      case 1:
        result = Constants.UP;
        break;
      case 2:
        result = Constants.BACK;
        break;
      case 3:
        result = Constants.DOWN;
        break;
      case 4:
        result = Constants.LEFT;
        break;
      case 5:
        result = Constants.RIGHT;
        break;
      }
    } else if ((oldFront == 0) && (oldLeft == 5)) {
      switch (newSide) {
      case 0:
        result = Constants.FRONT;
        break;
      case 1:
        result = Constants.DOWN;
        break;
      case 2:
        result = Constants.BACK;
        break;
      case 3:
        result = Constants.UP;
        break;
      case 4:
        result = Constants.RIGHT;
        break;
      case 5:
        result = Constants.LEFT;
        break;
      }
    } else if ((oldFront == 1) && (oldLeft == 0)) {
      switch (newSide) {
      case 0:
        result = Constants.LEFT;
        break;
      case 1:
        result = Constants.FRONT;
        break;
      case 2:
        result = Constants.RIGHT;
        break;
      case 3:
        result = Constants.BACK;
        break;
      case 4:
        result = Constants.UP;
        break;
      case 5:
        result = Constants.DOWN;
        break;
      }
    } else if ((oldFront == 1) && (oldLeft == 2)) {
      switch (newSide) {
      case 0:
        result = Constants.RIGHT;
        break;
      case 1:
        result = Constants.FRONT;
        break;
      case 2:
        result = Constants.LEFT;
        break;
      case 3:
        result = Constants.BACK;
        break;
      case 4:
        result = Constants.DOWN;
        break;
      case 5:
        result = Constants.UP;
        break;
      }
    } else if ((oldFront == 1) && (oldLeft == 4)) {
      switch (newSide) {
      case 0:
        result = Constants.DOWN;
        break;
      case 1:
        result = Constants.FRONT;
        break;
      case 2:
        result = Constants.UP;
        break;
      case 3:
        result = Constants.BACK;
        break;
      case 4:
        result = Constants.LEFT;
        break;
      case 5:
        result = Constants.RIGHT;
        break;
      }
    } else if ((oldFront == 1) && (oldLeft == 5)) {
      switch (newSide) {
      case 0:
        result = Constants.UP;
        break;
      case 1:
        result = Constants.FRONT;
        break;
      case 2:
        result = Constants.DOWN;
        break;
      case 3:
        result = Constants.BACK;
        break;
      case 4:
        result = Constants.RIGHT;
        break;
      case 5:
        result = Constants.LEFT;
        break;
      }
    } else if ((oldFront == 2) && (oldLeft == 1)) {
      switch (newSide) {
      case 0:
        result = Constants.BACK;
        break;
      case 1:
        result = Constants.LEFT;
        break;
      case 2:
        result = Constants.FRONT;
        break;
      case 3:
        result = Constants.RIGHT;
        break;
      case 4:
        result = Constants.UP;
        break;
      case 5:
        result = Constants.DOWN;
        break;
      }
    } else if ((oldFront == 2) && (oldLeft == 3)) {
      switch (newSide) {
      case 0:
        result = Constants.BACK;
        break;
      case 1:
        result = Constants.RIGHT;
        break;
      case 2:
        result = Constants.FRONT;
        break;
      case 3:
        result = Constants.LEFT;
        break;
      case 4:
        result = Constants.DOWN;
        break;
      case 5:
        result = Constants.UP;
        break;
      }
    } else if ((oldFront == 2) && (oldLeft == 4)) {
      switch (newSide) {
      case 0:
        result = Constants.BACK;
        break;
      case 1:
        result = Constants.DOWN;
        break;
      case 2:
        result = Constants.FRONT;
        break;
      case 3:
        result = Constants.UP;
        break;
      case 4:
        result = Constants.LEFT;
        break;
      case 5:
        result = Constants.RIGHT;
        break;
      }
    } else if ((oldFront == 2) && (oldLeft == 5)) {
      switch (newSide) {
      case 0:
        result = Constants.BACK;
        break;
      case 1:
        result = Constants.UP;
        break;
      case 2:
        result = Constants.FRONT;
        break;
      case 3:
        result = Constants.DOWN;
        break;
      case 4:
        result = Constants.RIGHT;
        break;
      case 5:
        result = Constants.LEFT;
        break;
      }
    } else if ((oldFront == 3) && (oldLeft == 0)) {
      switch (newSide) {
      case 0:
        result = Constants.LEFT;
        break;
      case 1:
        result = Constants.BACK;
        break;
      case 2:
        result = Constants.RIGHT;
        break;
      case 3:
        result = Constants.FRONT;
        break;
      case 4:
        result = Constants.DOWN;
        break;
      case 5:
        result = Constants.UP;
        break;
      }
    } else if ((oldFront == 3) && (oldLeft == 2)) {
      switch (newSide) {
      case 0:
        result = Constants.RIGHT;
        break;
      case 1:
        result = Constants.BACK;
        break;
      case 2:
        result = Constants.LEFT;
        break;
      case 3:
        result = Constants.FRONT;
        break;
      case 4:
        result = Constants.UP;
        break;
      case 5:
        result = Constants.DOWN;
        break;
      }
    } else if ((oldFront == 3) && (oldLeft == 4)) {
      switch (newSide) {
      case 0:
        result = Constants.UP;
        break;
      case 1:
        result = Constants.BACK;
        break;
      case 2:
        result = Constants.DOWN;
        break;
      case 3:
        result = Constants.FRONT;
        break;
      case 4:
        result = Constants.LEFT;
        break;
      case 5:
        result = Constants.RIGHT;
        break;
      }
    } else if ((oldFront == 3) && (oldLeft == 5)) {
      switch (newSide) {
      case 0:
        result = Constants.DOWN;
        break;
      case 1:
        result = Constants.BACK;
        break;
      case 2:
        result = Constants.UP;
        break;
      case 3:
        result = Constants.FRONT;
        break;
      case 4:
        result = Constants.RIGHT;
        break;
      case 5:
        result = Constants.LEFT;
        break;
      }
    } else if ((oldFront == 4) && (oldLeft == 0)) {
      switch (newSide) {
      case 0:
        result = Constants.LEFT;
        break;
      case 1:
        result = Constants.DOWN;
        break;
      case 2:
        result = Constants.RIGHT;
        break;
      case 3:
        result = Constants.UP;
        break;
      case 4:
        result = Constants.FRONT;
        break;
      case 5:
        result = Constants.BACK;
        break;
      }
    } else if ((oldFront == 4) && (oldLeft == 1)) {
      switch (newSide) {
      case 0:
        result = Constants.UP;
        break;
      case 1:
        result = Constants.LEFT;
        break;
      case 2:
        result = Constants.DOWN;
        break;
      case 3:
        result = Constants.RIGHT;
        break;
      case 4:
        result = Constants.FRONT;
        break;
      case 5:
        result = Constants.BACK;
        break;
      }
    } else if ((oldFront == 4) && (oldLeft == 2)) {
      switch (newSide) {
      case 0:
        result = Constants.RIGHT;
        break;
      case 1:
        result = Constants.UP;
        break;
      case 2:
        result = Constants.LEFT;
        break;
      case 3:
        result = Constants.DOWN;
        break;
      case 4:
        result = Constants.FRONT;
        break;
      case 5:
        result = Constants.BACK;
        break;
      }
    } else if ((oldFront == 4) && (oldLeft == 3)) {
      switch (newSide) {
      case 0:
        result = Constants.DOWN;
        break;
      case 1:
        result = Constants.RIGHT;
        break;
      case 2:
        result = Constants.UP;
        break;
      case 3:
        result = Constants.LEFT;
        break;
      case 4:
        result = Constants.FRONT;
        break;
      case 5:
        result = Constants.BACK;
        break;
      }
    } else if ((oldFront == 4) && (oldLeft == 1)) {
      switch (newSide) {
      case 0:
        result = Constants.UP;
        break;
      case 1:
        result = Constants.LEFT;
        break;
      case 2:
        result = Constants.DOWN;
        break;
      case 3:
        result = Constants.RIGHT;
        break;
      case 4:
        result = Constants.FRONT;
        break;
      case 5:
        result = Constants.BACK;
        break;
      }
    } else if ((oldFront == 5) && (oldLeft == 0)) {
      switch (newSide) {
      case 0:
        result = Constants.LEFT;
        break;
      case 1:
        result = Constants.UP;
        break;
      case 2:
        result = Constants.RIGHT;
        break;
      case 3:
        result = Constants.DOWN;
        break;
      case 4:
        result = Constants.BACK;
        break;
      case 5:
        result = Constants.FRONT;
        break;
      }
    } else if ((oldFront == 5) && (oldLeft == 1)) {
      switch (newSide) {
      case 0:
        result = Constants.DOWN;
        break;
      case 1:
        result = Constants.LEFT;
        break;
      case 2:
        result = Constants.UP;
        break;
      case 3:
        result = Constants.RIGHT;
        break;
      case 4:
        result = Constants.BACK;
        break;
      case 5:
        result = Constants.FRONT;
        break;
      }
    } else if ((oldFront == 5) && (oldLeft == 2)) {
      switch (newSide) {
      case 0:
        result = Constants.RIGHT;
        break;
      case 1:
        result = Constants.DOWN;
        break;
      case 2:
        result = Constants.LEFT;
        break;
      case 3:
        result = Constants.UP;
        break;
      case 4:
        result = Constants.BACK;
        break;
      case 5:
        result = Constants.FRONT;
        break;
      }
    } else if ((oldFront == 5) && (oldLeft == 3)) {
      switch (newSide) {
      case 0:
        result = Constants.UP;
        break;
      case 1:
        result = Constants.RIGHT;
        break;
      case 2:
        result = Constants.DOWN;
        break;
      case 3:
        result = Constants.LEFT;
        break;
      case 4:
        result = Constants.BACK;
        break;
      case 5:
        result = Constants.FRONT;
        break;
      }
    } else {
      result = -1;
      System.out.println("ERROR couldn't find face relationship");
    }
    return result;

  }

  /**
   * ueberschreibt das Wert des Turns auf das entgegengesetzte.
   */
  public void invert() {
    turn = turn.getInverse();
  }

  /**
   * Gibt das Wert des Turnobjektes zurueck.
   * 
   * @return Das turn Attribut.
   */
  public TurnType getValue() {
    return turn;
  }

  /**
   * Gibt die numerische Bezeichnung der Vorderseite zur&#252;ck. Diese liegt zwischen 0 und 5.
   * 
   * @return die numeriche Bezeichnung der Vorderseite.
   */
  public int getFrontFaceID() {
    return frontFaceID;
  }

  /**
   * Setzt die numerische Bezeichnung der Vorderseite neu. Diese muss zwischen 0 und 5 liegen.
   * 
   * @param frontFaceID
   *          die numerische Bezeichnung der Vorderseite.
   */
  public void setFrontFaceID(int frontFaceID) throws IllegalArgumentException {
    if (frontFaceID < 0 || frontFaceID > 5) {
      throw new IllegalArgumentException("Die Vorderseite muss zwischen 0 und 5 liegen!");
    }
    this.frontFaceID = frontFaceID;
  }

  /**
   * Gibt die numerische Bezeichnung der Seitenfl&#196;che zur&#252;ck. Diese liegt zwischen 0 und 5.
   * 
   * @return die numeriche Bezeichnung der Seitenfl&#196;che.
   */
  public int getSideFaceID() {
    return sideFaceID;
  }

  /**
   * Setzt die numerische Bezeichnung der Seitenfl&#196;che neu. Diese muss zwischen 0 und 5 liegen.
   * 
   * @param sideFaceID
   *          die numerische Bezeichnung der Seitenfl&#196;che.
   */
  public void setSideFaceID(int sideFaceID) throws IllegalArgumentException {
    if (sideFaceID < 0 || sideFaceID > 5) {
      throw new IllegalArgumentException("Die Seitenfl&#196;che muss zwischen 0 und 5 liegen!");
    }
    this.sideFaceID = sideFaceID;
  }

}
