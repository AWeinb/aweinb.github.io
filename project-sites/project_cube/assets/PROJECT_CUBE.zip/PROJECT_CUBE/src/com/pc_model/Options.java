package com.pc_model;

import android.app.Activity;
import android.graphics.Typeface;
import android.util.Log;

import com.pc_controller.FileHandler;
import com.pc_util.Constants;

/**
 * Stellt eine Schnittstelle fuer die Spieloptionen des Zauberwuerfels bereit. Speichert die Animationsgeschwindigkeit,
 * die Sprache, die Texturen der sechs Wuerfelflaechen, ob der Sound abgespielt werden soll, ob das Spiel im
 * Wettkampfmodus stattfindet und die Anzahl der Wuerfelverdrehungen am Spielbeginn.
 * 
 * Das Optionenobjekt ist ein Singleton.
 */
public class Options {
  /*
   * Speichert die Animationsgeschwindigkeit. Enthaelt einen Wert zwischen 0 und 100 (%). Standard ist '50'.
   */
  private int animationSpeed;

  // Enthaelt die aktuelle Sprache. Standard ist Englisch.
  private String language;

  // Enthaelt das aktuelle Farbthema.
  private String theme;
  
  // Enthaelt den aktuellen Grafikfilter.
  private String filter;

  private String font;
  private Typeface fontDY;
  private Typeface fontAM;
  /*
   * Enthaelt die eingestellten Wuerfelfarben. Die Standardinitialisierung entspricht den (Alpha)RGB-Werten der Farben
   * gruen, rot, weiss, orange, gelb, blau.
   * 
   * Up, Down, Front, Back, Left, Right
   */
  private int[] colours = { Constants.WHI, Constants.YEL, Constants.BLU, Constants.GRE, Constants.RED, Constants.ORA };

  /* Die aktuell eingestellte Wuerfelgroesse */
  private static int cubeSize;

  /*
   * Gibt die Anzahl der Zuege an, um die der Wuerfel beim Spielstart verdreht werden soll. Standard ist '20'.
   */
  private Integer numberOfMoves;


  /* Enthaelt die einzige Instanz des Optionen-Objekts. Ist anfangs null. */
  private static Options instance = null;

  private static final String OPTIONS_ERROR_1 = "FileHandler: Fehler beim Konvertieren der ints waehrend der Umwandlung der OPTIONS-Datei";
  private static final String OPTIONS_ERROR_2 = "FileHandler: OPTIONS-Datei enstpricht nicht dem korrekten Format.";

  /*
   * Der private Konstruktor vermeidet das Initialisieren des Optionen-Objekts von aussen.
   */
  private Options() {
    String[] settings = FileHandler.loadOptions();

    if (settings == null) {
      setAnimationSpeed(Constants.ANIM_SPEED_STANDARD);
      setCubeSize(3);
      setLanguage(Constants.NOLANGUAGE);
      setTheme(Constants.NOTHEME);
      setFilter(Constants.NOFILTER);
      setFont(Constants.FONT_AMERIKA);
      setNumberOfMoves(Constants.NUMBER_OF_MOVES);

      for (int i = 0; i < 6; i++) {
        setColour(colours[i], i);
      }

      FileHandler.storeOptions(this);

    } else {

      try {
        int size = Integer.parseInt(settings[0]);
        int animSpeed = Integer.parseInt(settings[1]);
        int numberOfMoves = Integer.parseInt(settings[2]);

        setCubeSize(size);
        setAnimationSpeed(animSpeed);
        setNumberOfMoves(numberOfMoves);

        for (int i = 0; i < 6; i++) {
          int colour = Integer.parseInt(settings[i + 3]);
          setColour(colour, i);
        }

        setLanguage(settings[9]);
        setTheme(settings[10]);
        setFilter(settings[11]);
        setFont(settings[12]);

      } catch (NumberFormatException e) {
        System.out.println(OPTIONS_ERROR_1 + e.getStackTrace());

      } catch (ArrayIndexOutOfBoundsException e) {
        System.out.println(OPTIONS_ERROR_2 + e.getStackTrace());
      }
    }
  }

  /**
   * Steht anstelle des Konstruktors. Vermeidet das Erstellen eines Optionen-Objekts von aussen. Gibt das einzige
   * Optionen-Instanz zurueck.
   * 
   * @return die einzige Instanz dieser Klasse
   */
  public static Options getOptionsInstance() {
    if (instance == null) {
      Log.v("PROJECTCUBE", "OPTIONS: NEW OPTIONS");
      instance = new Options();
    }
    return instance;
  }

  /**
   * Speichert die Wuerfelgroesse ab. Sie sollte groesser als 0 sein, sonst wird eine IllegalArgumentExcpetion geworfen.
   * 
   * @param cubeSize
   *          die Wuerfelgroesse
   * @throws IllegalArgumentException
   */
  public void setCubeSize(int cubeSize) throws IllegalArgumentException {

    if (cubeSize <= 0) {
      throw new IllegalArgumentException("Ein Wuerfel braucht mindestens eine Flaeche.");
    }
    Options.cubeSize = cubeSize;
  }

  /**
   * Gibt die gespeicherte Wuerfelgroesse zurueck.
   * 
   * @return die Wuerfelgroesse
   */
  public int getCubeSize() {
    return cubeSize;
  }

  /**
   * Gibt die aktuelle Sprache aus. Ist gleich dem Dateinamen der zugehoerigen Sprachdatei.
   * 
   * @return die aktuelle Sprache als String
   */
  public String getLanguage() {
    return this.language;
  }

  /**
   * Setzt die aktuelle Sprache. Wird ein leerer String oder null uebergeben, passiert nichts.
   * 
   * @param language
   *          die aktuelle Sprache.
   */
  public void setLanguage(String language) {
    if ((language == null) || language.equals("")) {
      return;
    }
    this.language = language;
  }

  /**
   * Gibt das aktuelle Farbthema zur�ck.
   * 
   * @return String des Themas
   */
  public String getTheme() {
    return theme;
  }

  /**
   * Setzt das aktuelle Farbthema.
   * 
   * @param theme String des Themas
   */
  public void setTheme(String theme) {
    this.theme = theme;
  }

  /**
   * Gibt den aktuellen Filter zur�ck.
   * 
   * @return String des Filters
   */
  public String getFilter() {
    return filter;
  }
  
  /**
   * Setzt den aktuellen Filter.
   * 
   * @param filter String des Filters
   */
  public void setFilter(String filter) {
    this.filter = filter;
  }
  
  /**
   * Gibt die aktuelle Schriftart aus.
   * 
   * @param font
   * 
   * @return die aktuelle Schriftart als String.
   */
  public String getActFont() {
    return this.font;
  }

  /**
   * Setzt die aktuelle Schriftart.
   * 
   * @param font
   *          die aktuelle Schriftart.
   */
  public void setFont(String font) {
    this.font = font;
  }

  /**
   * Gibt die aktuelle Schriftart zur�ck oder erstellt sie, falls noch nicht geschehen.
   * 
   * @param act
   *          Die aufrufende Activity.
   * @return Typeface
   */
  public Typeface getFont(Activity act) {
    Typeface ret = null;

    if (font == null)
      font = Constants.FONT_AMERIKA;

    if (font.equals(Constants.FONT_AMERIKA)) {
      ret = this.fontAM;

      if (ret == null) {
        ret = createFont(act);
      }

    } else if (font.equals(Constants.FONT_FAIRYCAKE)) {
      ret = this.fontDY;

      if (ret == null) {
        ret = createFont(act);
      }

    } else {
      ret = Typeface.DEFAULT;
    }

    return ret;
  }

  /*
   * Erstellt die Schriftart aus den Assets. WICHTIG: So wenig wie m�glich aufrufen! Sonst zu hoher Speicherverbrauch
   * (leak)
   */
  private Typeface createFont(Activity act) {
    Log.v("PROJECTCUBE", "OPTIONS: CREATEFONT() - PLUS MEMORY");
    Typeface ret = null;

    if (font.equals(Constants.FONT_AMERIKA)) {
      this.fontAM = Typeface.createFromAsset(act.getAssets(), font);
      ret = this.fontAM;

    } else if (font.equals(Constants.FONT_FAIRYCAKE)) {
      this.fontDY = Typeface.createFromAsset(act.getAssets(), font);
      ret = this.fontDY;
    }

    return ret;
  }

  /**
   * Setzt die Farbe auf der angegebenen Wuerfelseite. Die Seitenbezeichnung muss zwischen 0 und 5 liegen. Die farbe
   * muss in ARGB angegeben werden.
   * 
   * @param colour
   *          die gewuenschte Farbe als ARGB als Hex/Dezimal also zB -16711936 oder 0xFF0000FF fuer Blau
   * @param facenr
   *          die Seitennr, deren Farbe geaendert werden soll. Muss zwischen 1 und 6 liegen.
   * @throws IllegalArgumentException
   */
  public void setColour(int colour, int facenr) throws IllegalArgumentException {
    if ((facenr < 0) || (facenr > 5)) {
      throw new IllegalArgumentException("set Colour: Flaeche existiert nicht. facenr = " + facenr);
    }
    this.colours[facenr] = colour;
  }

  /**
   * Gibt die Farbe der gewuenschten Flaeche in dezimalem ARGB zurueck. Die Flaeche muss zwischen 0 und 5 liegen.
   * 
   * @param facenr
   *          die Seitennummer, deren Farbe abgefragt werden soll
   * @return die Farbe der angefragten Seite als dezimales ARGB
   * @throws IllegalArgumentException
   */
  public int getColour(int facenr) throws IllegalArgumentException {
    if ((facenr < 0) || (facenr > 5)) {
      throw new IllegalArgumentException("get Colour: Flaeche existiert nicht. facenr = " + facenr);
    }
    return this.colours[facenr];
  }

  /**
   * Gibt ein Array zurueck, in dem die Farben der Wuerfelflaechen als ARGB gespeichert sind. Die Indizes entsprechen
   * den Seiten des Wuerfels.
   * 
   * @return die Wuerfelfarben
   */
  public int[] getColours() {
    return this.colours;
  }

  /**
   * Setzt die ANzahl an Zuegen, um die der Wuerfel beim Spielstart verdreht werden soll. Sie sollte groesser als 0
   * sein.
   * 
   * @param nr
   *          Anzahl an Verdrehungen des Wuerfels
   * @throws IllegalArgumentException
   */
  public void setNumberOfMoves(int nr) throws IllegalArgumentException {
    if (nr < 0) {
      throw new IllegalArgumentException("Kann den Wuerfel nicht um eine negative Anzahl verdrehen.");
    }
    this.numberOfMoves = nr;
  }

  /**
   * Gibt die Anzahl an Verdrehungen zurueck, um die der Wuerfel beim Spielstart verdreht werden soll.
   * 
   * @return Anzahl an Verdrehungen des Wuerfels
   */
  public int getNumberOfMoves() {
    return this.numberOfMoves;
  }

  /**
   * Setzt die Animationsgeschwindigkeit in Prozent. Sollte ein Wert zwischen 0 und 100 (default) sein. Die obere Grenze
   * kann in Constants neu gesetzt werden.
   * 
   * @param speed
   *          die Animationsgeschwindigkeit in Prozent.
   * @return on die Animationsgeschwindigkeit erfolgreich gesetzt wurde.
   * @throws IllegalArgumentException
   */
  public void setAnimationSpeed(int speed) throws IllegalArgumentException {
    if (speed >= Constants.ANIM_SPEED_MIN && speed <= Constants.ANIM_SPEED_MAX) {
      this.animationSpeed = speed;

    } else {
      throw new IllegalArgumentException("ANimationsgeschwindigkeit konnte nicht eingestellt werden.");
    }
  }

  /**
   * Gibt die Animationsgeschwindigkeit in Prozent zurueck. Hat einen Wert zwischen 0 und 100.
   * 
   * @return die Animationsgeschwindigkeit in Prozent.
   */
  public int getAnimationSpeed() {
    return this.animationSpeed;
  }

}
