package com.pc_model;

import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;
import com.pc_util.Constants.Colour;

/**
 * Die Objekte dieser Klasse stellen Zauberwuerfel mit 6 Seiten dar, welche
 * durch spezifische Befehle beinflusst werden koennen, um Drehungen, etc.
 * auszufuehren.
 */
public class Cube {
	/**
	 * Vordere Seite des Wuerfels.
	 */
	private Face front;

	/**
	 * Rechte Seite des Wuerfels.
	 */
	private Face right;

	/**
	 * Hintere Seite des Wuerfels.
	 */
	private Face back;

	/**
	 * Linke Seite des Wuerfels.
	 */
	private Face left;

	/**
	 * Obere Seite des Wuerfels.
	 */
	private Face up;

	/**
	 * Untere Seite des Wuerfels.
	 */
	private Face down;

	/**
	 * Groesse des Wuerfels, spezifischer, die Kantenlaenge. Ein Wuerfel hat
	 * also die Groesse size*size*size.
	 */
	private int size;

	private CubeObserver viewObserver;

	private final String saveError = "Cube: SaveString entspricht nicht dem korrekten Format.";

	/**
	 * Konstruktor der Klasse mit dem man einen neuen, unverdrehten Wuerfel
	 * erzeugen kann. Die sechs urspruenglichen Seiten sind einfarbig
	 * verschieden belegt. front ist rot, right ist weiss, back ist orange, left
	 * ist gelb, up gruen und down blau.
	 * 
	 * @param size
	 *            Groesse des Wuerfels.
	 */
	public Cube(int size) {
		createCube(size);
	}

	/**
	 * Alternativer Constructor, welcher einen Wuefel basierend auf einem
	 * gegeben Strings erstellt. Sollte der String nicht dem gleichen Format
	 * entsprechen, wie er in der Cube.cubeToString() ausgegeben wird, so
	 * erhaelt man einen neuen, bereits geloesten 3x3x3 Wuerfel.
	 * 
	 * @param save
	 *            String im von Cube.cubeToString() vorgegeben Format.
	 */
	Cube(String save) {
		boolean error = false;
		int saveSize = 3;

		String[] splitSave = save.split(Constants.SEPARATOR);
		if (splitSave.length != 13) {
			System.out.println(saveError);
			error = true;
			createCube(saveSize);
		} else {
			try {
				saveSize = Integer.parseInt(splitSave[0]);
			} catch (NumberFormatException e) {
				System.out.println(saveError);
				error = true;
			}
			this.size = saveSize;

			if (!error) {
				// Ich brauche meine 6 Permutationen
				Colour[][][] permut = new Colour[6][this.size][this.size];
				char[][] colours = new char[6][this.size * this.size];

				for (int i = 0; i < 6; i++) {
					colours[i] = splitSave[i + 1].toCharArray();
					if (colours[i].length != 9) {
						error = true;
						System.out.println(saveError);
					}
				}
				if (!error) {
					for (int i = 0; i < 6; i++) {
						for (int j = 0; j < this.size; j++) {
							for (int k = 0; k < this.size; k++) {
								int counter = k;

								/*
								 * Dieser Schritt wird benoetigt, um das
								 * eindimensionale colours Array im Kontext
								 * einer 2-dimensionalen (Eigentlich 3, aber die
								 * aussere schleife ist fuer diesen spezifischen
								 * Schritt nicht von Relevanz.) Schleife
								 * vollstaendig zu durchlaufen.
								 */
								if (j == 1) {
									counter = k + this.size;
								} else if (j == 2) {
									counter = k + this.size + this.size;
								}

								Colour col;

								switch (colours[i][counter]) {
								case Constants.REDchar:
									col = Constants.Colour.RED;
									break;
								case Constants.BLUchar:
									col = Constants.Colour.BLU;
									break;
								case Constants.GREchar:
									col = Constants.Colour.GRE;
									break;
								case Constants.WHIchar:
									col = Constants.Colour.WHI;
									break;
								case Constants.YELchar:
									col = Constants.Colour.YEL;
									break;
								case Constants.ORAchar:
									col = Constants.Colour.ORA;
									break;
								default:
									col = Constants.Colour.RED; // Was? Ich mag
																// rot.
								}

								permut[i][j][k] = col;
							}
						}
					}

					// Ich habe meine 6 Permutationen, jetzt brauche ich meine
					// IDs.
					int[] faceIDs = new int[6];
					for (int i = 0; i < 6; i++) {
						try {
							faceIDs[i] = Integer.parseInt(splitSave[i + 7]);
						} catch (NumberFormatException e) {
							System.out.println(saveError);
							faceIDs[i] = 0;
							error = true;
						}
					}

					// Mit diesen Daten kann ich einen neuen Wuerfel erstellen
					// und
					// beschriften!
					if (!error) {
						Face[] myFaces = new Face[6];
						for (int i = 0; i < 6; i++) {
							myFaces[i] = new Face(this.size, faceIDs[i], null);
							myFaces[i].setPermut(permut[i]);

							switch (i) {
							case Constants.FRONT:
								this.front = myFaces[i];
								break;
							case Constants.RIGHT:
								this.right = myFaces[i];
								break;
							case Constants.BACK:
								this.back = myFaces[i];
								break;
							case Constants.LEFT:
								this.left = myFaces[i];
								break;
							case Constants.UP:
								this.up = myFaces[i];
								break;
							case Constants.DOWN:
								this.down = myFaces[i];
								break;
							default:
								System.out
										.println("Cube: Cubes haben nur 6 Seiten.");

							}
						}
					} else {
						createCube(saveSize);
					}
				} else {
					createCube(saveSize);
				}
			} else {
				createCube(saveSize);
			}

		}
	}

	// Private Methode, derer sich die konstruktoren bedienen, um code-redundanz
	// zu vermindern.
	private void createCube(int size) {
		this.size = size;
		this.front = new Face(size, 0, Constants.Colour.BLU);
		this.right = new Face(size, 1, Constants.Colour.ORA);
		this.back = new Face(size, 2, Constants.Colour.GRE);
		this.left = new Face(size, 3, Constants.Colour.RED);
		this.up = new Face(size, 4, Constants.Colour.WHI);
		this.down = new Face(size, 5, Constants.Colour.YEL);
	}

	/*
	 * WICHTIG: Diese privaten Methoden bestimmen wie die einzelnen 6 Seiten
	 * miteinander arbeiten und zueinander stehen, daher eine ausfuehrliche
	 * Beschreibung! Ein Bild ueber den Aufbau des Wuerfels kann auch im
	 * Model-Verzeichnis gefunden werden. Grundsaetzlich gibt es drei
	 * Bewegungen, die auf einem Rubik ausgefuehrt und mit booleans umgekehrt
	 * werden koennen: Man kann die vorderen Reihen horizontal und die vorderen
	 * Spalten vertikal bewegen und die seitlichen Spalten nach oben und unten
	 * bewegen. Die dabei entstehenden Verdrehungen der anliegenden Seiten
	 * werden bei diesen Methoden vorerst einmal vernachlaessigt und erst bei
	 * der finalen Umsetzung einer Wuerfeldrehung implementiert. Was bei einer
	 * Bewegung einer Spalte oder Reihe passiert, ist, dass man lediglich die 4
	 * Reihen/Spalten, welche im Vorgang inbegriffen sind, neu auf dem Wuerfel
	 * schreibt.
	 */

	/*
	 * Eine horizontale Drehung einer vorderen Reihe ist am einfachsten zu
	 * implementieren. Alle vier Seiten (Front, Right, Left, Back) sind so
	 * zueinander geordnet, dass man die Reihen einfach auslesen und in der
	 * benoetigten Reihenfolge wieder draufschreiben kann. boolean left gibt
	 * dabei and, ob die Verschiebung nach links gerichtet ist oder nicht.
	 */
	private void moveFrontHorizontal(int rowNr, boolean left) {
		assert (rowNr <= 5 && rowNr > 0) : "Bitte innerhalb des Wuerfels arbeiten.";

		Colour[] frontRow = this.front.readRow(rowNr, false);
		Colour[] rightRow = this.right.readRow(rowNr, false);
		Colour[] backRow = this.back.readRow(rowNr, false);
		Colour[] leftRow = this.left.readRow(rowNr, false);

		if (left) {
			this.left.writeRow(rowNr, frontRow);
			this.back.writeRow(rowNr, leftRow);
			this.right.writeRow(rowNr, backRow);
			this.front.writeRow(rowNr, rightRow);
		} else {
			this.right.writeRow(rowNr, frontRow);
			this.back.writeRow(rowNr, rightRow);
			this.left.writeRow(rowNr, backRow);
			this.front.writeRow(rowNr, leftRow);
		}
	}

	/*
	 * Die Seiten Up, Front und Down sind direkt uebereinander angeordnet, wenn
	 * man den Wuerfel aufklappt, damit man Back nicht falsch beschriftet,
	 * muessen manche Spalten von unten nach oben gelesen werden, da Back von
	 * Front aus betrachtet spiegelverkehrt ist.
	 */
	private void moveFrontVertical(int columnNr, boolean down) {
		if (down) {
			Colour[] frontCol = this.front.readColumn(columnNr, false);
			Colour[] downCol = this.down.readColumn(columnNr, true);
			Colour[] backCol = this.back.readColumn(this.size - 1 - columnNr,
					true);
			Colour[] upCol = this.up.readColumn(columnNr, false);

			this.down.writeColumn(columnNr, frontCol);
			this.back.writeColumn(this.size - 1 - columnNr, downCol);
			this.up.writeColumn(columnNr, backCol);
			this.front.writeColumn(columnNr, upCol);
		} else {
			Colour[] frontCol = this.front.readColumn(columnNr, false);
			Colour[] upCol = this.up.readColumn(columnNr, true);
			Colour[] backCol = this.back.readColumn(this.size - 1 - columnNr,
					true);
			Colour[] downCol = this.down.readColumn(columnNr, false);

			this.up.writeColumn(columnNr, frontCol);
			this.back.writeColumn(this.size - 1 - columnNr, upCol);
			this.down.writeColumn(columnNr, backCol);
			this.front.writeColumn(columnNr, downCol);
		}
	}

	/*
	 * Left und Right sind spiegelverkehrt zueinader, Up und Down stehen
	 * kopfueber zueinander; UND Man hat einen Uebergaenge von Spalten einer
	 * Seite zu Reihen einer anderen Seite.
	 */
	private void moveSideVertical(int columnNr, boolean down) {
		if (down) {
			Colour[] leftCol = this.left.readColumn(columnNr, false);
			Colour[] downRow = this.down
					.readRow(this.size - 1 - columnNr, true);
			Colour[] rightCol = this.right.readColumn(this.size - 1 - columnNr,
					false);
			Colour[] upRow = this.up.readRow(columnNr, true);

			this.down.writeRow(this.size - 1 - columnNr, leftCol);
			this.right.writeColumn(this.size - 1 - columnNr, downRow);
			this.up.writeRow(columnNr, rightCol);
			this.left.writeColumn(columnNr, upRow);
		} else {
			Colour[] leftCol = this.left.readColumn(columnNr, true);
			Colour[] upRow = this.up.readRow(columnNr, false);
			Colour[] rightCol = this.right.readColumn(this.size - 1 - columnNr,
					true);
			Colour[] downRow = this.down.readRow(this.size - 1 - columnNr,
					false);

			this.up.writeRow(columnNr, leftCol);
			this.right.writeColumn(this.size - 1 - columnNr, upRow);
			this.down.writeRow(this.size - 1 - columnNr, rightCol);
			this.left.writeColumn(columnNr, downRow);
		}
	}

	/*
	 * Dient zur neuen Zuteilung von FaceIDs waehrend der X-Rotation. frontDown:
	 * ob sich die vodere Seite nach unten bewegt
	 */
	private void changeFaceIDXAxis(boolean frontDown) {
		int frontID = this.front.getFaceID();
		int upID = this.up.getFaceID();
		int backID = this.back.getFaceID();
		int downID = this.down.getFaceID();

		if (frontDown) {
			this.front.setFaceID(upID);
			this.down.setFaceID(frontID);
			this.back.setFaceID(downID);
			this.up.setFaceID(backID);
		} else {
			this.front.setFaceID(downID);
			this.down.setFaceID(backID);
			this.back.setFaceID(upID);
			this.up.setFaceID(frontID);
		}
	}

	/*
	 * Hilfsmethode, um ganze wuerfeldrehungen entlang der X-Achse auszufuehren.
	 * frontDown: ob sich die vodere Seite nach unten bewegt
	 */
	private void rotX(boolean frontDown) {
		changeFaceIDXAxis(frontDown);
		for (int i = 0; i < this.size; i++) {
			this.moveFrontVertical(i, frontDown);
		}
		this.right.rotate90degrees(!frontDown);
		this.left.rotate90degrees(frontDown);
	}

	/*
	 * Dient zur neuen Zuteilung von FaceIDs waehrend der Y-Rotation. frontLeft:
	 * ob sich die vordere Seite nach links bewegt.
	 */
	private void changeFaceIDYAxis(boolean frontLeft) {
		int frontID = this.front.getFaceID();
		int leftID = this.left.getFaceID();
		int backID = this.back.getFaceID();
		int rightID = this.right.getFaceID();

		if (frontLeft) {
			this.front.setFaceID(rightID);
			this.left.setFaceID(frontID);
			this.back.setFaceID(leftID);
			this.right.setFaceID(backID);
		} else {
			this.front.setFaceID(leftID);
			this.left.setFaceID(backID);
			this.back.setFaceID(rightID);
			this.right.setFaceID(frontID);
		}
	}

	/*
	 * Hilfsmethode, um ganze wuerfeldrehungen entlang der Y-Achse auszufuehren.
	 * frontLeft: ob sich die vordere Seite nach links bewegt.
	 */
	private void rotY(boolean frontLeft) {
		changeFaceIDYAxis(frontLeft);
		for (int i = 0; i < this.size; i++) {
			this.moveFrontHorizontal(i, frontLeft);
		}
		this.up.rotate90degrees(frontLeft);
		this.down.rotate90degrees(!frontLeft);
	}

	/*
	 * Dient zur neuen Zuteilung von FaceIDs waehrend der Y-Rotation.
	 * frontClock: ob sich die vordere Seite im Uhrzeigersinn bewegt.
	 */
	private void changeFaceIDZAxis(boolean frontClock) {
		int leftID = this.left.getFaceID();
		int upID = this.up.getFaceID();
		int rightID = this.right.getFaceID();
		int downID = this.down.getFaceID();

		if (frontClock) {
			this.left.setFaceID(downID);
			this.up.setFaceID(leftID);
			this.right.setFaceID(upID);
			this.down.setFaceID(rightID);
		} else {
			this.left.setFaceID(upID);
			this.down.setFaceID(leftID);
			this.right.setFaceID(downID);
			this.up.setFaceID(rightID);
		}
	}

	/*
	 * Hilfsmethode, um ganze Wuerfeldrehungen entlang der Y-Achse auszufuehren.
	 * frontClock: ob sich die vordere Seite im Uhrzeigersinn bewegt.
	 */
	private void rotZ(boolean frontClock) {
		changeFaceIDZAxis(frontClock);
		for (int i = 0; i < this.size; i++) {
			this.moveSideVertical(i, !frontClock);
		}
		this.front.rotate90degrees(frontClock);
		this.back.rotate90degrees(!frontClock);
	}

	/**
	 * Fuehrt eine Drehung auf dem Wuerfel aus. Die Nomunklatur fuer die
	 * einzelnen Arten von Drehungen basieren hierbei auf der
	 * 'Singmaster-notation'. B bedeutet zum Beispiel, das die vom Spieler
	 * abgewandte Seite sich selbst um 90 Grad im Uhrzeigersinn dreht.
	 * 
	 * @param turn
	 *            Die Art von Zug, welche auf dem Wuerfel-Objekt ausgefuehrt
	 *            werden soll.
	 * @return true falls durchgefuehrt, false ansonsten.
	 */
	public boolean applyTurn(TurnType turn) {
		boolean success = false;
		// Die 'Mitte' wird auf diese Weise ermittelt, da wir ja von null
		// zaehlen.
		int middle = ((this.size - 1) / 2);

		if (turn != null) {
			// Befehle, die auf ALLEN Wuerfeln funktionieren.
			switch (turn) {
			case F:
				this.moveSideVertical(this.size - 1, false);
				this.front.rotate90degrees(true);
				success = true;
				break;
			case FPRIME:
				this.moveSideVertical(this.size - 1, true);
				this.front.rotate90degrees(false);
				success = true;
				break;
			case B:
				this.moveSideVertical(0, true);
				this.back.rotate90degrees(true);
				success = true;
				break;
			case BPRIME:
				this.moveSideVertical(0, false);
				this.back.rotate90degrees(false);
				success = true;
				break;
			case L:
				this.moveFrontVertical(0, true);
				this.left.rotate90degrees(true);
				success = true;
				break;
			case LPRIME:
				this.moveFrontVertical(0, false);
				this.left.rotate90degrees(false);
				success = true;
				break;
			case R:
				this.moveFrontVertical(this.size - 1, false);
				this.right.rotate90degrees(true);
				success = true;
				break;
			case RPRIME:
				this.moveFrontVertical(this.size - 1, true);
				this.right.rotate90degrees(false);
				success = true;
				break;
			case U:
				this.moveFrontHorizontal(0, true);
				this.up.rotate90degrees(true);
				success = true;
				break;
			case UPRIME:
				this.moveFrontHorizontal(0, false);
				this.up.rotate90degrees(false);
				success = true;
				break;
			case D:
				this.moveFrontHorizontal(this.size - 1, false);
				this.down.rotate90degrees(true);
				success = true;
				break;
			case DPRIME:
				this.moveFrontHorizontal(this.size - 1, true);
				this.down.rotate90degrees(false);
				success = true;
				break;

			case ROTX:
				rotX(false);
				success = true;
				break;
			case ROTXPRIME:
				rotX(true);
				success = true;
				break;

			case ROTY:
				rotY(true);
				success = true;
				break;
			case ROTYPRIME:
				rotY(false);
				success = true;
				break;

			case ROTZ:
				rotZ(true);
				success = true;
				break;
			case ROTZPRIME:
				rotZ(false);
				success = true;
				break;

			default:

			}

			// Befehle spezifisch fuer Wuerfel mit Mitten
			if (this.size % 2 == 1 && !success) {
				switch (turn) {
				case E:
					this.moveFrontHorizontal(middle, false);
					success = true;
					break;
				case EPRIME:
					this.moveFrontHorizontal(middle, true);
					success = true;
					break;
				case M:
					this.moveFrontVertical(middle, true);
					success = true;
					break;
				case MPRIME:
					this.moveFrontVertical(middle, false);
					success = true;
					break;
				case S:
					this.moveSideVertical(middle, false);
					success = true;
					break;
				case SPRIME:
					this.moveSideVertical(middle, true);
					success = true;
					break;
				default:
				}
			} else if (this.size > 3 && !success) {
				// Hier kann man in Zukunft die Befehlsannahme fuer groessere
				// Wuerfel
				// reinpacken.
			}
		} else {
			System.out.println("Cube: Turn darf nicht null sein.");
		}

		if (viewObserver != null) {
			this.viewObserver.update(this);
		}
		return success;
	}

	/**
	 * Erlaubt, einzelne Seiten eines Wuerfels zu beschreiben, sowie deren ID
	 * festzulegen. Falsches Verwenden dieser Methode kann einen unloesbaren
	 * Wuerfel generieren!
	 * 
	 * @param faceID
	 *            Das zu setzende FaceID.
	 * @param Colour
	 *            [][] Die Farbwerte die die Seite annehmen soll.
	 * @param position
	 *            Die Stellung des Seite im Wuerfel.
	 */
	void initializeFace(int faceID, Colour[][] permutation, int position) {
		this.getFace(position).setFaceID(faceID);
		this.getFace(position).setPermut(permutation);
	}

	/**
	 * Gibt das gewuenschte Seiten-Objekt des Wuerfel-Objektes aus.
	 * 
	 * 
	 * @param faceNr
	 *            Die Position der gewuenschten Seite.
	 * @return Die gewuenschte Seite als Objekt.
	 */
	public Face getFace(int faceNr) {
		assert (faceNr <= 5 && faceNr >= 0) : "Ein Wuerfel hat nur 6 Seiten.";

		Face datFace = null;

		switch (faceNr) {
		case Constants.FRONT:
			datFace = this.front;
			break;
		case Constants.RIGHT:
			datFace = this.right;
			break;
		case Constants.BACK:
			datFace = this.back;
			break;
		case Constants.LEFT:
			datFace = this.left;
			break;
		case Constants.UP:
			datFace = this.up;
			break;
		case Constants.DOWN:
			datFace = this.down;
			break;
		default:
			System.out.println("Cube: getFace arbeitet nur auf 6 Seiten.");
		}

		return datFace;
	}

	/**
	 * Testet, ob der Wuerfel geloest ist.
	 * 
	 * @return true falls geloest, false ansonsten
	 */
	// public fuer testzwecke
	public boolean isSolved() {

		boolean isSolved = true;
		int i = 0;
		while (isSolved && i < 6) {
			// Einfach alle 6 Seiten nach geloestem Zustand fragen.
			isSolved = this.getFace(i).isSolved();
			i++;
		}

		return isSolved;
	}

	/**
	 * Gibt die Groesse des Wuerfels zurueck.
	 * 
	 * @return die Groesse des Wuerfels
	 */
	int getSize() {

		return this.size;
	}

	/**
	 * Gibt den ID der linken Seite zurueck.
	 * 
	 * @return ID der linken Seite.
	 */
	public int getSideID() {
		return this.left.getFaceID();
	}

	/**
	 * Gibt den ID der vorderen Seite zurueck.
	 * 
	 * @return ID der vorderen Seite.
	 */
	public int getFrontID() {
		return this.front.getFaceID();
	}

	/**
	 * Macht eine Copie des Wuerfels.
	 * 
	 * @return Gibt eine Kopie des Wuerfels zurueck.
	 */
	@Override
	protected Cube clone() {
		Cube copy = new Cube(this.size);

		for (int i = 0; i < 6; i++) {
			Colour[][] toCopyPermut = this.getFace(i).getPermut();
			Colour[][] tempPermut = new Colour[this.size][this.size];
			for (int j = 0; j < toCopyPermut.length; j++) {
				for (int k = 0; k < toCopyPermut[j].length; k++) {
					tempPermut[j][k] = toCopyPermut[j][k];
				}
			}

			copy.initializeFace(this.getFace(i).getFaceID(), tempPermut, i);

		}

		return copy;

	}

	/**
	 * Erstellt eine Stringrepraesentation des Wuerfels, um einfache Speichern
	 * zu ermoeglichen. Der String sieht dann zum Beispiel mit einem 3er Wuerfel
	 * wie folgt aus ('S' steht dabei fuer das Trennzeichen, welches in
	 * Constants als SEPARATOR definiert ist): 3'S'OOORRRBBB'S'WWW...(6
	 * Seiten)...'S'frontID'S'rightID'S'..(6 SeitenIDs) Wichtig, am Ende steht
	 * kein Trennzeichen! Die Reihenfolge der Werte ist durch die Werte der
	 * Face-Konstanten in Constants definiert.
	 * 
	 * @return Den Wuerfel als meschenlesbare Stringrepraesentation
	 */
	String cubeToString() {
		StringBuilder sb = new StringBuilder();
		// size
		sb.append(this.size);
		sb.append(Constants.SEPARATOR);
		// faces
		for (int i = 0; i < 6; i++) {
			sb.append(this.getFace(i).faceToString());
			sb.append(Constants.SEPARATOR);
		}
		// IDs
		for (int i = 0; i < 6; i++) {
			if (i == 5) {
				sb.append(this.getFace(i).getFaceID());
			} else {
				sb.append(this.getFace(i).getFaceID());
				sb.append(Constants.SEPARATOR);
			}
		}

		return sb.toString();
	}

	// Testmethoden zum vergleichen 2er wuerfel, koennen im fertigen Programm
	// entfernt werden.
	boolean compareFace(Face comparesOne, Face comparesTwo) {
		boolean isEqual = true;

		isEqual = (comparesOne.size == comparesTwo.size);

		if (isEqual) {
			isEqual = (comparesOne.getFaceID() == comparesTwo.getFaceID());
			for (int i = 0; isEqual && i < this.size; i++) {
				for (int j = 0; isEqual && j < this.size; j++) {
					isEqual = (comparesOne.getSingleField(i, j) == comparesTwo
							.getSingleField(i, j));
				}
			}
		}

		return isEqual;
	}

	boolean equalsCube(Cube compares) {
		boolean isEqual = true;
		int i = 0;
		while (i < 6 && isEqual) {
			isEqual = compareFace(this.getFace(i), compares.getFace(i));

			i++;
		}

		return isEqual;
	}

	/**
	 * Registriert den Observer der die Farben der Flaechen an die View
	 * weitergibt.
	 * 
	 * @param co
	 *            Der Observer
	 */
	public void addListener(CubeObserver co) {
		this.viewObserver = co;
		co.update(this);
	}
}
