package com.pc_model;

import com.pc_util.Constants;
import com.pc_util.Constants.Colour;

/** 
 * Die Objekte dieser Klasse stellen die Seiten eines Wuerfels dar.
 *   0  1  2
 * 0-|--|--|-
 * 1-|--|--|-
 * 2-|--|--|-
 */
public class Face {
	/**
	 * Diese Matrix beinhaltet die Farbwerte der einzelnen Unterflaechen einer Seite. 
	 */
	private Colour[][] Permutation;
	
	/**
	 * Die Identifikationsnummer der Seite. Dient dazu, Bewegungen ganzer Seiten zu verdeutlichen.
	 */
	private int faceID;
	
	/** 
	 * Die Groesse einer Seite.
	 */
	//Nur quadratische Seiten werden unterstuetzt.
	int size;
	
	/**
	 * Konstruktor Methode fuer das erstellen einer Seite.
	 * @param size Die Groesse der zu erstellenden Seite.
	 * @param faceID ID der Seite.
	 * @param colour Die Anfangsfarbe, die alle Flaechen der Seite haben.
	 */
	Face(int size, int faceID, Colour colour) {
	
		this.size = size;
		this.faceID = faceID;
		this.Permutation = new Colour[size][size];
		for(int i = 0; i < this.size; i++) {
			for(int j = 0; j < this.size; j++) {
				this.Permutation[i][j] = colour;
			}
		}
	}
	
	/**
	 * Schreibt eine Reihe von Farbwerten in die gegebene Reihe.
	 * @param rowNr Die Nummer der Reihe auf der Seite
	 * @param row Array, welches die neuen Werte, welche fuer die Reihe bestimmt sind, enthaelt.
	 */
	void writeRow(int rowNr, Colour[] row) {
		assert(rowNr >= 0 && rowNr < this.size) : "Bitte innerhalb der Arrays arbeiten.";
		assert(row.length == this.size) : "Input muss auf die Seite abgestimmt sein.";
		for(int i = 0; i < this.size; i++) {
			this.Permutation[rowNr][i] = row[i];
		}
	}
	
	
	/**
	 * Schreibt eine Spalte von Farbwerten in die gegebene Spalte.
	 * @param columnNr Die Nummer der Spalte auf der Seite
	 * @param column Array, welches die neuen Werte, welche fuer die Spalte bestimmt sind, enthaelt.
	 */
	void writeColumn(int columnNr, Colour[] column) {
		assert(columnNr >= 0 && columnNr < this.size) : "Bitte innerhalb der Arrays arbeiten.";
		assert(column.length == this.size) : "Input muss auf die Seite abgestimmt sein.";
		for(int i = 0; i < this.size; i++) {
			this.Permutation[i][columnNr] = column[i];
		}
		
	}
	

	
	/** 
	 * Dreht die Seite um 90 Grad.
	 * @param clockwise Bestimmt ob die Drehung im Uhrzeigersinn oder entgegengesetzt dessen sein sollte.
	 */
	void rotate90degrees(boolean clockwise) {
		if(clockwise) {
			Colour[][] permutCopy = new Colour[this.size][this.size];
			for(int i = 0; i < this.size; i++) {
				permutCopy[i] = this.readRow(i, false);
			}
			
			for(int i = 0; i < this.size; i++) {
				this.writeColumn(this.size - 1 - i, permutCopy[i]);
			}
			
		} else {
			Colour[][] mirrorPermut = new Colour[this.size][this.size];
			for(int i = 0; i < this.size; i++) {
				mirrorPermut[i] = this.readRow(i, true);
			}
			for(int i = 0; i < this.size; i++) {
				this.writeColumn(i, mirrorPermut[i]);
			}
		}
	
	}
	
	/** 
	 * Liest eine Zeile der Seite.
	 * @param rowNr Bestimmt welche Zeile gelesen werden soll.
	 * @param rightToLeft Bestimmt, ob die Reihe von Rechts nach Links gelesen werden soll.
	 * @return Gibt die Farbwerte der angegebenen Zeile auf der Seite zurueck.
	 */
	Colour[] readRow(int rowNr, boolean rightToLeft) {
		assert(rowNr >= 0 && rowNr < this.size) : "Bitte innerhalb der Arrays arbeiten.";
		Colour[] rowValue = new Colour[this.size];
		
		for(int i = 0; i < this.size; i++) {
			
			if(rightToLeft) {
				rowValue[i] = this.Permutation[rowNr][this.size - 1 - i];
			} else {
				rowValue[i] = this.Permutation[rowNr][i];
			}
		}
		
		
		return rowValue;
	}
	
	/** 
	 * Liest eine Spalte der Seite.
	 * @param columnNr Bestimmt welche Spalte gelesen werden soll.
	 * @param bottomToTop Bestimmt, ob die Spale von Unten nach Oben gelesen werden soll.
	 * @return Gibt die Farbwerte der angegebenen Spalte auf dwe Seite zurueck.
	 */
	Colour[] readColumn(int columnNr, boolean bottomToTop) {
		assert(columnNr >= 0 && columnNr < size) : "Bitte innerhalb der Arrays arbeiten.";
		Colour[] colValue = new Colour[this.size];
		
		for(int i = 0; i < this.size; i++) {
			
			if(bottomToTop) {
				colValue[i] = this.Permutation[this.size - 1 - i][columnNr];
			} else {
				colValue[i] = this.Permutation[i][columnNr];
			}
		}
		
		
		return colValue;
	}
	
	/**
	 * ueberprueft, ob eine Seite einheitlich mit einer Farbe bedeckt ist.
	 * @return true, wenn die Seite einfarbig ist.
	 */
	boolean isSolved() {
		boolean singleColour = true;
		int i = 0;
		Colour currentColour = this.Permutation[0][0];
		while(singleColour && i < this.size) {
			int j = 0;
			while(singleColour && j < this.size) {
				if(currentColour != this.Permutation[i][j]) {
					singleColour = false;
				}
				j++;
			}
			i++;
		}
		
		return singleColour;
	}
	
	/**
	 * Gibt die aktuelle FaceID zurueck.
	 * @return Die aktuelle FaceID.
	 */
	int getFaceID() {
		return this.faceID;
	}
	
	/**
	 * Erlaubt, eine neue FaceID zu setzen.
	 * @param Die neue faceID.
	 *  */
	void setFaceID(int faceID) {
		this.faceID = faceID;
	}
	
	
	/**
	 * Gibt die aktuelle Farbkonfiguration der Seite als 2-dim. Array zurueck.
	 * @return Das aktuelle Aussehen der Seite als 2-dim. Array.
	 */
	public Colour[][] getPermut() {
		return this.Permutation;
	}
	
	/**
	 * Erlaubt es, einer Seite eine neue Farbkonfiguration zu verpassen.
	 * @param neue Farbkonfiguration in Form eines 2-dim. Arrays. 
	 */
	void setPermut(Colour[][] newPermut) {
		this.Permutation = newPermut;
	}
	
	//Diese Methoden dienen nur zu Testzwecken und werden entfernt, sollte nicht doch Bedarf fuer sie irgendwo bestehen.
	Colour getSingleField(int row, int column) {
		assert(row < this.size && column < this.size && row >= 0 && column >= 0): "Genau.";
		return this.Permutation[row][column];
	}
	
	
	/**
	 * Erstellt einen String, welcher den Inhalt der Seite darstellt.
	 * R steht fuer rot, W fuer weiss, O fuer orange, Y fuer gelb, G fuer gruen und B fuer blau.
	 * Es wird einfach Reihe fuer Reihe nacheinander geschrieben, zB 'OOORRRBBB'
	 * steht fuer eine Seite die so aussieht: OOO
	 * 										 RRR
	 * 										 BBB
	 * 
	 * @return Eine String-Repraesentation der Seite
	 */
	String faceToString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < this.size; i++) {
			for(int j = 0; j < this.size; j++) {
				switch(this.Permutation[i][j]){
				case RED : sb.append(Constants.REDchar); break;
				case WHI : sb.append(Constants.WHIchar); break;
				case ORA : sb.append(Constants.ORAchar); break;
				case YEL : sb.append(Constants.YELchar); break;
				case GRE : sb.append(Constants.GREchar); break;
				case BLU : sb.append(Constants.BLUchar); break;
				}
			} 
		}
		return sb.toString();
	}
	
}