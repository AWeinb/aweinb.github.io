package com.pc_model;

import com.pc_controller.FileHandler;
import com.pc_util.Constants.TurnType;

/**
 * Stellt eine Fassadeklasse zum Zauberwuerfel Modell dar. Erlaubt den Zugriff
 * auf den logischen und den grafischen Wuerfel sowie das Spielprotokoll.
 */
public class ModelFacade {

  /* Verweis auf den W�rfel, auf dem gespielt wird. */
  private Cube cube;
  /* Verweis auf den graphiscen W�rfel, der gedreht wird. */
  private GraphicCube gcube;
  /* Verweis auf die aktuellen Optionen. */
  private Options options;
  private boolean clear = false;

  /**************************** Methoden Facade *************************************************************************/

  /** Erstellt eine Fassadenklasse fuer das Model des Zauberwuerfels. */
  public ModelFacade() {
  }

  /** Erstellt die Modelkomponenten fuer ein neues Spiel */
  public void newGame() {
    this.options = Options.getOptionsInstance();

    cube = new Cube(options.getCubeSize());
    gcube = new GraphicCube(options.getCubeSize());

    TurnHandler.setCube(cube);
    TurnHandler.setGrCube(gcube);

    GameProtocol.resetToDefault();
  }

  /**
   * F�gt dem logischen Model (Cube und Graphic Cube) einen neuen CubeObserver/
   * Listener hinzu.
   * 
   * @param co
   *          der Listener der hinzugef�gt werden soll.
   */
  public void addListener(CubeObserver co) {
    cube.addListener(co);
    gcube.addListener(co);
  }

  /**
   * Gibt den W�rfel, auf dem aktuell gespielt wird zur�ck.
   * 
   * @return den aktuellen W�rfel
   */
  public Cube getCube() {
    return cube;
  }

  /**
   * Gibt den graphischen Cube, auf dem aktuell gepielt wird zur�ck.
   * 
   * @return den aktuellen graphischen W�rfel.
   */
  public GraphicCube getGraphicCube() {
    return gcube;
  }

  /******************** Methoden FileHandler **************************************************************************/

  /**
   * Spiel speichern.
   */
  public void saveGame() {
    if (!clear) {
      String cubeSave = cube.cubeToString();
      String protocolSave = GameProtocol.protocolToString();
      FileHandler.saveGame(cubeSave, protocolSave);

    } else {
      String cubesave = "NO_GAME";
      String protcsave = "NO_GAME";

      FileHandler.saveGame(cubesave, protcsave);
    }
  }

  public void clear(boolean clear) {
    this.clear = clear;
  }

  /**
   * Ruft die alten Spielwerte im Filehandler ab und erstellt die
   * Modelkomponenten abhaengig davon. Gibt true zurueck, falls das alte Spiel
   * erfolgreich gestartet wurde, false falls kein alter Spielstand vorhanden
   * ist.
   * 
   * @return ob ein altes Spiel erfolgreich gestartet werden konnte.
   */
  public boolean loadGame(boolean checkForSave) {
    boolean success;
    String[] saveGame = FileHandler.loadGame();

    if (saveGame != null && saveGame[0].equals("NO_GAME") || saveGame[0].equals("ERROR")) {
      success = false;

    } else {
      if (!checkForSave) {
        cube = new Cube(saveGame[0]);
        gcube = new GraphicCube(cube.getSize());
        TurnHandler.setCube(cube);
        TurnHandler.setGrCube(gcube);
        GameProtocol.fromString(saveGame[1]);
      }
      success = true;
    }

    return success;
  }

  /**
   * Fordert die Highscore Klasse dazu auf, die HighScores zurueck zu setzen.
   */
  public static void resetHighScore() {
    Highscores.getInstance().reset();
  }

  /**
   * Uebergibt dem FileHandler das OptionsObjekt, damit dieser es speichern
   * kann.
   * 
   * @param o
   *          Die zu speichernden Optionen.
   */
  public static void storeOptions(Options o) {
    FileHandler.storeOptions(o);
  }

  /******************** Methoden CUBE *********************************************************************************/

  public boolean applyTurn(TurnType turntype) {
    return cube.applyTurn(turntype);
  }

  public Cube cloneCube() {
    return cube.clone();
  }

  public boolean cubeIsSolved() {
    return cube.isSolved();
  }

  public int getCubeSize() {
    return cube.getSize();
  }

  /******************** Methoden GameProtocol *************************************************************************/

  public void setElapsedTime(long elapsedTime) {
    GameProtocol.setElapsedTime(elapsedTime);

  }

  public long getElapsedTime() {
    return GameProtocol.getElapsedTime();
  }

  public void setKey(long key) {
    GameProtocol.setKey(key);
  }

  public int getCount() {
    return GameProtocol.getCounter();
  }

  public void setHelpFunctionUsed() {
    GameProtocol.setHelpFunctionUsed();
  }

  public boolean getHelpFunctionUsed() {
    return GameProtocol.getHelpFunctionUsed();
  }

  /******************** Methoden TurnHandler **************************************************************************/

  public boolean manageTurn(Turn turn) {
    return TurnHandler.manageTurn(turn);
  }

  public boolean undo() {
    return TurnHandler.undo();
  }

  public boolean redo() {
    return TurnHandler.redo();
  }
}