package com.pc_model;

import java.util.Iterator;
import java.util.Vector;

import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;

/**
 * Repr&#196;sentiert den Verlauf des aktuellen Zauberw&#252;rfelspiels. Speichert vergangene Z&#252;ge f&#252;r die
 * Undo-/Redo-Funktion, die Anzahl der get&#196;tigten Z&#252;ge, die Spielzeit nachdem das Spiel beendet wurde, ob die
 * Hilfefunktion genutzt wurde und den Key des aktuellen W&#252;rfels.
 * 
 * Das GameProtocol ist ein statisches Singleton.
 */
public final class GameProtocol {
  /* Speichert die Anzahl der Z&#252;ge, die vom Anfang des Spieles gemacht wurden. */
  private static int counter = 0;

  /* Verbrauchte Spielzeit in Millisekunden. */
  private static long time = 0;
  /* Speichert, ob die Hilfefunktion benutzt wurde. */
  private static boolean helpFunctionUsed = false;

  /* Speichert die Liste der bisher auf dem W&#252;rfel ausgef&#252;hrten Z&#252;ge. Zu Anfang leer. */
  private static Vector<Turn> memory = new Vector<Turn>(30, 20);

  /* Speichert einen Pointer auf den zuletzt ausgef&#252;hrten Turn in der memory-List. null, falls die Liste leer ist. */
  private static int aktTurn = 0;

  /* Speichert den Key f&#252;r das Erstellen der Anfangskonfiguration des letzten W&#252;rfels. */
  private static String key = "";

  /* Der private Konstruktor vermeidet das Instanziieren der Klasse von au&#223;en. */
  private GameProtocol() {
  }

  /**
   * Speichert einen ausgef&#252;hrten Zug und erh&#246;ht den Zugcounter um eins. Wird ein ung&#252;ltiger Zug (z.B.
   * null) &#252;bergeben, passiert nichts.
   * 
   * @param turn
   *          den zuletzt ausgef&#252;hrten Zug
   */
  public static void setNextTurn(Turn turn) {
    if (turn == null) {
      return;
    }
    if (aktTurn <= memory.size() - 1) {
      for (int i = memory.size() - 1; i >= aktTurn; i--) {
        memory.remove(i);

      }
    }
    memory.add(aktTurn, turn);
    increaseCounter();
    aktTurn = aktTurn + 1;
  }

  /**
   * Gibt den 'zuletzt' ausgef&#252;hrten Zug zur&#252;ck, entsprechend der undo-funktion. Gibt null zur&#252;ck, falls
   * der Anfang der Protokoll-Liste erreicht wurde. Eh&#246;ht den Zugcounter um eins.
   * 
   * @return den zuletzt ausgef&#252;hrten Zug entsprechend der undo-funktion. kann null sein.
   */
  public static Turn getLastTurn() {
    // testen
    Turn turn = null;
    // testen
    if (!memory.isEmpty() && aktTurn >= 1) {
      aktTurn = aktTurn - 1;
      turn = memory.elementAt(aktTurn);

    }
    // if(turn = TurnType.EndOfLine)

    if (turn != null) {
      increaseCounter();
    }
    return turn;
  }

  /**
   * Gibt den als 'n&#196;chstens' auszuf&#252;hrenden Zug aus entsprechend der redo-funktion. Gibt null zur&#252;ck,
   * falls das Ende der Protokoll-Liste erreicht wurde. Erh&#246;ht den Zugcounter um eins.
   * 
   * @return den zun&#196;chst auszuf&#252;hrenden Zug entsprechend der redo-funktion. kann null sein.
   */
  public static Turn getNextTurn() {
    Turn turn = null;
    if (aktTurn <= memory.size() - 1) {
      aktTurn = aktTurn + 1;
      turn = memory.elementAt(aktTurn - 1);

    }
    if (turn != null) {
      increaseCounter();
    }
    return turn;
  }

  /**
   * Gibt die aktuell gespeicherte Turnliste als String zur&#252;ck. Sind keine Turns gespeichert wird ein leerer String
   * "" zur&#252;ck gegeben.
   * 
   * @return die Turnliste als String
   */
  public static String turnlistToString() {
    StringBuilder builder = new StringBuilder();
    builder.append("");
    if (!memory.isEmpty()) {
      for (Iterator<Turn> i = memory.iterator(); i.hasNext();) {
        builder.append(turnToString(i.next()));
        builder.append(Constants.TURNSEPERATOR);
      }
    }

    return builder.toString();
  }

  /**
   * Funktion f&#252;r das Lesen des Zugcounters.
   * 
   * @return Die Anzahl der durchgef&#252;hrten Z&#252;ge.
   */
  public static int getCounter() {
    return counter;
  }

  /**
   * Funktion f&#252;r die Inkrementierung des Zugcounters.
   */
  public static void increaseCounter() {
    counter = counter + 1;
  }

  /**
   * Setzt die verbrauchte Zeit in Millisekunden. Sie sollte gr&#246;&#223;er gleich 0 sein.
   * 
   * @param time
   *          die Spielzeit
   * @throws IllegalArgumentException
   */
  public static void setElapsedTime(long elapsedTime) throws IllegalArgumentException {
    if (elapsedTime < 0) {
      throw new IllegalArgumentException("Zeit kann nicht negativ sein.");
    }
    time = elapsedTime;
  }

  /**
   * Gibt die Spielzeit in Millisekunden zur&#252;ck, falls diese gesetzt wurde. Sonst 0.
   * 
   * @return die Spielzeit in Millisekunden
   */
  public static long getElapsedTime() {
    return time;
  }

  /**
   * Merkt sich, dass die Hilfefunktion benutzt wurde.
   */
  public static void setHelpFunctionUsed() {
    helpFunctionUsed = true;
  }

  /**
   * Methode f&#252;r das Lesen der Variable helpFunctionUsed.
   * 
   * @return Das Wert der Variable.
   */
  public static boolean getHelpFunctionUsed() {
    return helpFunctionUsed;
  }

  /**
   * Setzt das Protokoll auf die Defaultwerte zur&#252;ck. Diese sind: die Turnliste ist leer. Die Zuganzahl = 0. Die
   * Spielzeit = 0. Der Key ist nicht gesetzt. (= "") Die Hilfefuntkion wurde nicht benutzt.
   */
  public static void resetToDefault() {
    aktTurn = 0;
    counter = 0;
    key = "";
    memory = new Vector<Turn>(30, 20);
    helpFunctionUsed = false;
    time = 0;
  }

  /**
   * Speichert den Key im Protokoll.
   * 
   * @param key
   *          den Key als Long
   */
  public static void setKey(long newKey) {
    // TODO: formatierung muss eindeutig bestimmt werden!
    key = new String("" + newKey);

  }

  /**
   * Gibt den Key als String zur&#252;ck. Gibt einen leeren String zur&#252;ck, falls der Key nicht gesetzt wurde.
   * 
   * @return den Key als String
   */
  public static String getKeyAsString() {
    return key;
  }

  /**
   * Gibt den Key als Long zur&#252;ck. Gibt 0 zur&#252;ck, falls der Key nicht gesetzt wurde oder ein ung&#252;ltiger
   * Key gespeichert wurde..
   * 
   * @return den Key als Long
   */
  public static long getKeyAsLong() {
    try {
      long lkey = Long.parseLong(key);
      return lkey;
    } catch (NumberFormatException e) {
      return 0;
    }
  }

  /**
   * Gibt das Protokoll als String aus. Format: aktTurn#counter#helpFunctionUsed#key#time#turn1,turn2, ... Wobei "#" =
   * Constants.Separator und "," = Constants.Turnseparator.
   */
  public static String protocolToString() {
    StringBuilder builder = new StringBuilder();
    String seperator = Constants.SEPARATOR;
    String turnseperator = Constants.TURNSEPERATOR;

    builder.append(aktTurn).append(seperator);
    builder.append(counter).append(seperator);
    builder.append(helpFunctionUsed).append(seperator); // "true" oder "false"
    builder.append(key).append(seperator);
    builder.append(time).append(seperator);

    if (!memory.isEmpty()) {
      for (Iterator<Turn> i = memory.iterator(); i.hasNext();) {
        builder.append(turnToString(i.next()));
        builder.append(turnseperator);
      }
    }

    return builder.toString();
  }

  /**
   * Erstellt ein GameProtocol anhand eines alten Speicherstands. Format:
   * aktTurn#counter#helpFunctionUsed#key#time#turn1,turn2, ... <br>
   * Wobei "#" = Constants.Separator und "," = Constants.Turnseparator<br>
   * <br>
   * Beispiel:<br>
   * default: "0#0#false##0#" <br>
   * nicht default: 1#5#true#019827927498#9223372036#B00,U00,F11,G23,<br>
   * <br>
   * Wird ein ung&#252;ltiger String eingegeben (leer, null, nicht dem Format entsprechend) so wird reset
   * ausgef&#252;hrt.<br>
   * Werden ung&#252;ltige Werte eingesetzt (time, count < 0) werden diese ebenfalls resetet.
   * 
   * @param save
   *          der alte Speicherstnad als String
   */
  public static void fromString(String save) {
    if (save == null || save.equals("")) {
      resetToDefault();
      return;
    }

    String[] protocol = save.split(Constants.SEPARATOR);
    if (protocol.length < 5) {
      resetToDefault();
      return;
    }

    if(protocol[0].charAt(0) =='-' || protocol[1].charAt(0) =='-') {
    	aktTurn = 0;
        counter = 0;
    } else {
    	try {
    		aktTurn = Integer.parseInt(protocol[0]);
    		counter = Integer.parseInt(protocol[1]);
    		} catch (NumberFormatException e) {
    			e.printStackTrace();
    			aktTurn = 0;
    			counter = 0;
    	}
    }
    boolean used = false;
    if (protocol[2].equals("true")) { // Exception...
      used = true;
    } else if (protocol[2].equals("false")) {
      used = false;
    } else {
      System.out.println("Falsche Kodierung: helpFunctionUsed = " + protocol[2]);
    }
    helpFunctionUsed = used;
    key = protocol[3];
    // time
    if(protocol[4].charAt(0) =='-') {
    	time = 0;
        
    } else {
    time = Long.parseLong(protocol[4]);
    }
    // oben: protocol.length > 4 festgestellt.
    if (protocol.length > 5) { // nicht >= denn =4 ist nur protocol[3] m&#246;glich! // Arrayoutofbounds
      String[] turnlist = protocol[5].split(Constants.TURNSEPERATOR);

      if (!memory.isEmpty()) {
        memory.clear();
      }

      for (int i = 0; i < turnlist.length; i++) {
        try {
          Turn add = turnFromString(turnlist[i]);
          memory.add(add);
        } catch (IllegalArgumentException e) {
          e.printStackTrace();
          System.out.println("GP: fromString: unable to add turn " + turnlist[i]);
        }

      }
    }
    // es ist teoretisch m&#246;glich, aktTurn auf 1000 zu setzen, auch wenn memory leer
    if (aktTurn > memory.size()) {
      aktTurn = 0;
    }

  }

  /*************************************** PRIVATE **********************************************************************/

  /*
   * Stellt einen Turn aus der Turnlist als menschenlesbaren String dar in der Form "turntype.frontfaceid.sidefaceid"
   * 
   * @param der zu konvertierende Turn
   */
  private static String turnToString(Turn turn) {
    StringBuilder builder = new StringBuilder();
    String type = "";
    switch (turn.getValue()) {
    case F:
      type = "F";
      break;
    case FPRIME:
      type = "f";
      break;
    case L:
      type = "L";
      break;
    case LPRIME:
      type = "l";
      break;
    case R:
      type = "R";
      break;
    case RPRIME:
      type = "r";
      break;
    case B:
      type = "B";
      break;
    case BPRIME:
      type = "b";
      break;
    case U:
      type = "U";
      break;
    case UPRIME:
      type = "u";
      break;
    case D:
      type = "D";
      break;
    case DPRIME:
      type = "D";
      break;
    case M:
      type = "M";
      break;
    case MPRIME:
      type = "m";
      break;
    case E:
      type = "E";
      break;
    case EPRIME:
      type = "e";
      break;
    case S:
      type = "S";
      break;
    case SPRIME:
      type = "s";
      break;
    case ROTX:
      type = "X";
      break;
    case ROTXPRIME:
      type = "x";
      break;
    case ROTY:
      type = "Y";
      break;
    case ROTYPRIME:
      type = "y";
      break;
    case ROTZ:
      type = "Z";
      break;
    case ROTZPRIME:
      type = "z";
      break;
    default:
      type = Constants.SEPARATOR;
    }
    builder.append(type);
    builder.append(turn.getFrontFaceID()).append(turn.getSideFaceID());
    return builder.toString();
  }

  /*
   * Konvertiert einen String der Form "turntype.frontfaceid.sidefaceid" in einen Turn. Dabei ist turntype ein uchstabe.
   * Valid sind Buchstaben, der TurnType Notation (z.B F als 'F') oder ihre Primes als kleine Buchstaben (z.B FPRIME als
   * 'f') und X, Y, Z f&#252;r die Rotationen. Ist ein nicht valider Buchstabe dabei, wird eine IllegalArgumentException
   * geworfen. frontfaceid und sidefaceid sind ganze Zahlen zwischen 0 und 5. Besteht der String nicht aus diesen 3
   * Komponenten, wird eine IllegalArgumentException geworfen.
   * 
   * @param save der zu konvertierende String
   * 
   * @throws IllegalArgumentException
   */
  private static Turn turnFromString(String save) {
    TurnType type = null;
    int front = 0;
    int side = 0;

    if (save.length() != 3) {
      throw new IllegalArgumentException("Turn falsch kodiert.");
    }

    char[] turn = save.toCharArray();
    switch (turn[0]) {
    case 'F':
      type = TurnType.F;
      break;
    case 'f':
      type = TurnType.FPRIME;
      break;
    case 'L':
      type = TurnType.L;
      break;
    case 'l':
      type = TurnType.LPRIME;
      break;
    case 'R':
      type = TurnType.R;
      break;
    case 'r':
      type = TurnType.RPRIME;
      break;
    case 'B':
      type = TurnType.B;
      break;
    case 'b':
      type = TurnType.BPRIME;
      break;
    case 'U':
      type = TurnType.U;
      break;
    case 'u':
      type = TurnType.UPRIME;
      break;
    case 'D':
      type = TurnType.D;
      break;
    case 'd':
      type = TurnType.DPRIME;
      break;
    case 'M':
      type = TurnType.M;
      break;
    case 'm':
      type = TurnType.MPRIME;
      break;
    case 'E':
      type = TurnType.E;
      break;
    case 'e':
      type = TurnType.EPRIME;
      break;
    case 'S':
      type = TurnType.S;
      break;
    case 's':
      type = TurnType.SPRIME;
      break;
    case 'X':
      type = TurnType.ROTX;
      break;
    case 'x':
      type = TurnType.ROTXPRIME;
      break;
    case 'Y':
      type = TurnType.ROTY;
      break;
    case 'y':
      type = TurnType.ROTYPRIME;
      break;
    case 'Z':
      type = TurnType.ROTZ;
      break;
    case 'z':
      type = TurnType.ROTZPRIME;
      break;
    default:
      throw new IllegalArgumentException("Kein passender Buchstabe.");
    }

    try {
      front = Integer.parseInt(String.valueOf(turn[1]));
      side = Integer.parseInt(String.valueOf(turn[2]));

    } catch (NumberFormatException e) {
      e.printStackTrace();
      System.out.println("front = " + turn[1] + "side = " + turn[2]);
    }

    // TODO was ist wenn front, side beide 0 bleiben??? also das catch aktiviert wird?
    Turn t = new Turn(type, front, side);
    return t;
  }

}
