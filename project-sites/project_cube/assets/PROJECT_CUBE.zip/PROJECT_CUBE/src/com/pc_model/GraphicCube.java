package com.pc_model;


/**
 * Der GraphicCube erlaubt die Steuerung der Winkel des Zaberwuerfels, damit
 * diese dann genau in der View repraesentiert werden.
 * 
 * */
public class GraphicCube {

  /**
   * Damit man nicht unbeabsichtig mehrere Ebenen verdreht, wird hier die gerade
   * verdrehte Ebene gespeichert.
   */
  private int currentLayer;

  /**
   * Der Winkel, um den die aktuelle Ebene verdreht ist.
   */
  private float currentAngle;

  /*
   * Dieses Attribut soll zur Speicherung der Winkel im Wuerfel dienen. Entlang
   * der Achsen im Raum befinden sich immer so viele Ebenen wie die Groesse des
   * Wuerfels. Zum Beispiel, 2x2x2 Wuerfel haben eine obere, untere, linke,
   * rechte, vordere und hintere Ebene, welche entlang der Achsen im Raum um
   * einen Winkel gedreht sein koennen. Die erste stelle im Array gibt die Achse
   * an, die zweite die Nummer der Ebene. angleOfLayers[0] beinhalte die Ebenen
   * entlang der X-Achse, man zaehlt von links nach rechts. angleOfLayers[1]
   * beinhalte die Ebenen entlang der Y-Achse, man zaehlt von oben nach unten.
   * angleOfLayers[2] beinhaltet die Ebenen entlang der Z-Achse, man zaehlt von
   * vorne nach hinten.
   */
  private float[][] angleOfLayers;
  /*
   * Options enthaelt Animationsgeschwindigkeit.
   */
  private Options options;
  /*
   * Groesse des theoretischen Wuerfels
   */
  private int size;
  /*
   * Man arbeitet immer nur auf einer Ebene bei Einzelverdrehungen. Deshalb wird
   * hier die momentan verdrehte Achse gespeichert.
   */
  private int currentAxis;
  /*
   * Der GraphicObserver wird ueber aenderungen im GraphicCube informiert und
   * dient als Schnittstelle zu unserer View.
   */
  private CubeObserver viewObserver;
  private static final String OBSERVER_ERROR = "GraphicCube: Observer ist null!";

  /**
   * Constructor zur Erstellung unserer Winkelrepraesentation des Zauberwuerfels
   * 
   * @param size
   *          Groesse des Wuerfels
   */
  public GraphicCube(int size) {
    this.angleOfLayers = new float[3][size];
    this.size = size;
    this.currentAngle = 0;
    this.currentLayer = 0;
    this.options = Options.getOptionsInstance();
  }

  private void addDelay() {
    try {
      // 42 entspricht etwa 1000/24
      Thread.sleep(15);
    } catch (InterruptedException e) {
      System.out.println("Fehler beim delay in GraphicCube");
    }
  }

  /**
   * Gibt den Winkel der zu dem Parameter passenden Ebene zurueck.
   * 
   * @param axis
   *          Gewuenschte Achse 0= X, 1= Y und 2= Z.
   * @param layer
   *          Position der Ebene im Winkel-Array
   * @return Winkel der Ebene aus dem Winkel Array
   * */
  public float getAngle(int axis, int layer) {
    assert (axis >= 0 && axis <= 2) : "Nur 3 Achsen.";
    assert (layer >= 0 && layer < this.size) : "Im Wuerfel bleiben.";
    return this.angleOfLayers[axis][layer];
  }

  /**
   * Gibt den in currentAngle gespeicherten Wert zurueck, dient zur schnellen
   * Abfrage ohne Achsen- und Ebenenwissen.
   * 
   * @return der in currentAngle gespeicherte Wert.
   */
  float getCurrentAngle() {
    return this.currentAngle;
  }

  /**
   * Dient zur Setzung von Winkeln im Winkel-Array
   * 
   * @param layer
   *          Position der Ebene im Winkel-Array
   * @param angle
   *          Winkel, welche die Ebene haben soll.
   * @return true, wenn das setzen des Winkels erfolgreich war.
   * */
  boolean setAngle(int axis, int layer, float angle) {
    assert (axis >= 0 && axis <= 2) : "Nur 3 Achsen.";
    assert (layer >= 0 && layer < this.size) : "Im Wuerfel bleiben.";
    assert (angle >= -90 && angle <= 90) : "Wir fuehren nie groessere Drehungen als 90 grad aus.";
    this.angleOfLayers[axis][layer] = angle;
    this.currentAxis = axis;
    this.currentLayer = layer;
    this.currentAngle = angle;
    
    updateListener();

    return true;
  }

  /**
   * Um weitere Benutzer-Eingaben auf dem Wuerfel ausfuehren zu koennen, muss sich
   * der dargestellte Wuerfel in einer neutralen Position, d.h. alle Winkel sind
   * %90 = 0, befinden. Dies dient dazu, Bewegungen zu vermeiden, welche mit
   * einem echten Zauberwuerfel physikalisch nicht moegich sind. Die Methode
   * animate fuehrt basierend auf der Animationsgeschwindigkeit nacheinander die
   * Winkelaenderungen aus, bis eine gueltige Position erreicht ist.
   * 
   * @param layer
   *          Die zu animierende Ebene
   * @param reset
   *          Ob begonnene Drehung beendet oder zurueckgesetzt werden soll.
   * @return Erfolgreiches animieren erzeugt ein true-Rueckgabewert.
   * */
  boolean animate(boolean reset) {
    /*
     * Der increment ist so gewaehlt, dass eine AnimationSpeed von 0 bei einem
     * StartWinkel von 45 in etwa 100 frames resultiert.
     */
    float increment = 0.45f + 0.045f * (float) options.getAnimationSpeed();
    float workingAngle = this.currentAngle;
    int end;

    if ((workingAngle > 0) && reset) {
      end = 0;
      increment = -increment;
    } else if ((workingAngle < 0) && reset) {
      end = 0;
    } else if ((workingAngle > 0) && !reset) {
      end = 90;
    } else if ((workingAngle < 0) && !reset) {
      end = -90;
      increment = -increment;
    } else {
      end = 0;
    }

    if (increment > 0) {
      while (workingAngle < end) {
        addDelay();

        workingAngle = workingAngle + increment;
        // verhindern, dass der Winkel unzulaessige Werte annimmt
        if (workingAngle > end) {
          workingAngle = end;
        }

        // setAngle informiert GraphicObserver!
        this.setAngle(this.currentAxis, this.currentLayer, workingAngle);
      }
    } else {
      while (workingAngle > end) {
        addDelay();
        workingAngle = workingAngle + increment;
        // verhindern, dass der Winkel unzulaessige Werte annimmt
        if (workingAngle < end) {
          workingAngle = end;
        }

        // setAngle informiert GraphicObserver!
        this.setAngle(this.currentAxis, this.currentLayer, workingAngle);
      }
    }

    return true;
  }

  /**
   * Fuehrt basierend auf der Animationsgeschwindigkeit automatische
   * Winkelaenderungen aller Ebenen entlang der X/y/Z-Achsen aus, bis diese 90
   * grad rotiert sind , d.h. der gesamte Wuerfel dreht sich.
   * 
   * @param clockwise
   *          Dient der Richtungssteuerung der Rotation. Der Wuerfel dreht sich
   *          um X, Y, Z im Uhrzeigersinn. X Geht von links nach rechts, Y von
   *          oben nach unten, Z von vorne nach hinten, im Raum
   * @return true, wenn die Rotation erfolgreich war.
   * */
  boolean animRotation(boolean clockwise, int axis) {
    assert (axis >= 0 && axis <= 2) : "nur 3 Achsen!";
    this.currentAxis = axis;
    float increment = (0.45f + 0.045f * (float) options.getAnimationSpeed()) * 2;
    int end;
    float workingAngle = 0;
    if (clockwise) {
      end = 90;
      while (workingAngle < end) {
        addDelay();
        workingAngle = workingAngle + increment;
        // verhindern, dass der Winkel unzulaessige Werte annimmt
        if (workingAngle > end) {
          workingAngle = end;
        }
        this.currentAngle = workingAngle;

        for (int i = 0; i < this.size; i++) {
          this.angleOfLayers[axis][i] = workingAngle;
        }

        updateListener();

      }
    } else {
      end = -90;
      while (workingAngle > end) {
        addDelay();
        workingAngle = workingAngle - increment;

        // verhindern, dass der Winkel unzulaessige Werte annimmt
        if (workingAngle < end) {
          workingAngle = end;
        }
        this.currentAngle = workingAngle;

        for (int i = 0; i < this.size; i++) {
          this.angleOfLayers[axis][i] = workingAngle;
        }

        updateListener();
      }
    }

    return true;
  }

  /**
   * Registriert den Observer der die Winkel der Ebenen an die View weitergibt.
   * 
   * @param co
   *          Der Observer
   */
  public void addListener(CubeObserver co) {
    viewObserver = co;
  }

  private void updateListener() {
	  if(viewObserver != null){
          viewObserver.update(this);
	  } else {
          System.out.println(OBSERVER_ERROR);
      }
  }
  /**
   * Setzt den Wuerfel in den urspruenglichen Zustand zurueck, so dass man neue
   * Bewegungen ausfuehren kann.
   * 
   * */
  void reset() {
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < this.angleOfLayers[i].length; j++) {
        this.angleOfLayers[i][j] = 0;
      }
    }
    this.currentAngle = 0;
    this.currentAxis = 0;
    this.currentLayer = 0;
    //setAngle informiert observer
    this.setAngle(this.currentAxis, this.currentLayer, currentAngle);
  }
}
