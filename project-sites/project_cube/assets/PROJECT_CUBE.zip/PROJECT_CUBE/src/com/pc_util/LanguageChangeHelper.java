package com.pc_util;

import java.util.Locale;

import android.app.Activity;
import android.content.res.Configuration;

import com.pc_model.Options;

public class LanguageChangeHelper {
  private LanguageChangeHelper() {

  }

  /**
   * Setzt die Sprache neu.
   * 
   * @param language
   *          der Name der Sprache aus values/Strings.xml, der fuer die Sprache
   *          steht.
   */
  public static void setNewLanguage(Activity act, Options opt, String language) {
    if (act != null && language != null && language != "" && opt != null) {
      opt.setLanguage(language);
      setLanguage(act, language);
    }
  }

  /**
   * Veraendert die Sprache. Muss vor dem Aufruf einer ContentView geschehen.
   * 
   * @param language
   *          der Name der Sprache aus values/Strings.xml, der fuer die Sprache
   *          steht.
   */
  public static void setLanguage(Activity act, String language) {
    if (act != null && language != null && language != "") {
      Locale locale = new Locale(language.substring(0, 3));
      Locale.setDefault(locale);
      
      Configuration config = new Configuration();
      config.locale = locale;
      act.getBaseContext().getResources().updateConfiguration(config, null);
    }
  }
}
