package com.pc_util;

import java.util.ArrayList;

import com.pc_model.Turn;

/**
 * Diese Klasse stellt einen Pseudozufallsgenerator zur Verf###gung, der Zugfolgen
 * f###r Zauberw###rfel zuf###llig generiert und diese eindeutig als Key codiert.
 * Andersherum kann f###r einen eindeutigen Key die entsprechende Zugfolge
 * berechnet werden. Ein Key ist ein String aus Ascii-Buchstaben und ganzen
 * Zahlen zwischen 0 und 9.
 */
public interface Randomizer {

  /**
   * Gibt einen Key aus, der eine Zugfolge auf einem Zauberw###rfel eindeutig
   * codiert. Besteht nur aus Ascii-Buchstaben und ganzen Zahlen zwischen 0 und
   * 9.
   * 
   * @return einen Key
   */
  long generateKey(); 
  
  /**
   * Diese Funktion nimmt einen eindeutigen Key entgegen und berechnet die dazu
   * geh###rige Zugfolge f###r den Zauberw###rfel. Ist der Key nicht eindeutig oder
   * besteht er nicht aus Ascii-Buchstaben und ganzen Zahlen zwischen 0 und 9,
   * wird eine IllegalArgumentException geworfen.
   * 
   * @param key
   *          Ein String aus Ascii-Zeichen und ganzen Zahlen zwischen 0 und 9.
   *          Sollte eine Zauberw###rfelzugfolge eindeutig beschreiben
   * @return eine Liste von Zugfolgen auf einem Zauberw###rfel vom typ Turn
   */
  ArrayList<Turn> generateTurns(long key , int nrOfTurns); 

  /**
   * Gibt den zuletzt generierten Key aus, der eine Zugfolge auf einem
   * Zauberwuerfel eindeutig codiert. Besteht nur aus Ascii-Buchstaben und ganzen
   * Zahlen zwischen 0 und 9. null, falls noch kein Key generiert wurde.
   * 
   * @return einen Key
   */
  long getLastKey(); 
   
  /**Prueft, ob der key valid ist.
   * @param key der zu pruefende key
   * @return valid*/
  public boolean testKey(long key);
    
}
