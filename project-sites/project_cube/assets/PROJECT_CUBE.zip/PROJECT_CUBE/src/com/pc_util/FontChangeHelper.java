package com.pc_util;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pc_model.Options;

/**
 * Diese Klasse hilft beim aendern des Fonts. Der Font ist in der Constants
 * Klasse festgelegt.
 * 
 * @author AxP
 * 
 */
public class FontChangeHelper {
  private static final String CCEXC = "ClassCastException: changeFonts(Activity act, Options opt, ViewGroup root, TextView[] views): ";
  private static final String NPEXC = "NullPointerException: changeFonts(Activity act, Options opt, ViewGroup root, TextView[] views): ";

  private static final String COLOR_TITLE = "#fffffe";
  private static final String COLOR_SMALLER_STANDARD = "#ffffef";
  private static final String COLOR_BIGGER_STANDARD = "#fffeff";
  private static final String COLOR_STANDARD_BTN = "#fffeff";
  private static final String COLOR_MAINMENU_BTN = "#feffff";
  private static final String COLOR_KEYMENU_BTN = "#efffff";

  /*
   * Die Groessen richten sich nach den Farbwerten. 
   */
  // Standart Groessen
  private static final int DIMEN_TITLE_STD = 26;
  private static final int DIMEN_SMALLER_STANDARD_STD = 18;
  private static final int DIMEN_BIGGER_STANDARD_STD = 20;
  private static final int DIMEN_STANDARD_BTN_STD = 15;
  private static final int DIMEN_MAINMENU_BTN_STD = 20;
  private static final int DIMEN_KEYMENU_BTN_STD = 15;
  // CAKE Groessen
  private static final int DIMEN_TITLE_CAKE = 22;
  private static final int DIMEN_SMALLER_STANDARD_CAKE = 13;
  private static final int DIMEN_BIGGER_STANDARD_CAKE = 15;
  private static final int DIMEN_STANDARD_BTN_CAKE = 12;
  private static final int DIMEN_MAINMENU_BTN_CAKE = 15;
  private static final int DIMEN_KEYMENU_BTN_CAKE = 12;
  // Amerika Groessen
  private static final int DIMEN_TITLE_AM = 30;
  private static final int DIMEN_SMALLER_STANDARD_AM = 18;
  private static final int DIMEN_BIGGER_STANDARD_AM = 20;
  private static final int DIMEN_STANDARD_BTN_AM = 15;
  private static final int DIMEN_MAINMENU_BTN_AM = 21;
  private static final int DIMEN_KEYMENU_BTN_AM = 15;
  private static Typeface tf;

  private FontChangeHelper() {

  }

  /**
   * Methode die einen String annimmt und die View Elemente. Es wird entweder
   * eine View Gruppe oder ein Array bearbeitet.
   * 
   * @param act
   *          Context
   * @param font
   *          String/ Fontname
   * @param opt
   *          Optioneninstanz
   * @param root
   *          Wurzelelement im Layout
   */
  public static void changeFonts(Activity act, String font, Options opt, ViewGroup root, TextView[] views) {
    if (font != null) {
      boolean isInArray = false;

      // Font String Kontrolle
      for (String s : Constants.FONTS_ARRAY) {
        if (s.equals(font)) {
          isInArray = true;
        }
      }

      if (isInArray) {
        opt.setFont(font);
        tf = opt.getFont(act);
        changeFonts(act, opt, root, views);
      }

    } else {
      tf = opt.getFont(act);
      changeFonts(act, opt, root, views);
    }
  }

  /**
   * Methode die die Schrifart des gesamten Layouts innerhalb eines bestimmten
   * Layout Knoten aendert. (Rekursiv)
   */
  private static void changeFonts(Activity act, Options opt, ViewGroup root, TextView[] views) {
    try {
      // Mit Root Element
      for (int i = 0; root != null && i < root.getChildCount() && views == null; i++) {
        View v = root.getChildAt(i);

        if (v instanceof TextView) {
          setFont(opt.getActFont(), ((TextView) v), tf);

        } else if (v instanceof ViewGroup) {
          changeFonts(act, opt, (ViewGroup) v, views);
        }
      }

      // Mit Array
      for (int i = 0; views != null && i < views.length && root == null; i++) {
        views[i].setTypeface(tf);
      }

    } catch (ClassCastException exc) {
      System.out.println(CCEXC + " ");
      exc.printStackTrace();

    } catch (NullPointerException exc) {
      System.out.println(NPEXC + exc.getStackTrace());
    }

  }

  /*
   * aendert die Textgroesse entsprechend dem Schriftstil.
   */
  private static void setFont(String font, TextView v, Typeface tf) {
    // Standard Font Text Groessen FONT_NOFONT
    if (font.equals(Constants.FONT_NOFONT)) {
      if (v.getCurrentTextColor() == Color.parseColor(COLOR_TITLE)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_TITLE_STD);
        v.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_SMALLER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_SMALLER_STANDARD_STD);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_BIGGER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_BIGGER_STANDARD_STD);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_STANDARD_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_STANDARD_BTN_STD);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_MAINMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_MAINMENU_BTN_STD);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_KEYMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_KEYMENU_BTN_STD);
      }

      // Font 2 Text Groessen FONT_FAIRYCAKE
    } else if (font.equals(Constants.FONT_FAIRYCAKE)) {
      v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_STANDARD_BTN_CAKE);

      if (v.getCurrentTextColor() == Color.parseColor(COLOR_TITLE)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_TITLE_CAKE);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_SMALLER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_SMALLER_STANDARD_CAKE);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_BIGGER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_BIGGER_STANDARD_CAKE);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_STANDARD_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_STANDARD_BTN_CAKE);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_MAINMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_MAINMENU_BTN_CAKE);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_KEYMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_KEYMENU_BTN_CAKE);
      }

      // Font 2 Text Groessen FONT_AMERIKA
    } else if (font.equals(Constants.FONT_AMERIKA)) {
      v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_STANDARD_BTN_AM);

      if (v.getCurrentTextColor() == Color.parseColor(COLOR_TITLE)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_TITLE_AM);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_SMALLER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_SMALLER_STANDARD_AM);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_BIGGER_STANDARD)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_BIGGER_STANDARD_AM);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_STANDARD_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_STANDARD_BTN_AM);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_MAINMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_MAINMENU_BTN_AM);

      } else if (v.getCurrentTextColor() == Color.parseColor(COLOR_KEYMENU_BTN)) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, DIMEN_KEYMENU_BTN_AM);
      }
    }

    v.setTypeface(tf);
  }
}
