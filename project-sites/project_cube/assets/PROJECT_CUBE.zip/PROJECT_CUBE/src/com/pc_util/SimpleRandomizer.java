package com.pc_util;

import java.util.ArrayList;
import java.util.Random;

import com.pc_model.Turn;
import com.pc_util.Constants.TurnType;
import com.pc_util.Randomizer;


/**
 * Diese Klasse stellt einen Pseudozufallsgenerator zur Verfuegung, der Zugfolgen
 * fuer Zauberwuerfel zufaellig generiert und diese eindeutig als Key codiert.
 * Andersherum kann fuer einen eindeutigen Key die entsprechende Zugfolge
 * berechnet werden. Ein Key ist ein String aus Ascii-Buchstaben und ganzen
 * Zahlen zwischen 0 und 9.
 */
public final class SimpleRandomizer implements Randomizer {

  /* Der zuletzt generierte Key. Falls noch kein Key generiert wurde -1. */
  private static long lastKey = -1;

  
  private static ArrayList<Turn> randomTurns = new ArrayList<Turn>();
  
  /*
   * Erstellt einen Pseudozahlengenerator, der Zugfolgen auf einem Zauberwuerfel
   * zufaellig generiert und diese eindeutig als Key codieren kann. Andersherum
   * kann fuer einen eindeutigen Key die entsprechende Zugfolge berechnet werden.
   * Ein Key ist ein String aus Ascii-Buchstaben und ganzen Zahlen zwischen 0
   * und 9.
   */
  public SimpleRandomizer() {
    
  }

  /**
   * Gibt einen Key aus, der eine Zugfolge auf einem Zauberwuerfel eindeutig
   * codiert. Besteht nur aus Ascii-Buchstaben und ganzen Zahlen zwischen 0 und
   * 9.
   * 
   * @return einen Key
   */
  public long generateKey() {
      Random keyGenerator = new Random();
      
      int[] gen = new int[13];
      
      
      for(int i = 0; i < 12; i++) {
        gen[i] = keyGenerator.nextInt(10);
      }
      
      if(gen[0] == 0) {
        gen[0] = 1;
      }
      
      gen[12] = (10 - ((gen[0] + gen[2] + gen[4] + gen[6] + gen[8] + gen[10]
          + 3* (gen[1] + gen[3] + gen[5] + gen[7] + gen[9] + gen[11]))%10))%10;
      
      
      long key = gen[0];
      
      for(int j = 1; j < 13; j++) {
        key = key * 10 + gen[j];
      }
      
      return key;
  }

  /**
   * Diese Funktion nimmt einen eindeutigen Key entgegen und berechnet die dazu
   * gehoerige Zugfolge fuer den Zauberwuerfel. Ist der Key nicht eindeutig oder
   * besteht er nicht aus Ascii-Buchstaben und ganzen Zahlen zwischen 0 und 9,
   * wird eine IllegalArgumentException geworfen.
   * 
   * @param key
   *          Ein String aus Ascii-Zeichen und ganzen Zahlen zwischen 0 und 9.
   *          Sollte eine Zauberwuerfelzugfolge eindeutig beschreiben
   * @return eine Liste von Zugfolgen auf einem Zauberwuerfel vom typ Turn
   * 
   * @throws IllegalArgumentException
   */
  public ArrayList<Turn> generateTurns(long key , int nrOfTurns) throws IllegalArgumentException {
    
        if(testKey(key) == false) {
          throw new IllegalArgumentException("Das gegebene Key ist nicht gueltig");
        } else {

          lastKey = key;
                
          randomTurns.clear();        
          
          //zum testen
          if(key == 1337) {
              randomTurns.add(new Turn(TurnType.F, Constants.FRONT, Constants.LEFT));
              return randomTurns;
          } 
  
          randomTurns.ensureCapacity(nrOfTurns);      
  
                 
          
          Random turnGenerator = new Random(key);
        
        
          for (int i = 0; i < nrOfTurns; i++) {
              
              int turn = turnGenerator.nextInt(18) + 1;
              
              switch(turn) {
                  case 1: randomTurns.add(new Turn(TurnType.F, Constants.FRONT, Constants.LEFT));      break;
                  case 2: randomTurns.add(new Turn(TurnType.FPRIME, Constants.FRONT, Constants.LEFT));         break;
                  case 3: randomTurns.add(new Turn(TurnType.L, Constants.FRONT, Constants.LEFT));      break;
                  case 4: randomTurns.add(new Turn(TurnType.LPRIME, Constants.FRONT, Constants.LEFT));         break;
                  case 5: randomTurns.add(new Turn(TurnType.R, Constants.FRONT, Constants.LEFT));      break;
                  case 6: randomTurns.add(new Turn(TurnType.RPRIME, Constants.FRONT, Constants.LEFT));         break;
                  case 7: randomTurns.add(new Turn(TurnType.B, Constants.FRONT, Constants.LEFT));      break;
                  case 8: randomTurns.add(new Turn(TurnType.BPRIME, Constants.FRONT, Constants.LEFT));         break;
                  case 9: randomTurns.add(new Turn(TurnType.U, Constants.FRONT, Constants.LEFT));      break;
                  case 10: randomTurns.add(new Turn(TurnType.UPRIME, Constants.FRONT, Constants.LEFT));    break;
                  case 11: randomTurns.add(new Turn(TurnType.D, Constants.FRONT, Constants.LEFT));     break;
                  case 12: randomTurns.add(new Turn(TurnType.DPRIME, Constants.FRONT, Constants.LEFT));    break;
                  case 13: randomTurns.add(new Turn(TurnType.M, Constants.FRONT, Constants.LEFT));     break;
                  case 14: randomTurns.add(new Turn(TurnType.MPRIME, Constants.FRONT, Constants.LEFT));    break;
                  case 15: randomTurns.add(new Turn(TurnType.E, Constants.FRONT, Constants.LEFT));     break;
                  case 16: randomTurns.add(new Turn(TurnType.EPRIME, Constants.FRONT, Constants.LEFT));    break;
                  case 17: randomTurns.add(new Turn(TurnType.S, Constants.FRONT, Constants.LEFT));     break;
                  case 18: randomTurns.add(new Turn(TurnType.SPRIME, Constants.FRONT, Constants.LEFT));    break;
                  
                  
                          
              }
              
          }
        
        return randomTurns;
        
      }
  }

  /*
   * Diese Methode testet eine eingegebene Key ob die der Codierung stimmt
   * @param der key
   * @return true wenn das key gut ist false wenn nicht 
   */  
  public boolean testKey(long key) {
    
    String gen = String.valueOf(key);
    
    boolean goodKey = false;
    
    if(gen.length() == 13){
      
      int[] test = new int[gen.length()];
      
      for (int x = 0; x < gen.length(); x++) {
      
        test[x] = gen.charAt(x) - 48;
      }
      
      int sum = (test[0] + test[2] + test[4] + test[6] + test[8] + test[10] + test[12]
          + 3* (test[1] + test[3] + test[5] + test[7] + test[9] + test[11]))%10;
      
      if (sum == 0) {
          goodKey = true;
      }
      
    }
    
    
    
    //cheat fuer testen
    if(key == 1337) {
      goodKey = true;
    }
    
    if (goodKey == false) {
      System.out.println("generate Key mit error: " + key);
    }
    
    return goodKey;
    
  }

  /**
   * Gibt den zuletzt generierten Key aus, der eine Zugfolge auf einem
   * Zauberwuerfel eindeutig codiert. Besteht aus Zahlen zwischen 0 und 9. 
   * -1, falls noch kein Key generiert wurde.
   * 
   * @return einen Key
   */
  public long getLastKey() {
    
     return lastKey;
         
  }
  
    
}
