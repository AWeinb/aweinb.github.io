package com.pc_util;

import android.graphics.Color;

/**
 * Konstanten-Klasse fuer die Darstellung von Zauberwuerfelflaechen, -zuegen und
 * -positionen. Globale Programmkonstanten zur zentralen Verwaltung von Werten,
 * die an verschiedenen Stellen im Programm gebraucht werden.
 */
public class Constants {
  /** Konstante fuer die Deckseite des Zauberwuerfels. */
  public static final int UP = 0;

  /** Konstante fuer die Unterseite des Zauberwuerfels. */
  public static final int DOWN = 1;
  
  /** Konstante fuer die Vorderseite des Zauberwuerfels. */
  public static final int FRONT = 2;
  
  /** Konstante fuer die Hinterseite des Zauberwuerfels. */
  public static final int BACK = 3;

  /** Konstante fuer die rechte Seite des Zauberwuerfels. */
  public static final int RIGHT = 4;

  /** Konstante fuer die linke Seite des Zauberwuerfels. */
  public static final int LEFT = 5;

  /**
   * Konstanten fuer die Standardfarben eines Zauberwuerfels. Diese sind: RED =
   * rot, WHI = weiss, ORA = orange, YEL = gelb, GRE = gruen, BLU = blau.
   * */
  public static enum Colour {
    RED, WHI, ORA, YEL, GRE, BLU
  }

  /**
   * Es folgen Standard-Alapha-RGB-Werte fuer die 6 Farben
   **/

  /** Standard-Alpha-RGB-Wert der Farbe GREEN **/
  public final static int GRE = 0xFF00FF00;
  /** Standard-Alpha-RGB-Wert der Farbe RED **/
  public final static int RED = 0xFFFF0000;
  /** Standard-Alpha-RGB-Wert der Farbe WHITE **/
  public final static int WHI = 0xFFFFFFFF;
  /** Standard-Alpha-RGB-Wert der Farbe ORANGE **/
  public final static int ORA = 0xFFFF8C00;
  /** Standard-Alpha-RGB-Wert der Farbe YELLOW **/
  public final static int YEL = 0xFFFFFF00;
  /** Standard-Alpha-RGB-Wert der Farbe BLUE **/
  public final static int BLU = 0xFF0000FF;

  /** Character-Repraesentation der Farbe rot **/
  public final static char REDchar = 'R';
  /** Character-Repraesentation der Farbe blau **/
  public final static char BLUchar = 'B';
  /** Character-Repraesentation der Farbe gelb **/
  public final static char YELchar = 'Y';
  /** Character-Repraesentation der Farbe gruen **/
  public final static char GREchar = 'G';
  /** Character-Repraesentation der Farbe weiss **/
  public final static char WHIchar = 'W';
  /** Character-Repraesentation der Farbe orange **/
  public final static char ORAchar = 'O';

  /**
   * Konstanten fuer die Zuege eines Zauberwuerfels der Groesse 3x3x3. Diese sind
   * Standardisiert nach der 'Singmaster notation'. Wenn PRIME einem Buchstaben
   * folgt, erfolgt der Zug gegen den Uhrzeigersinn, ohne PRIME erfolgt er mit
   * dem Uhrzeigersinn.
   */

  public enum TurnType {
    ENDOFLINE,
    /* F (Front): die Vorderseite */
    F, FPRIME,
    /* L (Left): die linke Seite */
    L, LPRIME,
    /* L (Left): die linke Seite */
    R, RPRIME,
    /* R (Right): die rechte Seite */
    B, BPRIME,
    /* B (Back): die Rueckseite */
    U, UPRIME,
    /* U (Up): die Deckseite */
    D, DPRIME,
    /* D (Down): die Unterseite */
    M, MPRIME,
    /* M (Middle): die Ebene zwischen L und R, Zugrichtung wie L (top-down) */
    E, EPRIME,
    /* E (Equator): die Ebene zwischen U und D, Zugrichtung wie D (left-right) */
    S, SPRIME,
    /* S (Standing): die Ebene zwischen F and B, Zugrichtung wie F */
    ROTX, ROTXPRIME,
    /* ROTX (rotate): Drehe den ganzen Wuerfel um R */
    ROTY, ROTYPRIME,
    /* ROTY (rotate): Drehe den ganzen Wuerfel um U */
    ROTZ, ROTZPRIME;
    /* ROTZ (rotate): Drehe den ganzen Wuerfel um F */

    public TurnType getInverse() {
      switch (this.ordinal()) {
        case 1:
          return FPRIME;
        case 2:
          return F;
        case 3:
          return LPRIME;
        case 4:
          return L;
        case 5:
          return RPRIME;
        case 6:
          return R;
        case 7:
          return BPRIME;
        case 8:
          return B;
        case 9:
          return UPRIME;
        case 10:
          return U;
        case 11:
          return DPRIME;
        case 12:
          return D;
        case 13:
          return MPRIME;
        case 14:
          return M;
        case 15:
          return EPRIME;
        case 16:
          return E;
        case 17:
          return SPRIME;
        case 18:
          return S;
        case 19:
          return ROTXPRIME;
        case 20:
          return ROTX;
        case 21:
          return ROTYPRIME;
        case 22:
          return ROTY;
        case 23:
          return ROTZPRIME;
        case 24:
          return ROTZ;

        default:
          return null;

      }
    }
  }

  /**
   * Untere Grenze des Animationsgeschwindigkeit-Intervalls. Kann veraendert
   * werden, ist aber nicht empfohlen, da diverse Android-Widgets wie
   * beispielsweise die Seekbar keine negativen Zahlen annehmen und 0 der
   * Standard ist (kann dort auch nicht geaendert werden).
   */
  public static final int ANIM_SPEED_MIN = 0;
  /**
   * Obere Grenze des Animationsgeschwindigkeit-Intervalls. Kann beliebig
   * veraendert werden. Der Standard einer Android Seekbar ist 100.
   */
  public static final int ANIM_SPEED_MAX = 100;

  /**
   * Die urspruengliche Gewschindigkeitseinstellung enstrprich der Haelfte des
   * Maximalwerts.
   **/
  public static final int ANIM_SPEED_STANDARD = ANIM_SPEED_MAX / 2;

  /** Legt die Anzahl der Eintraege in der Bestenliste fest. */
  public static final int HIGHSCORE_ENTRIES = 10;

  /** Normalerweise wird ein Wuerfel zu beginn eines Spieles 20 mal verdreht. **/
  public static final int NUMBER_OF_MOVES = 20;

  /** Stringrepraesentation fuer keine Sprache angegeben **/
  public final static String NOLANGUAGE = "Standard";
  
  /** Stringrepraesentation fuer kein Farbthema angegeben **/
  public final static String NOTHEME = "Standard";
  
  public final static String THEME1 = "Theme1";
  // Theme 1 Farben
  public final static int THEME1_TOP = Color.parseColor("#665535");
  public final static int THEME1_BTM = Color.parseColor("#FFCC8A");
  public final static int THEME1_FRO = Color.parseColor("#FFD724");
  public final static int THEME1_BAC = Color.parseColor("#ED5B00");
  public final static int THEME1_LEF = Color.parseColor("#FF9D00");
  public final static int THEME1_RIG = Color.parseColor("#5E0900");
  // Ende Theme 1 Farben
  
  public final static String THEME2 = "Theme2";
  // Theme 1 Farben
  public final static int THEME2_TOP = Color.parseColor("#BF4B30");
  public final static int THEME2_BTM = Color.parseColor("#FFBD73");
  public final static int THEME2_FRO = Color.parseColor("#225E79");
  public final static int THEME2_BAC = Color.parseColor("#37DB79");
  public final static int THEME2_LEF = Color.parseColor("#A62000");
  public final static int THEME2_RIG = Color.parseColor("#FF8700");
  // Ende Theme 1 Farben
  
  public static final String[] THEME_ARRAY = {NOTHEME, THEME1, THEME2};

  /** Stringrepraesentation fuer keinen Farbfilter angegeben **/
  public final static String NOFILTER = "Standard";
  public static final String FILTER1 = "Filter 1";

  public static final String[] FILTER_ARRAY = {NOTHEME, FILTER1};
  
  /** Stringrepraesentation fuer keine Schriftart **/
  public final static String FONT_NOFONT = "Standard Font";
  /** Stringrepraesentation fuer Fairy Cake **/
  public final static String FONT_FAIRYCAKE = "Yearsupplyoffairycakes.ttf";
  /** Stringrepraesentation fuer AMERIKA_.ttf **/
  public final static String FONT_AMERIKA = "AMERIKA_.ttf";
  
  public static final String[] FONTS_ARRAY = {FONT_NOFONT, FONT_FAIRYCAKE, FONT_AMERIKA};
  
  /**
   * Dieses Zeichen dient in Speicherstrings zur Trennung von Segmenten und
   * Werten
   **/
  public final static String SEPARATOR = "#";

  public final static String TURNSEPERATOR = ",";
  
  /**
   * DummyWert, um nicht belegte HighScores darzustellen [Platzierung][{name,
   * counter, time}]
   **/
  public final static String[][] DUMMY = { { "MaxMustermann", "999", "9999999999999999" } };

  /** Universitaets URL, benutzt im Impressum */
  public static final String KIT_URL = "http://www.kit.edu";
  /** Entwickler URL, benutzt im Impressum */
  public static final String ANDROID_URL = "http://developer.android.com";

  /** Put Extra Name */
  public static final String INTENT_FIRSTSTARTUP = "firstStartUp";
  public static final String INTENT_FROMRUN = "fromRun";
  public static final String INTENT_FROM_OPTIONS = "fromOptionsToGame";
  public static final String INTENT_NEWGAME = "newGame";
  public static final String INTENT_TOURNAMENT = "tournament";

  public static int NAMELENGTH = 15;

  public static String STANDARDNAME = "Anonymous";

}
