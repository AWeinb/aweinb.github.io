package com.pc_util;

import java.util.ArrayList;

import android.util.Log;

import com.pc_model.Cube;
import com.pc_model.Turn;
import com.pc_util.Constants;
import com.pc_util.Constants.Colour;
import com.pc_util.Constants.TurnType;

//http://www.ryanheise.com/cube/beginner.html

//TO DO hinter Interface verstecken wenn es funktioniert
//kommentieren

/**
 * Diese Klasse stellt einen Loesungsalgorithmus fuer den sogenannten
 * Zauberwuerfel bereit. Der Algorithmus stellt nicht den mathematisch
 * effizientesten Algorithmus dar, sonder rechnet in 'menschlichen' Schritten.
 * Er sucht zuerst die optimale Startflaeche und berechnet dann anhand einer
 * Kopie des aktuellen Wuerfelmodells eine Zugfolge, die zur Loesung dieses
 * Wuerfels fuehrt.
 */
public final class Solver {
  /*
   * Eine Kopie des aktuellen Wuerfels, auf der der Algorithmus die Loesung
   * berechnen kann.
   */
  private static Cube cubeCopy = null;

  private static ArrayList<Turn> solution = new ArrayList<Turn>();

  /*
   * privates Konstruktor.
   */
  private Solver(Cube cubeCopy) {

  }

  /**
   * Bekommt einen ungeloesten Wuerfel, berechnet eine Zugfolge, die zur
   * vollstaendigen Loesung des Wuerfels fuehrt und gibt diese aus. Gibt eine
   * leere Liste aus, falls der Eingabe-wuerfel schon geloest ist.
   * 
   * @param cube
   *          ein ungeloester Wuerfel. Kann in dieser Version nur die Groesse
   *          3x3x3 haben. Andernfalls wird eine IllegalArgumentException
   *          geworfen.
   * @return eine Liste von Turns, die zur vollstaendigen Loesung des Wuerfels
   *         fuehrt. Leer, falls der Eingabe-Wuerfel geloest ist.
   */
  public static ArrayList<Turn> solve(Cube cube) {

    cubeCopy = cube;

    solution.clear();

    // test cube solved
    // throw illegal argument if cube size != 3

    solution.ensureCapacity(100);

    int face = optimalFace();

    int state = getState(face);

    // nicht wirkich noetig
    findSide(face);

    switch (state) {
      case 0:
        solveFirstStep();
      case 1:
        ;
      case 2:
        ;
      case 3:
        ;
      case 4:
        solveSecondStep(4);
      case 5:
        ;
      case 6:
        ;
      case 7:
        ;
      case 8:
        solveSecondLayer(4);
      case 9:
        solveUpperCross();
      case 10:
        solveUpperCorners();
      case 11:
        correctUpperCorners();
      case 12:
        correctUpperCross();
        break;

    }

    solution.trimToSize();

    return solution;
  }

  /**
   * Bekommt einen ungeloesten Wuerfel, berechnet eine Zugfolge, die einen
   * Loesungsschritt darstellt und gibt diese aus. Gibt eine leere Liste aus,
   * falls der Eingabe-wuerfel schon geloest ist.
   * 
   * @param cube
   *          ein ungeloester Wuerfel. Kann in dieser Version nur die Groesse
   *          3x3x3 haben. Andernfalls wird eine IllegalArgumentException
   *          geworfen.
   * @return eine Liste von Turns, die einen Loesungsschritt darstellt. Leer,
   *         falls der Eingabe-Wuerfel geloest ist.
   */
  public static ArrayList<Turn> solveNextStep(Cube cube) {

    cubeCopy = cube;

    solution.clear();

    solution.ensureCapacity(30);

    if (cubeCopy.getFace(Constants.FRONT).getPermut().length != 3) {
      throw new IllegalArgumentException("Der Wuerfel hat nicht die richtige Groesse!");
    } else if (cube.isSolved()) {
      return null;
    } else {

      int face = optimalFace();

      Log.v("Solver: Optimal Face: ", String.valueOf(face));

      int state = getState(face);

      Log.v("Solver: State: ", String.valueOf(state));

      // nicht wirkich noetig
      findSide(face);

      switch (state) {
        case 0:
          solveFirstStep();
          break;
        case 1:
          solveSecondStep(1);
          break;
        case 2:
          solveSecondStep(2);
          break;
        case 3:
          solveSecondStep(3);
          break;
        case 4:
          solveSecondStep(4);
          break;
        case 5:
          solveSecondLayer(1);
          break;
        case 6:
          solveSecondLayer(2);
          break;
        case 7:
          solveSecondLayer(3);
          break;
        case 8:
          solveSecondLayer(4);
          break;
        case 9:
          solveUpperCross();
          break;
        case 10:
          solveUpperCorners();
          break;
        case 11:
          correctUpperCorners();
          break;
        case 12:
          correctUpperCross();
          break;

      }

      solution.trimToSize();

      return solution;
    }
  }

  /*
   * Berechnet die optimale Startflaeche fuer den Loesungsalgorithmus. Kann eine
   * bereits geloeste Flaeche sein, kann aber auch eine nur unvollstaendig
   * geloeste Flaeche sein.
   * 
   * @param cube ein ungeloester Wuerfel. Kann in dieser Version nur die Groesse
   * 3x3x3 haben. Andernfalls wird eine IllegalArgumentException geworfen.
   * 
   * @return die fuer den Loesungsalgorithmus optimale Startflaeche. Kann in
   * dieser Version nur die Groesse 3x3 haben. Andernfalls wird eine
   * IllegalArgumentException geworfen.
   */
  private static int optimalFace() {

    int face = -1;
    int biggest = -1;

    int[] faceTest = new int[6];

    for (int i = 0; i < 6; i++) {
      faceTest[i] = getState(i);
    }

    for (int i = 0; i < 6; i++) {

      if (faceTest[i] > biggest) {
        biggest = faceTest[i];
        face = i;
      }

    }

    return face;
  }

  /*
   * Diese Methode berechnet wie weit der Wuerfel entlang der gegebenen
   * Algorithmus fuer eine bestimmte Seite ist. Keine der benutzten Methoden
   * aendert die Wuerfelkopie.
   * 
   * @param Die Seite die vorne stehen sollte am anfang der Test.
   */
  private static int getState(int sideID) {

    // Man richtet den Cube auf die Seite von dem man testen will
    findSide(sideID);

    // Diese Variable bezeichnet die Stufe des Algorythmus die schon auf dem
    // Wuerfel geloest ist.
    int state = 0;

    if (testFirstLayerEdge() == 4) {
      state++;

      if (testFirstLayerCorners() == 4) {
        state = state + 4;

        if (testSecondLayerEdges() == 4) {
          state = state + 4;

          if (testUpperCross() == 4) {
            state++;

            if (testUpperCorners() == 4) {
              state++;

              if (testCorrectUpperCorners() == 4) {
                state++;

                if (testCorrectUpperCross() == 4) {
                  state++;

                }
              }
            }
          }

        } else {
          state = state + testSecondLayerEdges();
        }

      } else {
        state = state + testFirstLayerCorners();
      }

    }

    return state;
  }

  /*
   * Diese Methode wird benutzt um die cubeCopy nach eine bestimmte Seite zu
   * richten.
   * 
   * @param Die Seite die man danach vorne haben will.
   */
  private static void findSide(int sideID) {

    assert (sideID <= 5 && sideID >= 0) : "Ein Wuerfel hat nur 6 Seiten.";

    // Es gibt 6 Seite und die werden zu zweit getestet deshalb hat man 3
    // durchgaenge;
    for (int i = 0; i < 3; i++) {
      // Man testet, ob die vordere Seite die gesuchte ist.
      if (cubeCopy.getFrontID() == sideID) {
        return;
      }

      // Man verdreht den Wuerfel auf eine neue Seite.
      addTurn(TurnType.ROTY);

      // Man testet, ob die vordere Seite die gesuchte ist.
      if (cubeCopy.getFrontID() == sideID) {
        return;
      }

      // Man verdreht den Wuerfel auf eine neue Seite.
      addTurn(TurnType.ROTXPRIME);

    }

  }

  /*
   * Kontrollmethode um den ersten Schritt zu losen.
   */
  private static void solveFirstStep() {
    // Annahme, dass man schon auf die "richtige" Seite guckt

    // int nrGoodEdges = testFirstLayerEdge();

    for (int i = 0; i < 4; i++) {
      if (testUpperEdge()) {
        addTurn(TurnType.ROTZPRIME);
      } else {
        solveFirstLayerEdge();
        addTurn(TurnType.ROTZPRIME);
      }
    }
    // assert time

  }

  /*
   * Diese Methode zaehlt die Anzahl der Mittelstuecke die an der richtigen
   * Stelle sind auf die vordere Seite (die Seite suf dem das Algorithmus
   * arbeiten wird). Die Verschiedenen Positionen, die getestet werden muessen,
   * sind hardcoded und die Methode aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen Mittelstuecke
   */
  private static int testFirstLayerEdge() {

    // Diese Variable bezeichnet die Anzahl der richtig liegenden Mittlestuecke
    // auf der vorderen Seite.
    int nrCorrectEdges = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();

    // Testen des oberen Mittelstuecks (Edge)
    if ((frontFace[0][1] == frontFace[1][1]) && (upFace[2][1] == upFace[1][1])) {
      nrCorrectEdges++;
    }

    // Testen des rechten Mittelstuecks (Edge)
    if ((frontFace[1][2] == frontFace[1][1]) && (rightFace[1][0] == rightFace[1][1])) {
      nrCorrectEdges++;
    }

    // Testen des unteren Mittelstuecks (Edge)
    if ((frontFace[2][1] == frontFace[1][1]) && (downFace[0][1] == downFace[1][1])) {
      nrCorrectEdges++;
    }

    // Testen des linken Mittelstuecks (Edge)
    if ((frontFace[1][0] == frontFace[1][1]) && (leftFace[1][2] == leftFace[1][1])) {
      nrCorrectEdges++;
    }

    // Anzahl der richtigen Mittelsuecke wird zurueckgegeben.
    return nrCorrectEdges;
  }

  /*
   * Diese Methode testet ob der obere Mittelstueck der richtige ist.
   * 
   * @return true wenn der mittelstueck passt, false in allen anderen Faelle.
   */
  private static boolean testUpperEdge() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();

    // Man testet ob der obere Mittelstueck der richtige ist.
    if ((frontFace[0][1] == frontFace[1][1]) && (upFace[2][1] == upFace[1][1])) {
      return true;
    } else {
      return false;
    }
  }

  /*
   * Testet alle Platze wo der richtige Mittelstuck sein konnte und bewegt sie
   * auf die richtige Stelle.
   */
  // TODO chained if else und ohne boolean return
  private static boolean solveFirstLayerEdge() {
    // Annahme, dass man schon auf die "richtige" Seite guckt

    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();

    if ((frontFace[1][1] == frontFace[0][1]) && (upFace[1][1] == upFace[2][1])) {
      return true;
    } else {

      Colour one = frontFace[1][1];
      Colour two = upFace[1][1];

      // Man holt die noetigen Faces des Wuerfels.
      Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
      Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
      Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
      Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

      // Vordere Seite nach dem Gesuchten Stueck testen
      // Linkes Teil
      if ((frontFace[1][0] == one) && (leftFace[1][2] == two)) {

        addTurn(TurnType.L);
        addTurn(TurnType.S);

        addTurn(TurnType.UPRIME);

        addTurn(TurnType.SPRIME);
        return true;
      }

      // Unteres Teil
      if ((frontFace[2][1] == one) && (downFace[0][1] == two)) {

        addTurn(TurnType.D);
        addTurn(TurnType.S);
        addTurn(TurnType.S);

        addTurn(TurnType.UPRIME);

        addTurn(TurnType.SPRIME);
        addTurn(TurnType.SPRIME);
        return true;

      }

      // rechtes Teil
      if ((frontFace[1][2] == one) && (rightFace[1][0] == two)) {

        addTurn(TurnType.RPRIME);
        addTurn(TurnType.SPRIME);

        addTurn(TurnType.U);

        addTurn(TurnType.S);
        return true;

      }

      // Obere Seite nach dem gesuchten Stueck testen

      if ((upFace[2][1] == one) && (frontFace[0][1] == two)) {

        addTurn(TurnType.U);
        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((upFace[1][0] == one) && (leftFace[0][1] == two)) {

        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((upFace[0][1] == one) && (backFace[0][1] == two)) {

        addTurn(TurnType.UPRIME);
        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((upFace[1][2] == one) && (rightFace[0][1] == two)) {

        addTurn(TurnType.SPRIME);
        addTurn(TurnType.UPRIME);

        addTurn(TurnType.S);

        return true;

      }

      // Untere Seite nach dem gesuchten Stueck testen

      if ((downFace[0][1] == one) && (frontFace[2][1] == two)) {

        addTurn(TurnType.D);

        addTurn(TurnType.SPRIME);
        addTurn(TurnType.U);

        addTurn(TurnType.S);

        return true;

      }

      if ((downFace[1][0] == one) && (leftFace[2][1] == two)) {

        addTurn(TurnType.S);

        addTurn(TurnType.UPRIME);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((downFace[2][1] == one) && (backFace[2][1] == two)) {

        addTurn(TurnType.B);
        addTurn(TurnType.B);

        addTurn(TurnType.UPRIME);
        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((downFace[1][2] == one) && (rightFace[2][1] == two)) {

        addTurn(TurnType.SPRIME);

        addTurn(TurnType.U);

        addTurn(TurnType.S);

        return true;

      }

      // Rechte Seite nach dem gesuchten Stueck testen

      if ((rightFace[1][0] == one) && (frontFace[1][2] == two)) {

        addTurn(TurnType.R);

        addTurn(TurnType.U);

        return true;

      }

      if ((rightFace[0][1] == one) && (upFace[1][2] == two)) {

        addTurn(TurnType.U);

        return true;

      }

      if ((rightFace[1][2] == one) && (backFace[1][0] == two)) {

        addTurn(TurnType.B);
        addTurn(TurnType.UPRIME);
        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((rightFace[2][1] == one) && (downFace[1][2] == two)) {

        addTurn(TurnType.SPRIME);
        addTurn(TurnType.SPRIME);

        addTurn(TurnType.UPRIME);

        addTurn(TurnType.S);
        addTurn(TurnType.S);

        return true;

      }

      // Linke Seite nach dem gesuchten Stueck testen

      if ((leftFace[1][2] == one) && (frontFace[1][0] == two)) {

        addTurn(TurnType.LPRIME);
        addTurn(TurnType.UPRIME);

        return true;

      }

      if ((leftFace[0][1] == one) && (upFace[1][0] == two)) {

        addTurn(TurnType.UPRIME);

        return true;

      }

      if ((leftFace[1][0] == one) && (backFace[1][2] == two)) {

        addTurn(TurnType.BPRIME);
        addTurn(TurnType.UPRIME);

        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);

        return true;

      }

      if ((leftFace[2][1] == one) && (downFace[1][0] == two)) {

        addTurn(TurnType.S);
        addTurn(TurnType.S);

        addTurn(TurnType.U);

        addTurn(TurnType.SPRIME);
        addTurn(TurnType.SPRIME);

        return true;

      }

      // Hintere Seite nach dem gesuchten Stueck testen

      if ((backFace[0][1] == one) && (upFace[0][1] == two)) {

        addTurn(TurnType.U);
        addTurn(TurnType.U);

        return true;

      }

      if ((backFace[1][0] == one) && (rightFace[1][2] == two)) {

        addTurn(TurnType.B);

        addTurn(TurnType.U);
        addTurn(TurnType.U);

        return true;

      }

      if ((backFace[2][1] == one) && (downFace[2][1] == two)) {

        addTurn(TurnType.B);
        addTurn(TurnType.B);

        addTurn(TurnType.U);
        addTurn(TurnType.U);

        return true;

      }

      if ((backFace[1][2] == one) && (leftFace[1][0] == two)) {

        addTurn(TurnType.BPRIME);

        addTurn(TurnType.U);
        addTurn(TurnType.U);

        return true;

      }
    }

    return false;

  }

  // Ecken der ersten Schicht einfuegen
  private static void solveSecondStep(int target) {

    int correctCorners = testFirstLayerCorners();

    // do whil macht mehr sinn

    while (correctCorners < target) {

      // Die rechte obere Ecke wird getestet
      if (testUpperRightCorner()) {

        addTurn(TurnType.ROTZPRIME);

      } else {

        findFirstLayerCorner();

        insertFirstLayerCorner();
      }

      // aktualisieren des werts
      correctCorners = testFirstLayerCorners();
    }

  }

  /*
   * Diese Methode zaehlt die Anzahl der Ecken die an der richtigen Stelle auf
   * die erste Ebene sind. Die verschiedenen Positionen, die getestet werden
   * muessen, sind hardcoded und die Methode aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen Ecken.
   */
  private static int testFirstLayerCorners() {

    // Diese Variable bezeichnetdie Anzahl der richtig gestellten Ecken der
    // vorderen Seite (erste Ebene).
    int nrOfCorrectCorners = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();

    // testen ob die obere linke Ecke die richtige ist
    if ((frontFace[0][0] == frontFace[1][1]) && (upFace[2][0] == upFace[1][1]) && (leftFace[0][2] == leftFace[1][1])) {

      nrOfCorrectCorners++;
    }

    // testen ob die obere rechte Ecke die richtige ist
    if ((frontFace[0][2] == frontFace[1][1]) && (upFace[2][2] == upFace[1][1]) && (rightFace[0][0] == rightFace[1][1])) {

      nrOfCorrectCorners++;
    }

    // testen ob die untere linke Ecke die richtige ist
    if ((frontFace[2][0] == frontFace[1][1]) && (downFace[0][0] == downFace[1][1]) && (leftFace[2][2] == leftFace[1][1])) {

      nrOfCorrectCorners++;
    }

    // testen ob die untere rechte Ecke die richtige ist
    if ((frontFace[2][2] == frontFace[1][1]) && (downFace[0][2] == downFace[1][1]) && (rightFace[2][0] == rightFace[1][1])) {

      nrOfCorrectCorners++;
    }

    // Anzahl der richtigen Ecken wird zurueckgegeben.
    return nrOfCorrectCorners;
  }

  /*
   * Testet ob, von vorne gesehen (d.h die erste geloeste Ebene ist nach vorne
   * gerichtet), die rechte obere Ecke richtig gesetzt ist.
   * 
   * @return true wenn die Ecke die richtige ist, false anderfalls
   */
  private static boolean testUpperRightCorner() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();

    // Man testet ob die obere rechte Ecke die richtige ist.
    if ((frontFace[0][2] == frontFace[1][1]) && (upFace[2][2] == upFace[1][1]) && (rightFace[0][0] == rightFace[1][1])) {
      return true;
    } else {
      return false;
    }
  }

  /*
   * Sucht auf dem Wuerfel nach der Ecke, dass vorne oben rechts gehoert und
   * stellt sie hinten oben rechts.
   */
  // TODO Muss nicht boolean sein...
  private static boolean findFirstLayerCorner() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();

    // Man definiert die gesuchten Farben
    Colour one = frontFace[1][1];
    Colour two = upFace[1][1];
    Colour three = rightFace[1][1];

    boolean caseFound = false;

    // Der hintere obere rechte Eckstein wird getestet
    if (testCorner(one, two, three, upFace[0][2], rightFace[0][2], backFace[0][0])) {
      caseFound = true;
    } else

    // Der hintere obere linke Eckstein wird getestet
    if (testCorner(one, two, three, upFace[0][0], leftFace[0][0], backFace[0][2])) {

      addTurn(TurnType.BPRIME);

      caseFound = true;
    } else

    // Der hintere untere linke Eckstein wird getestet
    if (testCorner(one, two, three, downFace[2][0], leftFace[2][0], backFace[2][2])) {

      addTurn(TurnType.BPRIME);
      addTurn(TurnType.BPRIME);

      caseFound = true;
    } else

    // Der hintere untere rechte Eckstein wird getestet
    if (testCorner(one, two, three, downFace[2][2], rightFace[2][2], backFace[2][0])) {

      addTurn(TurnType.B);

      caseFound = true;
    } else

    // Der vordere untere rechte Eckstein wird getestet
    if (testCorner(one, two, three, downFace[0][2], rightFace[2][0], frontFace[2][2])) {

      addTurn(TurnType.RPRIME);

      addTurn(TurnType.BPRIME);

      addTurn(TurnType.R);

      addTurn(TurnType.B);
      addTurn(TurnType.B);

      caseFound = true;
    } else

    // Der vordere untere linke Eckstein wird getestet
    if (testCorner(one, two, three, downFace[0][0], leftFace[2][2], frontFace[2][0])) {

      addTurn(TurnType.DPRIME);

      addTurn(TurnType.BPRIME);

      addTurn(TurnType.D);

      addTurn(TurnType.BPRIME);

      caseFound = true;
    } else

    // Der vordere obere linke Eckstein wird getestet
    if (testCorner(one, two, three, upFace[2][0], leftFace[0][2], frontFace[0][0])) {

      addTurn(TurnType.LPRIME);

      addTurn(TurnType.BPRIME);

      addTurn(TurnType.L);

      caseFound = true;
    } else

    // Der vordere obere rechte Eckstein wird getestet
    if (testCorner(one, two, three, upFace[2][2], frontFace[0][2], rightFace[0][0])) {

      addTurn(TurnType.R);
      addTurn(TurnType.BPRIME);
      addTurn(TurnType.RPRIME);

      caseFound = true;

    } else {

    }

    return caseFound;
  }

  /*
   * Testet einen Eckstein (mit den Flaechen testone, testtwo, testthree) ob er
   * die Farben one, two, three gleichzeitig beinhaltet.
   */
  private static boolean testCorner(Colour one, Colour two, Colour three, Colour testOne, Colour testTwo, Colour testThree) {

    boolean criteriaOne = false;
    boolean criteriaTwo = false;
    boolean criteriaThree = false;

    // Testet ob die erste Flaeche des Wuerfels eine der drei gesuchten Farben
    // hat
    if ((testOne == one) || (testOne == two) || (testOne == three)) {

      criteriaOne = true;
    }

    // Testet ob die zweite Flaeche des Wuerfels eine der drei gesuchten Farben
    // hat
    if ((testTwo == one) || (testTwo == two) || (testTwo == three)) {

      criteriaTwo = true;
    }

    // Testet ob die dritte Flaeche des Wuerfels eine der drei gesuchten Farben
    // hat
    if ((testThree == one) || (testThree == two) || (testThree == three)) {

      criteriaThree = true;
    }

    // Falls alle drei Tests positiv sind ist die getestete Ecke die gesuchte
    if (criteriaOne && criteriaTwo && criteriaThree) {

      return true;
    }

    return false;
  }

  /*
   * 
   */
  private static void insertFirstLayerCorner() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    // Man definiert die gesuchten Farben
    Colour one = frontFace[1][1];
    Colour two = upFace[1][1];
    Colour three = rightFace[1][1];

    if ((upFace[0][2] == two) && (rightFace[0][2] == one) && (backFace[0][0] == three)) {

      addTurn(TurnType.R);
      addTurn(TurnType.B);
      addTurn(TurnType.RPRIME);

    } else if ((upFace[0][2] == one) && (rightFace[0][2] == three) && (backFace[0][0] == two)) {

      addTurn(TurnType.UPRIME);
      addTurn(TurnType.BPRIME);
      addTurn(TurnType.U);

    } else if ((upFace[0][2] == three) && (rightFace[0][2] == two) && (backFace[0][0] == one)) {

      addTurn(TurnType.R);
      addTurn(TurnType.BPRIME);
      addTurn(TurnType.RPRIME);
      addTurn(TurnType.B);
      addTurn(TurnType.B);

      // koennte problematisch sein - TODO max zwei durchgaenge
      insertFirstLayerCorner();
    }

    // Alle anderen Faelle sind auf einen richtigen Wuerfel nicht zu finden
    // TODO andere Faelle testen

  }

  /*
   * 
   */
  private static void solveSecondLayer(int target) {

    // /////////////////////////////////////////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////

    int correctEdges = testSecondLayerEdges();
    Log.v("Second Step: Correct Edges ", String.valueOf(correctEdges));

    while (correctEdges < target) {

      if (testUpperRightEdge()) {

        Log.v("Second Step", "Upper right edge is correct");
        addTurn(TurnType.ROTZPRIME);

      } else {
        Log.v("Second Step", "Upper right is being solved");
        solveSecondLayerEdge();
      }

      correctEdges = testSecondLayerEdges();
      Log.v("Second Step: Correct Edges ", String.valueOf(correctEdges));

    }

    // /////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////////

    /*
     * //Das Teil hier funkt nicht immer aber koennte ne basis sein... for(int i
     * = 0; i < 6; i++) {
     * 
     * if (testUpperRightEdge()) {
     * 
     * addTurn(TurnType.ROTZPRIME);
     * 
     * } else { solveSecondLayerEdge(); addTurn(TurnType.ROTZPRIME); }
     * 
     * }
     */
  }

  /*
   * Diese Methode zaehlt die Anzahl der Mittelstuecke die an der richtigen
   * Stelle auf die zweite Ebene sind. Die verschiedenen Positionen, die
   * getestet werden muessen, sind hardcoded und die Methode aendert nichts am
   * Wuerfelkopie.
   * 
   * @return Anzahl der richtigen Mittelstuecke.
   */
  private static int testSecondLayerEdges() {

    // Diese Variable bezeichnet die Anzahl der richtig liegenden Mittlestuecke
    // auf der zweiten Ebene.
    int nrOfCorrectEdges = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();

    // Man testet ob die obere linke Mittlestueck der zweiten Ebene die richtige
    // ist.
    if ((upFace[1][0] == upFace[1][1]) && (leftFace[0][1] == leftFace[1][1])) {

      nrOfCorrectEdges++;
    }

    // Man testet ob die obere rechte Mittlestueck der zweiten Ebene die
    // richtige ist.
    if ((upFace[1][2] == upFace[1][1]) && (rightFace[0][1] == rightFace[1][1])) {

      nrOfCorrectEdges++;
    }

    // Man testet ob die untere linke Mittlestueck der zweiten Ebene die
    // richtige ist.
    if ((downFace[1][0] == downFace[1][1]) && (leftFace[2][1] == leftFace[1][1])) {

      nrOfCorrectEdges++;
    }

    // Man testet ob die untere rechte Mittlestueck der zweiten Ebene die
    // richtige ist.
    if ((downFace[1][2] == downFace[1][1]) && (rightFace[2][1] == rightFace[1][1])) {

      nrOfCorrectEdges++;
    }

    // Anzahl der richtigen Mittelstuecke wird zurueckgegeben.
    return nrOfCorrectEdges;
  }

  /*
   * Testet ob, von vorne gesehen (d.h die erste geloeste Ebene ist nach vorne
   * gerichtet), die obere rechte Mittlestein auf der zweiten Ebene richtig
   * gesetzt ist.
   * 
   * @return true wenn der Mittlestueck der richtige ist, false anderfalls
   */
  private static boolean testUpperRightEdge() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    // Man testet ob die obere rechte Mittelstueck der zweiten Ebene der
    // richtige ist.
    if ((upFace[1][2] == upFace[1][1]) && (rightFace[0][1] == rightFace[1][1])) {
      return true;
    } else {
      return false;
    }

  }

  /*
   * 
   */
  private static void solveSecondLayerEdge() {

    findEdgeOnSecondLayer();
    findEdgeOnThirdLayer();
    insertSecondLayerEdge();

    // Hier koennte etwas ganz falsch sein
  }

  /*
   * Testet ob ein bestimmtes Mittelstueck die beiden gesuchten Farben enthaelt.
   */
  private static boolean rightEdge(Colour one, Colour two, Colour testOne, Colour testTwo) {

    boolean controlOne = false;
    boolean controlTwo = false;

    // Man testet ob die erste Flaeche des Mittelstuecks eine der gesuchten
    // Farben enthaelt
    if ((testOne == one) || (testOne == two)) {
      controlOne = true;
    }

    // Man testet ob die zweite Flaeche des Mittelstuecks eine der gesuchten
    // Farben enthaelt
    if ((testTwo == one) || (testTwo == two)) {
      controlTwo = true;
    }

    // Falls beide tests positiv sind
    if (controlOne && controlTwo) {
      return true;
    } else {
      return false;
    }

  }

  /*
   * Diese Methode sucht nach der noetigen Mittelstueck der zweiten Ebene auf
   * der der dritten Ebene.
   */
  // TODO muss nicht return boolean haben
  // chained if else
  private static void findEdgeOnThirdLayer() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    // Man definiert die gesuchten Farben
    Colour one = upFace[1][1];
    Colour two = rightFace[1][1];

    if ((upFace[0][1] == one) && (backFace[0][1] == two)) {
      Log.v("Second Step", "Edge on Third Layer - Case 1");
    } else

    if ((upFace[0][1] == two) && (backFace[0][1] == one)) {

      Log.v("Second Step", "Edge on Third Layer - Case 2");
      addTurn(TurnType.BPRIME);

    } else

    // ///////////////////////

    if ((rightFace[1][2] == one) && (backFace[1][0] == two)) {

      Log.v("Second Step", "Edge on Third Layer - Case 3");
      addTurn(TurnType.B);

    } else

    if ((rightFace[1][2] == two) && (backFace[1][0] == one)) {

      Log.v("Second Step", "Edge on Third Layer - Case 4");
    } else

    // ///////////////////////

    if ((downFace[2][1] == one) && (backFace[2][1] == two)) {

      Log.v("Second Step", "Edge on Third Layer - Case 5");
      addTurn(TurnType.B);
      addTurn(TurnType.B);

    } else

    if ((downFace[2][1] == two) && (backFace[2][1] == one)) {

      Log.v("Second Step", "Edge on Third Layer - Case 6");
      addTurn(TurnType.B);

    } else

    // /////////////////////////////

    if ((leftFace[1][0] == one) && (backFace[1][2] == two)) {

      Log.v("Second Step", "Edge on Third Layer - Case 7");
      addTurn(TurnType.BPRIME);

    } else

    if ((leftFace[1][0] == two) && (backFace[1][2] == one)) {

      Log.v("Second Step", "Edge on Third Layer - Case 8");
      addTurn(TurnType.BPRIME);
      addTurn(TurnType.BPRIME);

    } else {
      Log.v("Second Step", "Edge on Third Layer not found");
    }

  }

  /*
   * Diese Methode sucht nach der noetigen Mittelstueck der zweiten Ebene auf
   * der der zweiten Ebene.
   */
  private static void findEdgeOnSecondLayer() {

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();

    if ((upFace[1][2] == rightFace[1][1]) && (rightFace[0][1] == upFace[1][1])) {

      Log.v("Second Step", "Edge on Second Layer - Case 1");
      moveEdge();

    } else if (rightEdge(upFace[1][1], rightFace[1][1], rightFace[2][1], downFace[1][2])) {

      Log.v("Second Step", "Edge on Second Layer - Case 2");
      addTurn(TurnType.ROTZPRIME);
      moveEdge();
      addTurn(TurnType.ROTZ);

    } else if (rightEdge(upFace[1][1], rightFace[1][1], leftFace[2][1], downFace[1][0])) {

      Log.v("Second Step", "Edge on Second Layer - Case 3");
      addTurn(TurnType.ROTZPRIME);
      addTurn(TurnType.ROTZPRIME);
      moveEdge();
      addTurn(TurnType.ROTZ);
      addTurn(TurnType.ROTZ);

    } else if (rightEdge(upFace[1][1], rightFace[1][1], upFace[1][0], leftFace[0][1])) {

      Log.v("Second Step", "Edge on Second Layer - Case 4");
      addTurn(TurnType.ROTZ);
      moveEdge();
      addTurn(TurnType.ROTZPRIME);

    } else {
      Log.v("Second Step", "Edge on Second Layer not found");
    }

  }

  /*
   * Diese Methode bringt einen Mittelstueck von der zweiten Ebene auf die
   * dritte ohne die erste Ebene zu beeinflussen.
   */
  private static void moveEdge() {

    // Die Perspektive aus der die Bewegungen durchgefuehrt werden ist mit den
    // ersten geloesten Seite nach vorne.
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.B);
    addTurn(TurnType.U);
    addTurn(TurnType.B);
    addTurn(TurnType.R);
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.RPRIME);
  }

  /*
   * Diese Methode
   */
  private static void insertSecondLayerEdge() {

    // Ab hier bis zur Ende der Methode arbeitet man mit der ersten geloesten
    // Ebene nach unten gedreht.
    addTurn(TurnType.ROTXPRIME);

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] frontFace = cubeCopy.getFace(Constants.FRONT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    // Man definiert die gesuchten Farben.
    Colour one = frontFace[1][1];
    Colour two = rightFace[1][1];

    if ((rightFace[0][1] == two) && (upFace[1][2] == one)) {

      addTurn(TurnType.UPRIME);
      addTurn(TurnType.FPRIME);
      addTurn(TurnType.U);
      addTurn(TurnType.F);
      addTurn(TurnType.U);
      addTurn(TurnType.R);
      addTurn(TurnType.UPRIME);
      addTurn(TurnType.RPRIME);

    } else if ((frontFace[0][1] == one) && (upFace[2][1] == two)) {

      // aenderungen
      addTurn(TurnType.U);
      addTurn(TurnType.R);
      addTurn(TurnType.UPRIME);
      addTurn(TurnType.RPRIME);
      addTurn(TurnType.UPRIME);
      addTurn(TurnType.FPRIME);
      addTurn(TurnType.U);
      addTurn(TurnType.F);

    }

    // Hier wird das Wuerfel mit der ersten geloesten Seite nach Vorne
    // zurueckgedreht
    addTurn(TurnType.ROTX);

  }

  /*
   * 
   */
  private static void solveUpperCross() {

    if (testUpperCross() == 0) {

      Log.v("Upper Cross", "No Edges Up");
      algoUpperCross();
    }

    while (testUpperCross() == 2) {

      Log.v("Upper Cross", "Two Edges Up");
      positionUppercross();
      algoUpperCross();
    }

    // assert time
    return;
  }

  /*
   * Diese Methode zaehlt die Anzahl der Mittelstuecke der dritten Ebene, die
   * nach hinten mit der richtigen Farbe gerichtet sind. Die verschiedenen
   * Positionen, die getestet werden muessen, sind hardcoded und die Methode
   * aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen gestellten Mittelstuecke
   */
  private static int testUpperCross() {

    // Diese Variable bezeichnet die Anzahl der Mittelstuecke der dritten Ebene
    // die mit der richtigen Farbe nach hinten
    // (nach forne wenn man die dritte Ebene direkt ansieht) gerichtet sind.
    int nrOfCorrectEdges = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    // Oberes Mittelstueck wird getestet.
    if (backFace[0][1] == backFace[1][1]) {
      nrOfCorrectEdges++;
    }

    // Rechtes Mittlestueck wird getestet.
    if (backFace[1][0] == backFace[1][1]) {
      nrOfCorrectEdges++;
    }

    // Unteres Mittlestueck wird getestet.
    if (backFace[2][1] == backFace[1][1]) {
      nrOfCorrectEdges++;
    }

    // Linkes Mittelstueck wird getestet.
    if (backFace[1][2] == backFace[1][1]) {
      nrOfCorrectEdges++;
    }

    // Anzahl der richtig gerichteten Mittelstuecke wird zurueckgegeben.
    return nrOfCorrectEdges;
  }

  private static void positionUppercross() {

    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    Colour one = backFace[1][1];

    // Hier wird der Fall wo es keine der Edges richtig gerichtet sind nicht
    // behandelt

    if ((backFace[1][0] == one) && (backFace[1][2] == one)) {

      Log.v("Upper Cross", "Two Edges Up - Case 1");
      return;

    }

    if ((backFace[0][1] == one) && (backFace[2][1] == one)) {

      // vllt mit ROT ersetzen ???
      Log.v("Upper Cross", "Two Edges Up - Case 2");
      addTurn(TurnType.B);
      return;

    }

    // /////////////////////////

    if ((backFace[1][2] == one) && (backFace[2][1] == one)) {

      // vllt mit ROT ersetzen ???
      Log.v("Upper Cross", "Two Edges Up - Case 3");
      return;

    }

    if ((backFace[0][1] == one) && (backFace[1][2] == one)) {

      // vllt mit ROT ersetzen ???
      Log.v("Upper Cross", "Two Edges Up - Case 4");
      addTurn(TurnType.B);
      return;

    }

    if ((backFace[0][1] == one) && (backFace[1][0] == one)) {

      // vllt mit ROT ersetzen ???
      Log.v("Upper Cross", "Two Edges Up - Case 5");
      addTurn(TurnType.B);
      addTurn(TurnType.B);
      return;

    }

    if ((backFace[1][0] == one) && (backFace[2][1] == one)) {

      // vllt mit ROT ersetzen ???
      Log.v("Upper Cross", "Two Edges Up - Case 6");
      addTurn(TurnType.B);
      return;

    }

  }

  /*
   * 
   */
  private static void algoUpperCross() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.RPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.FPRIME);
    addTurn(TurnType.U);
    addTurn(TurnType.F);
    addTurn(TurnType.R);

    addTurn(TurnType.ROTX);

  }

  /*
   * 
   */
  private static void solveUpperCorners() {

    int upperCorners = testUpperCorners();

    if (upperCorners == 0) {
      Log.v("Upper Corners", "No Corners Up");
      solveFourWrongCorners();
    } else if (upperCorners == 2) {
      Log.v("Upper Corners", "Two Corners Up");
      solveTwoWrongCorners();
    }

    Log.v("Upper Corners", "Three Corners Up");
    solveThreeWrongCorners();

    // time for an assert
    return;
  }

  /*
   * Diese Methode zaehlt die Anzahl der Ecken der dritten Ebene, die nach
   * hinten mit der richtigen Farbe gerichtet sind. Die verschiedenen
   * Positionen, die getestet werden muessen, sind hardcoded und die Methode
   * aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen gestellten Ecken
   */
  private static int testUpperCorners() {

    // Diese Variable bezeichnet die Anzahl der Ecken der dritten Ebene die mit
    // der richtigen Farbe nach hinten
    // (nach forne wenn man die dritte Ebene direkt ansieht) gerichtet sind.
    int nrOfCorrectCorners = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    // Die obere rechte Ecke wird getestet.
    if (backFace[0][0] == backFace[1][1]) {
      nrOfCorrectCorners++;
    }

    // Die obere linke Ecke wird getestet.
    if (backFace[0][2] == backFace[1][1]) {
      nrOfCorrectCorners++;
    }

    // Die untere rechte Ecke wird getestet.
    if (backFace[2][0] == backFace[1][1]) {
      nrOfCorrectCorners++;
    }

    // Die untere linke Ecke wird getestet.
    if (backFace[2][2] == backFace[1][1]) {
      nrOfCorrectCorners++;
    }

    // Anzahl der richtg gerichteten Ecken wird zurueckgegeben.
    return nrOfCorrectCorners;

  }

  private static void solveTwoWrongCorners() {

    for (int i = 0; i < 4; i++) {
      if (twoWrongCornersCases()) {
        return;
      } else {
        addTurn(TurnType.ROTZ);
      }

    }
  }

  /*
   * 
   */
  private static boolean twoWrongCornersCases() {

    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    Colour one = backFace[1][1];

    boolean caseFound = false;

    if ((upFace[0][0] == one) && (upFace[0][2] == one)) {

      Log.v("Upper Corners", "Two Corners Up - Case 1");
      algoUpperCorners();
      caseFound = true;
    } else if ((upFace[0][0] == one) && (downFace[2][0] == one)) {

      Log.v("Upper Corners", "Two Corners Up - Case 2");
      algoUpperCorners();
      caseFound = true;
    } else if ((upFace[0][0] == one) && (rightFace[2][2] == one)) {

      Log.v("Upper Corners", "Two Corners Up - Case 3");
      algoUpperCorners();
      caseFound = true;
    } else {
      Log.v("Upper Corners", "Two Corners Up - No Case Found");
    }

    return caseFound;

  }

  /*
   * 
   */
  private static void solveThreeWrongCorners() {

    for (int i = 0; i < 4; i++) {
      if (threeWrongCornersCases()) {
        return;
      } else {
        addTurn(TurnType.ROTZ);
      }

    }
  }

  private static boolean threeWrongCornersCases() {

    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    Colour one = backFace[1][1];

    boolean caseFound = false;

    if ((upFace[0][2] == one) && (rightFace[2][2] == one) && (downFace[2][0] == one)) {

      Log.v("Upper Corners", "Three Wrong Corners - Case 1");
      algoUpperCorners();
      caseFound = true;
    } else if ((upFace[0][0] == one) && (leftFace[2][0] == one) && (downFace[2][2] == one)) {

      Log.v("Upper Corners", "Three Wrong Corners - Case 1");
      algoMirroredUpperCorners();
      caseFound = true;
    } else {
      Log.v("Upper Corners", "Three Wrong Corners - No Case Found");
    }

    return caseFound;

  }

  private static void solveFourWrongCorners() {

    for (int i = 0; i < 4; i++) {
      if (fourWrongCornersCases()) {
        return;
      } else {
        addTurn(TurnType.ROTZ);
      }

    }
  }

  private static boolean fourWrongCornersCases() {

    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] backFace = cubeCopy.getFace(Constants.BACK).getPermut();

    Colour one = backFace[1][1];

    boolean caseFound = false;

    if ((rightFace[0][2] == one) && (rightFace[2][2] == one) && (leftFace[0][0] == one) && (leftFace[2][0] == one)) {

      Log.v("Upper Corners", "Four Wrong Corners - Case 1");
      algoUpperCorners();
      caseFound = true;

    } else if ((upFace[0][2] == one) && (downFace[2][2] == one) && (leftFace[0][0] == one) && (leftFace[2][0] == one)) {

      Log.v("Upper Corners", "Four Wrong Corners - Case 2");
      algoUpperCorners();
      caseFound = true;
    } else {
      Log.v("Upper Corners", "No Case Found");
    }

    return caseFound;

  }

  private static void algoUpperCorners() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.R);
    addTurn(TurnType.U);
    addTurn(TurnType.RPRIME);
    addTurn(TurnType.U);
    addTurn(TurnType.R);
    addTurn(TurnType.U);
    addTurn(TurnType.U);
    addTurn(TurnType.RPRIME);

    addTurn(TurnType.ROTX);

  }

  private static void algoMirroredUpperCorners() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.LPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.L);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.LPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.L);

    addTurn(TurnType.ROTX);

  }

  private static void correctUpperCorners() {

    // TODO neu schreiben die logic ist sehr fuzzy

    int correctUpperCorners = testCorrectUpperCorners();

    if (correctUpperCorners == 4) {
      return;
    }

    if (correctUpperCorners == 2) {
      algoCorrectUpperCorners();
    }

    solveCorrectUpperCorners();

    if (testCorrectUpperCorners() != 4) {
      addTurn(TurnType.B);
      solveCorrectUpperCorners();
    }

    // loc pt un assert
    return;

  }

  /*
   * Diese Methode zaehlt die Anzahl der Ecken der dritten Ebene, die richtig
   * gestellt sind. Die verschiedenen Positionen, die getestet werden muessen,
   * sind hardcoded und die Methode aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen Ecken der dritten Ebene.
   */
  private static int testCorrectUpperCorners() {

    // stezt voraus, dass testUpperCorners schon bestanden wurde.

    // Diese Variable bezeichnet die Anzahl der Ecken der dritten Ebene.
    int solvedCorners = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    // Die obere rechte Ecke wird getestet.
    if ((upFace[0][2] == upFace[1][1]) && (rightFace[0][2] == rightFace[1][1])) {
      solvedCorners++;
    }

    // Die obere linke Ecke wird getestet.
    if ((upFace[0][0] == upFace[1][1]) && (leftFace[0][0] == leftFace[1][1])) {
      solvedCorners++;
    }

    // Die untere rechte Ecke wird getestet.
    if ((downFace[2][2] == downFace[1][1]) && (rightFace[2][2] == rightFace[1][1])) {
      solvedCorners++;
    }

    // Die untere linke Ecke wird getestet.
    if ((downFace[2][0] == downFace[1][1]) && (leftFace[2][0] == leftFace[1][1])) {
      solvedCorners++;
    }

    // Anzahl der richtigen Ecken wird zurueckgegeben.
    return solvedCorners;
  }

  // invartit ca sa gasesc cazul corect
  private static void solveCorrectUpperCorners() {

    for (int i = 0; i < 4; i++) {
      if (correctUpperCornersCases()) {
        return;
      } else {
        addTurn(TurnType.ROTZ);
      }

    }

  }

  private static boolean correctUpperCornersCases() {

    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    Colour one = upFace[1][1];
    Colour two = rightFace[1][1];
    Colour three = downFace[1][1];
    Colour four = leftFace[1][1];

    boolean caseFound = false;

    if ((upFace[0][2] == three) && (rightFace[0][2] == four) && (rightFace[2][2] == one) && (downFace[2][2] == two) && (downFace[2][0] == two) && (leftFace[2][0] == three)) {

      Log.v("Upper Corners Corrected", "Case 1");
      algoCorrectUpperCorners();
      caseFound = true;
    } else if ((upFace[0][0] == three) && (leftFace[0][0] == two) && (leftFace[2][0] == one) && (downFace[2][2] == four) && (downFace[2][0] == four) && (leftFace[2][2] == three)) {

      Log.v("Upper Corners Corrected", "Case 2");
      algoMirroredCorrectUpperCorners();
      caseFound = true;
    } else {
      Log.v("Upper Corners Corrected", "No Case Found");
    }

    return caseFound;
  }

  private static void algoCorrectUpperCorners() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.RPRIME);
    addTurn(TurnType.F);
    addTurn(TurnType.RPRIME);
    addTurn(TurnType.B);
    addTurn(TurnType.B);
    addTurn(TurnType.R);
    addTurn(TurnType.FPRIME);
    addTurn(TurnType.RPRIME);
    addTurn(TurnType.B);
    addTurn(TurnType.B);
    addTurn(TurnType.R);
    addTurn(TurnType.R);

    addTurn(TurnType.ROTX);

  }

  private static void algoMirroredCorrectUpperCorners() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.L);
    addTurn(TurnType.FPRIME);
    addTurn(TurnType.L);
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.LPRIME);
    addTurn(TurnType.F);
    addTurn(TurnType.L);
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.BPRIME);
    addTurn(TurnType.LPRIME);
    addTurn(TurnType.LPRIME);

    addTurn(TurnType.ROTX);

  }

  private static void correctUpperCross() {

    int correctUpperEdges = testCorrectUpperCross();

    if (correctUpperEdges == 4) {
      return;
    }

    if (correctUpperEdges == 0) {
      algoCorrectUpperCross();
    }

    solveCorrectUpperCross();

    // loc pt un assert

    return;
  }

  /*
   * Diese Methode zaehlt die Anzahl der Mittestuecke der dritten Ebene, die
   * richtig gestellt sind. Die verschiedenen Positionen, die getestet werden
   * muessen, sind hardcoded und die Methode aendert nichts am Wuerfelkopie.
   * 
   * @return Anzahl der richtigen Mittelstuecke der dritten Ebene.
   */
  private static int testCorrectUpperCross() {

    // stezt voraus, dass testUpperCross schon bestanden wurde.

    // Diese Variable bezeichnet die Anzahl der Mittelstuecke der dritten Ebene.
    int solvedEdges = 0;

    // Man holt die noetigen Faces des Wuerfels.
    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] downFace = cubeCopy.getFace(Constants.DOWN).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    // Der obere Mittelstueck wird getestet.
    if (upFace[0][1] == upFace[1][1]) {
      solvedEdges++;
    }

    // Der untere Mittelstueck wird getestet.
    if (downFace[2][1] == downFace[1][1]) {
      solvedEdges++;
    }

    // Der linke Mittelstueck wird getestet.
    if (leftFace[1][0] == leftFace[1][1]) {
      solvedEdges++;
    }

    // Der rechte Mittelstueck wird getestet.
    if (rightFace[1][2] == rightFace[1][1]) {
      solvedEdges++;
    }

    // Anzahl der richtigen Ecken wird zurueckgegeben.
    return solvedEdges;
  }

  private static void solveCorrectUpperCross() {

    for (int i = 0; i < 4; i++) {
      if (correctUpperCrossCases()) {
        return;
      } else {
        addTurn(TurnType.ROTZ);
      }

    }

  }

  /*
   * Diese Methode
   */
  private static boolean correctUpperCrossCases() {

    Colour[][] upFace = cubeCopy.getFace(Constants.UP).getPermut();
    Colour[][] leftFace = cubeCopy.getFace(Constants.LEFT).getPermut();
    Colour[][] rightFace = cubeCopy.getFace(Constants.RIGHT).getPermut();

    boolean caseFound = false;

    if ((upFace[0][1] == leftFace[1][1]) && (rightFace[1][2] == upFace[1][1]) && (leftFace[1][0] == rightFace[1][1])) {

      Log.v("Upper Cross Corrected", "Case 1");

      algoCorrectUpperCross();

      addTurn(TurnType.ROTZPRIME);

      algoMirroredCorrectUpperCross();

      caseFound = true;

    } else if ((upFace[0][1] == rightFace[1][1]) && (rightFace[1][2] == leftFace[1][1]) && (leftFace[1][0] == upFace[1][1])) {

      Log.v("Upper Cross Corrected", "Case 2");

      algoMirroredCorrectUpperCross();

      addTurn(TurnType.ROTZ);

      algoCorrectUpperCross();

      caseFound = true;
    } else {
      Log.v("Upper Cross Corrected", "No Cases Found");
    }

    return caseFound;
  }

  private static void algoCorrectUpperCross() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.R);
    addTurn(TurnType.U);
    addTurn(TurnType.RPRIME);
    addTurn(TurnType.U);
    addTurn(TurnType.R);
    addTurn(TurnType.U);
    addTurn(TurnType.U);
    addTurn(TurnType.RPRIME);

    addTurn(TurnType.ROTX);
  }

  private static void algoMirroredCorrectUpperCross() {

    addTurn(TurnType.ROTXPRIME);

    addTurn(TurnType.LPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.L);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.LPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.UPRIME);
    addTurn(TurnType.L);

    addTurn(TurnType.ROTX);

  }

  /*
   * Diese Methode wird benutzt um Zuege auf die Wuerfelkopie durchzufuehren und
   * diese in die solution Liste zu speichern.
   * 
   * @param Der Zug der ausgefuehrt/gespeichert werden muss.
   */
  private static void addTurn(TurnType type) {
    assert (cubeCopy != null) : "There is no cube to work on";

    switch (type) {
      // Die Rotationen des Wuerfels sollen nicht gespeichert werden, da der
      // Algorithmus unabhaengig von die
      // Perspektive der Benutzer laufen sollte.
      case ROTXPRIME:
      case ROTX:
      case ROTYPRIME:
      case ROTY:
      case ROTZPRIME:
      case ROTZ:
        cubeCopy.applyTurn(type);
        break;
      default:
        cubeCopy.applyTurn(type);
        // Ein neues Turn erzeugen
        Turn turn = new Turn(type, cubeCopy.getFrontID(), cubeCopy.getSideID());
        // Das neu erzeugte Turn der Liste zufuegen
        solution.add(turn);
        break;
    }

  }

}
