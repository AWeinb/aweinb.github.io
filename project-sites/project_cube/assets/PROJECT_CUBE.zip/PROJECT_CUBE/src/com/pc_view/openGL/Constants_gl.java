package com.pc_view.openGL;

/**
 * Die Konstanten bezeichnen die Standartreihenfolge, in der Fl&#228;chen oder
 * Farben eines W&#252;rfels in Listen gespeichert werden. Hilfreich um
 * bestimmten Ebenen bestimmte Farbwerte zuzuordnen.
 * 
 * @author AxP
 */
public final class Constants_gl {

  /**
   * Verschiebung der W&#252;rfel in das Display hinein.
   */
  public static float zTranslate = -17.5f;
  /** W&#252;rfel Zwischenraum */
  public static float cubeMargin = 0.3f;
  /** W&#252;rfelweite */
  public static float cubeRadius = 2f;

  /**
   * F&#252;r Farbzuweisung verwendete Maximalzahl der Ebenen.
   */
  public static final int MAXSIDES = 6;

  /**
   * Die Unterfl&#228;chen auf den Hauptw&#252;rfelseiten werden wie folgt durch
   * nummeriert.
   */
  /**
   * <pre>
   *  ________
   * |X_|__|__|
   * |__|__|__|
   * |__|__|__|
   * </ pre>
   */
  public static final int TOPLEFT = 0;
  /**
   * <pre>
   *  ________
   * |__|_X|__|
   * |__|__|__|
   * |__|__|__|
   * </ pre>
   */
  public static final int TOPMIDDLE = 1;
  /**
   * <pre>
   *  ________
   * |__|__|X_|
   * |__|__|__|
   * |__|__|__|
   * </ pre>
   */
  public static final int TOPRIGHT = 2;

  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |X_|__|__|
   * |__|__|__|
   * </ pre>
   */
  public static final int MIDDLELEFT = 3;
  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |__|X_|__|
   * |__|__|__|
   * </ pre>
   */
  public static final int MIDDLEMIDDLE = 4;
  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |__|__|X_|
   * |__|__|__|
   * </ pre>
   */
  public static final int MIDDLERIGHT = 5;

  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |__|__|__|
   * |X_|__|__|
   * </ pre>
   */
  public static final int BOTTOMLEFT = 6;
  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |__|__|__|
   * |__|X_|__|
   * </ pre>
   */
  public static final int BOTTOMMIDDLE = 7;
  /**
   * <pre>
   *  ________
   * |__|__|__|
   * |__|__|__|
   * |__|__|X_|
   * </ pre>
   */
  public static final int BOTTOMRIGHT = 8;

  /**
   * Maximalzahl der Einzelseiten/ W&#252;rfel einer Hauptseite.
   */
  public static final int MAXFACES = 9;

  /**
   * Int x. Steht f&#252;r die x Achse.
   */
  public static final int XAXIS = 0;

  /**
   * Int y. Steht f&#252;r die y Achse.
   */
  public static final int YAXIS = 1;

  /**
   * Int z. Steht f&#252;r die z Achse.
   */
  public static final int ZAXIS = 2;

  /**
   * Erste, zweite, dritte Ebene von Y(Oben -> Unten), Z(Vorne -> Hinten),
   * X(Links -> Rechts).
   */
  public static final int LAYER_ONE = 0;
  /**
   * Erste, zweite, dritte Ebene von Y(Oben -> Unten), Z(Vorne -> Hinten),
   * X(Links -> Rechts).
   */
  public static final int LAYER_TWO = 1;
  /**
   * Erste, zweite, dritte Ebene von Y(Oben -> Unten), Z(Vorne -> Hinten),
   * X(Links -> Rechts).
   */
  public static final int LAYER_THREE = 2;
}
