package com.pc_view.openGL;

import java.security.InvalidParameterException;

import android.opengl.GLSurfaceView;

/**
 * Die Klasse MainCube stellt eine Art Schnittstelle zu den anderen Komponenten
 * wie Model und Controller dar. Sie beinhaltet vereinfachte Funktionen zum
 * Drehen von Ebenen und F&#228;rben von Fl&#228;chen. Hier kann au&#223;erdem
 * die Gr&#246;&#223;e der Unterw&#252;rfel angepasst werden oder wie weit vom
 * Ursprung der Hauptw&#252;rfel gezeichnet werden soll. F&#252;r diese
 * Variablen existieren noch keine getter-Methoden.
 * 
 * @author AxP
 * 
 */
public class MainCube_gl {
  private static final String RENDER_ERROR = "Create Renderer first!";

  private static CubeRenderer_gl renderer;
  private static GLSurfaceView view;

  private static float zTranslate = Constants_gl.zTranslate;
  private static float cubeMargin = Constants_gl.cubeMargin;
  private static float cubeRadius = Constants_gl.cubeRadius;

  /**
   * Der Renderer Zugriff wird mit dieser Methode verwaltet. Der Renderer sollte
   * nicht direkt erstellt werden. Diese M&#246;glichkeit besteht zur Zeit auch
   * nicht.
   * 
   * @return Der aktuelle Renderer.
   */
  public static CubeRenderer_gl getRenderer(GLSurfaceView view, String filter) {
    if (renderer == null) {
      renderer = new CubeRenderer_gl(cubeRadius, cubeMargin, zTranslate, filter);
    }

    if (view != null) {
      MainCube_gl.view = view;

    } else {
      throw new InvalidParameterException();
    }

    return renderer;
  }

  public static void requestRender() {
    if (view != null)
      view.requestRender();
  }

  /**
   * Um einen neuen Renderer zu erhalten, kann der Alte mithilfe dieser Funktion
   * entfernt werden.
   */
  public static void destroyRenderer() {
    renderer = null;
  }

  /**
   * Diese Methode f&#228;rbt eine Unterfl&#228;che in einer bestimmten Farbe
   * ein. Dazu muss mithilfe der Constants_gl Klasse die richtige Ebene und die
   * richtige Unterfl&#228;che diese Ebene ausgew&#228;hlt werden. Die letzten
   * vier float-Parameter sind Farbanweisungen und m&#252;ssen zwischen 0 und 1
   * liegen.
   * 
   * @see Constants_gl
   * @param layerID
   *          Ebenen ID. Siehe Constants_gl.
   * @param faceID
   *          Unterfl&#228;chen ID. Siehe Constants_gl.
   * @param red
   *          Rotwert. Muss zwischen 0 und 1 liegen.
   * @param green
   *          Gr&#252;nwert. Muss zwischen 0 und 1 liegen.
   * @param blue
   *          Blauwert. Muss zwischen 0 und 1 liegen.
   * @param alpha
   *          Transparenzwert. Muss zwischen 0 und 1 liegen.
   * @return Gibt bei Erfolg true zur&#252;ck.
   */
  public static boolean setColorOnFaceOfSide(int layerID, int faceID, float red, float green, float blue, float alpha) throws IllegalStateException {
    boolean success = true;
    // Sicherstellung das ein Renderer existiert.
    if (renderer == null)
      throw new IllegalStateException(RENDER_ERROR);

    if (layerID >= 0 && layerID < Constants_gl.MAXSIDES && faceID >= 0 && faceID < Constants_gl.MAXFACES) {
      // CubeColor Obj dient zur einfachen Verwaltung/Ueberpruefung der vier Werte.
      CubeColor_gl color = new CubeColor_gl(red, green, blue, alpha);
      renderer.paintFaceOnSide(layerID, faceID, color);
      
    } else {
      success = false;
    }

    return success;
  }

  /**
   * Diese Methode rotiert eine bestimmte Ebene um die eigene Mittelachse. Dazu
   * muss die Achse angegeben werden und die Ebene. Um zu verstehen, welche
   * Ebene mit welchen Parametern angesprochen werden, ist es empfehlenswert,
   * sich die Klasse Constants_gl anzusehen, die hier verwendet werden soll! Als
   * dritter Parameter muss der Winkel angegeben werden, auf den die Ebene dann
   * unverz&#252;glich gedreht wird. Der Winkel kann positiv und negativ sein,
   * sodass beide Richtungen abgedeckt werden k&#246;nnen.
   * 
   * @see Constants_gl
   * @param axis
   *          Die Achse um die gedreht werden soll.
   * @param layerID
   *          Die Ebene die auf dieser Achse bewegt werden soll.
   * @param angle
   *          Der Winkel auf den die Ebene gedreht wird.
   * @return Gibt bei Erfolg true zur&#252;ck.
   */
  public static boolean rotateLayerOnAxis(int axis, int layerID, float angle) throws IllegalStateException {
    boolean success;
    // Sicherstellung das ein Renderer existiert.
    if (renderer == null)
      throw new IllegalStateException(RENDER_ERROR);

    if (checkLayerID(layerID) && (axis == Constants_gl.XAXIS || axis == Constants_gl.YAXIS || axis == Constants_gl.ZAXIS)) {
      renderer.setAnimAngle(axis, layerID, angle);
      success = true;

    } else {
      success = false;
    }

    return success;
  }

  /*
   * Hilfsmethode um lange If &#252;berpr&#252;fung auszulagern. Hier werden die
   * Ebenen IDs kontrolliert.
   */
  private static boolean checkLayerID(int layerID) {
    boolean success;

    if (layerID == Constants_gl.LAYER_ONE || layerID == Constants_gl.LAYER_TWO || layerID == Constants_gl.LAYER_THREE) {
      success = true;

    } else {
      success = false;
    }

    return success;
  }

}
