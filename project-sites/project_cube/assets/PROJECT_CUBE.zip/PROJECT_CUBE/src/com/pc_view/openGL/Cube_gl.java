package com.pc_view.openGL;

import java.security.InvalidParameterException;
import java.util.ArrayList;

import javax.microedition.khronos.opengles.GL10;

import com.pc_util.Constants;

/**
 * Die Klasse Cube_gl verbindet 6 CubeFace_gl Objekte zu einem W&#252;rfel. Dazu
 * werden hier die Eckpunkte an die CubeFace Klasse &#252;bergeben, die dann damit
 * ein OpenGL Model einer W&#252;rfelseite erzeugt. Als Parameter ben&#246;tigt ein Cube
 * Objekt den L&#228;ngenwert einer Kante.
 * 
 * 
 * @author AxP
 * 
 */
class Cube_gl {

  private static final String CONSTR_ERROR = "Class Cube_gl Constructor: float rad <= 0.";

  /*
   * Das folgende Array enthaelt die Laengen der einzelnen Gebiete. Zum
   * Beispiel Breite des Randes oder Laenge der Sternspitzen. Fuer eine genauere
   * Beschreibung der Belegung siehe weiter unten.
   */
  private float[] cS;
  //Alle Wuerfelseiten werden in dieser Liste gespeichert.
  private ArrayList<CubeFace_gl> sides = new ArrayList<CubeFace_gl>();
  
  /**
   * Der Konstruktor &#252;bernimmt die Seitenl&#228;nge des zu erzeugenden W&#252;rfels. Um
   * diesen zu zeichnen, muss draw() aufgerufen werden.
   */
  protected Cube_gl(float cubeLength) {
    /*
     * Grobe Skizze des von den unten definierten Vertices erzeugten Models.
     *  ---------------------
     * |   ---------------   |
     * |  |               |  |
     * |  |      ||       |  |
     * |  |    = ** =     |  |
     * |  |      ||       |  |
     * |  |               |  |
     * |   ---------------   |
     *  ---------------------
     */
    if (cubeLength <= 0)
      throw new InvalidParameterException(CONSTR_ERROR);

    this.cS = new float[10];
    this.cS[0] = cubeLength;    // cubeLength
    this.cS[1] = cS[0] / 2;     // cubeRadius_half
    this.cS[2] = 0.75f;         // cubeBorderRadius
    this.cS[3] = cS[1] * 0.15f; // cubeStarPikeRadius
    this.cS[4] = cS[1] * 0.10f; // cubeStarBendRadius
    this.cS[5] = cS[1];         // cubeZIndex_out
    this.cS[6] = cS[1] * 1.15f; // cubeZIndex_in
    this.cS[7] = cS[1] * 1.25f; // cubeStarZIndex_pike
    this.cS[8] = cS[1] * 1.1f;  // cubeStarZIndex_bend
    this.cS[9] = cS[1] * 1.25f; // cubeCenterZIndex

    /*
     * Zum Nachvollziehen bitte Skizze ansehen/ anfertigen! 
     */
    float[] topVertices = new float[] {
      -cS[1],   cS[5],  -cS[1],
      -cS[1],   cS[5],   cS[1],
       cS[1],   cS[5],   cS[1],
       cS[1],   cS[5],  -cS[1],
      
      -cS[2],   cS[6],  -cS[2],
      -cS[2],   cS[6],   cS[2],
       cS[2],   cS[6],   cS[2],
       cS[2],   cS[6],  -cS[2],
      
      -cS[2],   cS[6],       0,
           0,   cS[6],   cS[2],
       cS[2],   cS[6],       0,
           0,   cS[6],  -cS[2],
      
      -cS[3],   cS[7],       0,
           0,   cS[7],   cS[3],
       cS[3],   cS[7],       0,
           0,   cS[7],  -cS[3],
      
      -cS[4],   cS[8],  -cS[4],
      -cS[4],   cS[8],   cS[4],
       cS[4],   cS[8],   cS[4],
       cS[4],   cS[8],  -cS[4],
      
           0,   cS[9],       0
    };
    
    float[] btmVertices = new float[] {
       cS[1],   -cS[5],  -cS[1],
       cS[1],   -cS[5],   cS[1],
      -cS[1],   -cS[5],   cS[1],
      -cS[1],   -cS[5],  -cS[1],
      
       cS[2],   -cS[6],  -cS[2],
       cS[2],   -cS[6],   cS[2],
      -cS[2],   -cS[6],   cS[2],
      -cS[2],   -cS[6],  -cS[2],
      
       cS[2],   -cS[6],       0,
           0,   -cS[6],   cS[2],
      -cS[2],   -cS[6],       0,
           0,   -cS[6],  -cS[2],
      
       cS[3],   -cS[7],       0,
           0,   -cS[7],   cS[3],
      -cS[3],   -cS[7],       0,
           0,   -cS[7],  -cS[3],
      
       cS[4],   -cS[8],  -cS[4],
       cS[4],   -cS[8],   cS[4],
      -cS[4],   -cS[8],   cS[4],
      -cS[4],   -cS[8],  -cS[4],
      
           0,   -cS[9],       0
    };

    float[] frontVertices = new float[] {
      -cS[1],   cS[1],  cS[5],
      -cS[1],  -cS[1],  cS[5],
       cS[1],  -cS[1],  cS[5],
       cS[1],   cS[1],  cS[5],
      
      -cS[2],   cS[2],  cS[6],
      -cS[2],  -cS[2],  cS[6],
       cS[2],  -cS[2],  cS[6],
       cS[2],   cS[2],  cS[6],
      
      -cS[2],       0,  cS[6],
           0,  -cS[2],  cS[6],
       cS[2],       0,  cS[6],
           0,   cS[2],  cS[6],
      
      -cS[3],       0,  cS[7],
           0,  -cS[3],  cS[7],
       cS[3],       0,  cS[7],
           0,   cS[3],  cS[7],
      
      -cS[4],   cS[4],  cS[8],
      -cS[4],  -cS[4],  cS[8],
       cS[4],  -cS[4],  cS[8],
       cS[4],   cS[4],  cS[8],
      
           0,       0,  cS[9]
    };
    
    float[] backVertices = new float[] {
       cS[1],   cS[1],  -cS[5],
       cS[1],  -cS[1],  -cS[5],
      -cS[1],  -cS[1],  -cS[5],
      -cS[1],   cS[1],  -cS[5],
      
       cS[2],   cS[2],  -cS[6],
       cS[2],  -cS[2],  -cS[6],
      -cS[2],  -cS[2],  -cS[6],
      -cS[2],   cS[2],  -cS[6],
      
       cS[2],       0,  -cS[6],
           0,  -cS[2],  -cS[6],
      -cS[2],       0,  -cS[6],
           0,   cS[2],  -cS[6],
      
       cS[3],       0,  -cS[7],
           0,  -cS[3],  -cS[7],
      -cS[3],       0,  -cS[7],
           0,   cS[3],  -cS[7],
      
       cS[4],   cS[4],  -cS[8],
       cS[4],  -cS[4],  -cS[8],
      -cS[4],  -cS[4],  -cS[8],
      -cS[4],   cS[4],  -cS[8],
      
           0,       0,  -cS[9]        
    }; 
    
    float[] leftVertices = new float[] {
       -cS[5],   cS[1],  -cS[1],
       -cS[5],  -cS[1],  -cS[1],
       -cS[5],  -cS[1],   cS[1],
       -cS[5],   cS[1],   cS[1],
      
       -cS[6],   cS[2],  -cS[2],
       -cS[6],  -cS[2],  -cS[2],
       -cS[6],  -cS[2],   cS[2],
       -cS[6],   cS[2],   cS[2],
      
       -cS[6],       0,  -cS[2],
       -cS[6],  -cS[2],       0,
       -cS[6],       0,   cS[2],
       -cS[6],   cS[2],       0,
      
       -cS[7],       0,  -cS[3],
       -cS[7],  -cS[3],       0,
       -cS[7],       0,   cS[3],
       -cS[7],   cS[3],       0,
      
       -cS[8],   cS[4],  -cS[4],
       -cS[8],  -cS[4],  -cS[4],
       -cS[8],  -cS[4],   cS[4],
       -cS[8],   cS[4],   cS[4],
      
       -cS[9],       0,       0
    };
    
    float[] rightVertices = new float[] {
       cS[5],   cS[1],   cS[1],
       cS[5],  -cS[1],   cS[1],
       cS[5],  -cS[1],  -cS[1],
       cS[5],   cS[1],  -cS[1],
      
       cS[6],   cS[2],   cS[2],
       cS[6],  -cS[2],   cS[2],
       cS[6],  -cS[2],  -cS[2],
       cS[6],   cS[2],  -cS[2],
      
       cS[6],       0,   cS[2],
       cS[6],  -cS[2],       0,
       cS[6],       0,  -cS[2],
       cS[6],   cS[2],       0,
      
       cS[7],       0,   cS[3],
       cS[7],  -cS[3],       0,
       cS[7],       0,  -cS[3],
       cS[7],   cS[3],       0,
       
       cS[8],   cS[4],   cS[4],
       cS[8],  -cS[4],   cS[4],
       cS[8],  -cS[4],  -cS[4],
       cS[8],   cS[4],  -cS[4],
      
       cS[9],       0,       0
    };
    
    byte[] indices = new byte[] {       
         0,  5,  4,
         0,  1,  5,
         1,  6,  5,
         1,  2,  6,
         2,  7,  6,
         2,  3,  7,
         3,  4,  7,
         3,  0,  4,
         
        //#
         8, 12, 16,
         8, 17, 12,
         9, 13, 17,
         9, 18, 13,
        10, 14, 18,
        10, 19, 14,
        11, 16, 15,
        11, 15, 19,
        
        //#
        11,  4, 16,
         4,  8, 16,
         8,  5, 17,
         5,  9, 17,
         9,  6, 18,
         6, 10, 18,
        10,  7, 19,
         7, 11, 19,
         
        //#
        12, 20, 16,
        12, 17, 20,
        13, 20, 17,
        13, 18, 20,
        14, 20, 18,
        14, 19, 20,
        15, 20, 19,
        15, 16, 20 
        };

    sides.add(new CubeFace_gl(topVertices,   indices)); // top
    sides.add(new CubeFace_gl(btmVertices,   indices)); // bottom
    sides.add(new CubeFace_gl(frontVertices, indices)); // front
    sides.add(new CubeFace_gl(backVertices,  indices)); // back
    sides.add(new CubeFace_gl(rightVertices, indices)); // right
    sides.add(new CubeFace_gl(leftVertices,  indices)); // left
  }

  /*
   * Mit dieser Methode laesst sich ein Wuerfel zeichnen. Dazu muss der GL10
   * Kontext uebergeben werden.
   */
  protected void draw(GL10 gl) {
    if (gl == null)
      throw new InvalidParameterException();
    
    sides.get(Constants.UP).draw(gl);
    sides.get(Constants.DOWN).draw(gl);
    sides.get(Constants.FRONT).draw(gl);
    sides.get(Constants.BACK).draw(gl);
    sides.get(Constants.RIGHT).draw(gl);
    sides.get(Constants.LEFT).draw(gl);
  }

  /*
   * Diese Methode zeichnet die vereinfachten Wuerfelseiten fuer die Touch
   * Control.
   */
  protected void drawMask(GL10 gl) {
    if (gl == null)
      throw new InvalidParameterException();
    
    sides.get(Constants.UP).drawMask(gl);
    sides.get(Constants.DOWN).drawMask(gl);
    sides.get(Constants.FRONT).drawMask(gl);
    sides.get(Constants.BACK).drawMask(gl);
    sides.get(Constants.RIGHT).drawMask(gl);
    sides.get(Constants.LEFT).drawMask(gl);
  }
 

  /*
   * Diese Methode setzt die Farbe einer bestimmten Wuerfelseite. Die Konstanten
   * fuer int side sind in Constants_gl definiert.
   */
  protected void setColor(int side, CubeColor_gl color) {
    if (side >= 0 && side < sides.size()) {
      sides.get(side).setColor(color);
    } else {
      throw new InvalidParameterException();
    }
  }

  /*
   * Setzt die einfache Farbe fuer die Touchsteuerung.
   */
  protected void setColorSimple(int side, CubeColor_gl color){
    if (side >= 0 && side < sides.size()) {
      sides.get(side).setColorSimple(color);
      } else {
      throw new InvalidParameterException();
    }
  }
  
  @Override
  public String toString() {
    String ret = "";
    int count = 0;
    ret += "Cube Width: " + cS[0] + "\n";
    for (CubeFace_gl f : sides) {
      ret += "CubeFace_gl " + count + f.toString();
      count++;
    }
    return ret;
  }
}