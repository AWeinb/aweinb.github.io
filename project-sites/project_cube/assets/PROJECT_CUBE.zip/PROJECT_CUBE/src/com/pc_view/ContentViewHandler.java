package com.pc_view;

import com.pc_controller.R;

/**
 * Diese Klasse regelt den Zugriff auf die Layouts. Jedes Layout kann hier per
 * getter-Methode abgerufen werden.
 * 
 * @author AxP
 */
public class ContentViewHandler {

  /**
   * Splashscreen
   * 
   * @return ID
   */
  public static int getIntroLayout() {
    return R.layout.intro_layout;
  }

  /**
   * Die Methode <code>public static int getMainLayout()</code> gibt das
   * Beginnlayout zur&#252;ck, das im Hauptmen&#252; verwendet wird.
   * 
   * @return Die ID des Hauptlayouts.
   */
  public static int getMainLayout() {
    return R.layout.main_layout;
  }

  public static int getMainLayoutRootNode() {
    return R.id.mainLayoutRoot;
  }

  /**
   * Die Methode <code>public static int getDialogLayout()</code> gibt das
   * Dialog Layout zur&#252;ck.
   * 
   * @return Die ID des Dialoglayouts.
   */
  public static int getDialogLayout() {
    return R.layout.dialog;
  }

  public static int getDialogLayoutRootNode() {
    return R.id.dialog_root;
  }

  /**
   * Die Methode <code>public static int getOptionsLayout()</code> gibt das
   * Optionenlayout zur&#252;ck, in dem Buttons und Textfelder des
   * Optionenfensters definiert werden.
   * 
   * @return Die ID des Optionenlayouts.
   */
  public static int getOptionsLayout() {
    return R.layout.options_layout;
  }

  public static int getOptionsLayoutRootNode() {
    return R.id.optionsLayoutRootNode;
  }

  /**
   * Die Methode <code>public static int getGameLayout()</code> gibt das
   * Spiellayout zur&#252;ck.
   * 
   * @return Die ID des Spiellayouts.
   */
  public static int getGameLayout() {
    return R.layout.game_layout;
  }
  
  public static int getGameLayoutRootNode() {
    return R.id.g_rootNode;
  }

  /**
   * Die Methode <code>public static int getPauseMenuLayout()</code> gibt das
   * Pausenmen&#252;layout zur&#252;ck.
   * 
   * @return Die ID des Pausenlayouts.
   */
  public static int getPauseMenuLayout() {
    return R.layout.pausemenu_layout;
  }

  public static int getPauseMenuLayoutRootNode() {
    return R.id.pauseLayoutRootNode;
  }

  /**
   * Die Methode <code>public static int getHelpScreenLayout()</code> gibt das
   * Spielhilfelayout zur&#252;ck.
   * 
   * @return Die ID des Spielhilfelayouts.
   */
  public static int getHelpScreenLayout() {
    return R.layout.help_layout;
  }
  
  public static int getHelpScreenLayoutRootNode() {
    return R.id.g_help_root;
  }
  
  /**
   * Die Methode <code>public static int getInfoLayout()</code> gibt das
   * getInfoLayout zur&#252;ck.
   * 
   * @return Die ID des getInfoLayouts.
   */
  public static int getInfoLayout() {
    return R.layout.about_layout;
  }
  
  public static int getInfoLayoutRootNode() {
    return R.id.m_about_root;
  }
}
