package com.pc_view.openGL;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.security.InvalidParameterException;

import javax.microedition.khronos.opengles.GL10;

/**
 * Die Klasse CubeFace erzeugt die Fl&#228;chenmodelle der W&#252;rfel. Es
 * m&#252;ssen die Vertices und die Indices als Array &#252;bergeben werden.
 * 
 * @author AxP
 * 
 */
class CubeFace_gl {
  private static final String SETCOLOR_ERROR = "void setColor(CubeColor_gl color): color is null!";
  /*
   * Die Arrays werden in Buffer eingelagert damit sie von OpenGL verarbeitet
   * werden k&#246;nnen.
   */
  private FloatBuffer vertexBuffer;
  private ByteBuffer indexBuffer;
  private FloatBuffer colorBuffer;
  private FloatBuffer colorBufferSimple;

  private int indexLength;
  private float[] colors;
  private float[] colorsSimple;

  /*
   * Der Konstruktor &#252;bernimmt die Eckpunkte und die die Definition, wie
   * diese verbunden werden sollen. Die Anordnung der Create Methoden f&#252;r
   * die verschiedenen Buffer sollte beibehalten werden.
   */
  protected CubeFace_gl(float[] vertices, byte[] indices) {
    if (vertices == null || indices == null || vertices.length == 0 || indices.length == 0)
      throw new InvalidParameterException();

    this.indexLength = indices.length;
    this.colors = new float[84];
    this.colorsSimple = new float[84];
    this.setColor(new CubeColor_gl(0f, 0f, 0f, 1f));
    this.setColorSimple(new CubeColor_gl(1f, 1f, 1f, 1f));

    {
      this.vertexBuffer = makeDirectFloatBuffer(vertices);
      this.indexBuffer = makeDirectByteBuffer(indices);
      this.colorBuffer = makeDirectFloatBuffer(colors);
      this.colorBufferSimple = makeDirectFloatBuffer(colorsSimple);
    }
  }

  /*
   * Die Methode draw sorgt letztendlich daf&#252;r das die Fl&#228;che auf dem
   * Display erscheint. Die Fl&#228;che wird dabei nur von einer Seite angemalt.
   * Das ist bei der Punkt&#252;bergabe zu beachten.
   */
  protected void draw(GL10 gl) {
    if (gl == null)
      throw new InvalidParameterException();

    gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
    gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer);
    gl.glDrawElements(GL10.GL_TRIANGLES, indexLength, GL10.GL_UNSIGNED_BYTE, indexBuffer);
  }

  /*
   * Zeichnet die einfache Farbauswahl fuer die Touchsteuerung.
   */
  protected void drawMask(GL10 gl) {
    if (gl == null)
      throw new InvalidParameterException();

    gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
    gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBufferSimple);
    gl.glDrawElements(GL10.GL_TRIANGLES, indexLength, GL10.GL_UNSIGNED_BYTE, indexBuffer);
  }

  /*
   * Die Fl&#228;che wird nach einem gewissen Prinzip eingef&#228;rbt. Jede
   * Zeile f&#228;rbt einen Punkt des &#252;bergebenen Arrays ein, der Reihe
   * nach. Verschiedene Farben laufen ineinander &#252;ber.
   */
  protected void setColor(CubeColor_gl color) {
    if (color != null) {
      // Zum Neuf&#228;rben muss der Colorbuffer neu erzeugt werden, also auch
      // das Farbarray.
      // Vertex 0
      colors[0] = 0.0f;
      colors[1] = 0.0f;
      colors[2] = 0.0f;
      colors[3] = 1.0f * color.alpha;

      // Vertex 1
      colors[4] = 0.0f;
      colors[5] = 0.0f;
      colors[6] = 0.0f;
      colors[7] = 1.0f * color.alpha;

      // Vertex 2
      colors[8] = 0.0f;
      colors[9] = 0.0f;
      colors[10] = 0.0f;
      colors[11] = 1.0f * color.alpha;

      // Vertex 3
      colors[12] = 0.0f;
      colors[13] = 0.0f;
      colors[14] = 0.0f;
      colors[15] = 1.0f * color.alpha;

      // Vertex 4
      colors[16] = 1.0f * color.red;
      colors[17] = 1.0f * color.green;
      colors[18] = 1.0f * color.blue;
      colors[19] = 1.0f * color.alpha;

      // Vertex 5
      colors[20] = 1.0f * color.red;
      colors[21] = 1.0f * color.green;
      colors[22] = 1.0f * color.blue;
      colors[23] = 1.0f * color.alpha;

      // Vertex 6
      colors[24] = 1.0f * color.red;
      colors[25] = 1.0f * color.green;
      colors[26] = 1.0f * color.blue;
      colors[27] = 1.0f * color.alpha;

      // Vertex 7
      colors[28] = 1.0f * color.red;
      colors[29] = 1.0f * color.green;
      colors[30] = 1.0f * color.blue;
      colors[31] = 1.0f * color.alpha;

      // Vertex 8
      colors[32] = 1.0f * color.red;
      colors[33] = 1.0f * color.green;
      colors[34] = 1.0f * color.blue;
      colors[35] = 1.0f * color.alpha;

      // Vertex 9
      colors[36] = 1.0f * color.red;
      colors[37] = 1.0f * color.green;
      colors[38] = 1.0f * color.blue;
      colors[39] = 1.0f * color.alpha;

      // Vertex 10
      colors[40] = 1.0f * color.red;
      colors[41] = 1.0f * color.green;
      colors[42] = 1.0f * color.blue;
      colors[43] = 1.0f * color.alpha;

      // Vertex 11
      colors[44] = 1.0f * color.red;
      colors[45] = 1.0f * color.green;
      colors[46] = 1.0f * color.blue;
      colors[47] = 1.0f * color.alpha;

      // Vertex 12
      colors[48] = 0.9f * color.red;
      colors[49] = 0.9f * color.green;
      colors[50] = 0.9f * color.blue;
      colors[51] = 1.0f * color.alpha;

      // Vertex 13
      colors[52] = 0.9f * color.red;
      colors[53] = 0.9f * color.green;
      colors[54] = 0.9f * color.blue;
      colors[55] = 1.0f * color.alpha;

      // Vertex 14
      colors[56] = 0.9f * color.red;
      colors[57] = 0.9f * color.green;
      colors[58] = 0.9f * color.blue;
      colors[59] = 1.0f * color.alpha;

      // Vertex 15
      colors[60] = 0.9f * color.red;
      colors[61] = 0.9f * color.green;
      colors[62] = 0.9f * color.blue;
      colors[63] = 1.0f * color.alpha;

      // Vertex 16
      colors[64] = 1.0f * color.red;
      colors[65] = 1.0f * color.green;
      colors[66] = 1.0f * color.blue;
      colors[67] = 1.0f * color.alpha;

      // Vertex 17
      colors[68] = 1.0f * color.red;
      colors[69] = 1.0f * color.green;
      colors[70] = 1.0f * color.blue;
      colors[71] = 1.0f * color.alpha;

      // Vertex 18
      colors[72] = 1.0f * color.red;
      colors[73] = 1.0f * color.green;
      colors[74] = 1.0f * color.blue;
      colors[75] = 1.0f * color.alpha;

      // Vertex 19
      colors[76] = 1.0f * color.red;
      colors[77] = 1.0f * color.green;
      colors[78] = 1.0f * color.blue;
      colors[79] = 1.0f * color.alpha;

      // Vertex 20
      colors[80] = 1.0f * color.red;
      colors[81] = 1.0f * color.green;
      colors[82] = 1.0f * color.blue;
      colors[83] = 1.0f * color.alpha;

      this.colorBuffer = makeDirectFloatBuffer(colors);

    } else {
      throw new InvalidParameterException(SETCOLOR_ERROR);
    }
  }

  /*
   * Die Fl&#228;che wird nach einem gewissen Prinzip eingef&#228;rbt. Jede
   * Zeile f&#228;rbt einen Punkt des &#252;bergebenen Arrays ein, der Reihe
   * nach. Verschiedene Farben laufen ineinander &#252;ber.
   * 
   * Es werden hier die Flaechen einfarbig gefaerbt.
   */

  protected void setColorSimple(CubeColor_gl color) {
    if (color != null) {
      // Zum Neuf&#228;rben muss der colorSimplebuffer neu erzeugt werden, also
      // auch das Farbarray.

      // Vertex 0
      colorsSimple[0] = 1.0f * color.red;
      colorsSimple[1] = 1.0f * color.green;
      colorsSimple[2] = 1.0f * color.blue;
      colorsSimple[3] = 1.0f * color.alpha;

      // Vertex 1
      colorsSimple[4] = 1.0f * color.red;
      colorsSimple[5] = 1.0f * color.green;
      colorsSimple[6] = 1.0f * color.blue;
      colorsSimple[7] = 1.0f * color.alpha;

      // Vertex 2
      colorsSimple[8] = 1.0f * color.red;
      colorsSimple[9] = 1.0f * color.green;
      colorsSimple[10] = 1.0f * color.blue;
      colorsSimple[11] = 1.0f * color.alpha;

      // Vertex 3
      colorsSimple[12] = 1.0f * color.red;
      colorsSimple[13] = 1.0f * color.green;
      colorsSimple[14] = 1.0f * color.blue;
      colorsSimple[15] = 1.0f * color.alpha;

      // Vertex 4
      colorsSimple[16] = 1.0f * color.red;
      colorsSimple[17] = 1.0f * color.green;
      colorsSimple[18] = 1.0f * color.blue;
      colorsSimple[19] = 1.0f * color.alpha;

      // Vertex 5
      colorsSimple[20] = 1.0f * color.red;
      colorsSimple[21] = 1.0f * color.green;
      colorsSimple[22] = 1.0f * color.blue;
      colorsSimple[23] = 1.0f * color.alpha;

      // Vertex 6
      colorsSimple[24] = 1.0f * color.red;
      colorsSimple[25] = 1.0f * color.green;
      colorsSimple[26] = 1.0f * color.blue;
      colorsSimple[27] = 1.0f * color.alpha;

      // Vertex 7
      colorsSimple[28] = 1.0f * color.red;
      colorsSimple[29] = 1.0f * color.green;
      colorsSimple[30] = 1.0f * color.blue;
      colorsSimple[31] = 1.0f * color.alpha;

      // Vertex 8
      colorsSimple[32] = 1.0f * color.red;
      colorsSimple[33] = 1.0f * color.green;
      colorsSimple[34] = 1.0f * color.blue;
      colorsSimple[35] = 1.0f * color.alpha;

      // Vertex 9
      colorsSimple[36] = 1.0f * color.red;
      colorsSimple[37] = 1.0f * color.green;
      colorsSimple[38] = 1.0f * color.blue;
      colorsSimple[39] = 1.0f * color.alpha;

      // Vertex 10
      colorsSimple[40] = 1.0f * color.red;
      colorsSimple[41] = 1.0f * color.green;
      colorsSimple[42] = 1.0f * color.blue;
      colorsSimple[43] = 1.0f * color.alpha;

      // Vertex 11
      colorsSimple[44] = 1.0f * color.red;
      colorsSimple[45] = 1.0f * color.green;
      colorsSimple[46] = 1.0f * color.blue;
      colorsSimple[47] = 1.0f * color.alpha;

      // Vertex 12
      colorsSimple[48] = 1.0f * color.red;
      colorsSimple[49] = 1.0f * color.green;
      colorsSimple[50] = 1.0f * color.blue;
      colorsSimple[51] = 1.0f * color.alpha;

      // Vertex 13
      colorsSimple[52] = 1.0f * color.red;
      colorsSimple[53] = 1.0f * color.green;
      colorsSimple[54] = 1.0f * color.blue;
      colorsSimple[55] = 1.0f * color.alpha;

      // Vertex 14
      colorsSimple[56] = 1.0f * color.red;
      colorsSimple[57] = 1.0f * color.green;
      colorsSimple[58] = 1.0f * color.blue;
      colorsSimple[59] = 1.0f * color.alpha;

      // Vertex 15
      colorsSimple[60] = 1.0f * color.red;
      colorsSimple[61] = 1.0f * color.green;
      colorsSimple[62] = 1.0f * color.blue;
      colorsSimple[63] = 1.0f * color.alpha;

      // Vertex 16
      colorsSimple[64] = 1.0f * color.red;
      colorsSimple[65] = 1.0f * color.green;
      colorsSimple[66] = 1.0f * color.blue;
      colorsSimple[67] = 1.0f * color.alpha;

      // Vertex 17
      colorsSimple[68] = 1.0f * color.red;
      colorsSimple[69] = 1.0f * color.green;
      colorsSimple[70] = 1.0f * color.blue;
      colorsSimple[71] = 1.0f * color.alpha;

      // Vertex 18
      colorsSimple[72] = 1.0f * color.red;
      colorsSimple[73] = 1.0f * color.green;
      colorsSimple[74] = 1.0f * color.blue;
      colorsSimple[75] = 1.0f * color.alpha;

      // Vertex 19
      colorsSimple[76] = 1.0f * color.red;
      colorsSimple[77] = 1.0f * color.green;
      colorsSimple[78] = 1.0f * color.blue;
      colorsSimple[79] = 1.0f * color.alpha;

      // Vertex 20
      colorsSimple[80] = 1.0f * color.red;
      colorsSimple[81] = 1.0f * color.green;
      colorsSimple[82] = 1.0f * color.blue;
      colorsSimple[83] = 1.0f * color.alpha;

      this.colorBufferSimple = makeDirectFloatBuffer(colorsSimple);

    } else {
      throw new InvalidParameterException(SETCOLOR_ERROR);
    }
  }

  /*
   * Hilfsmethode um einen Floatbuffer aus einem Array zu erstellen.
   */
  private static FloatBuffer makeDirectFloatBuffer(float[] array) {
    int len = array.length * (Float.SIZE / 8);
    ByteBuffer storage = ByteBuffer.allocateDirect(len);
    storage.order(ByteOrder.nativeOrder());
    FloatBuffer buffer = storage.asFloatBuffer();
    buffer.put(array);
    buffer.position(0);

    return buffer;
  }

  /*
   * Hilfsmethode um einen Bytebuffer aus einem Array zu erstellen.
   */
  private static ByteBuffer makeDirectByteBuffer(byte[] array) {
    int len = array.length * (Byte.SIZE / 8);
    ByteBuffer buffer = ByteBuffer.allocateDirect(len);
    buffer.put(array);
    buffer.position(0);

    return buffer;
  }

  @Override
  public String toString() {
    String ret = "Klasse CubeFace_gl: ";
    ret += "Vertex Buffer: " + vertexBuffer + " | ";
    ret += "Index Buffer: " + indexBuffer + " | ";
    ret += "Color Buffer: " + colorBuffer + " | ";
    ret += "Color Buffer Simple: " + colorBufferSimple + " | ";
    return ret;
  }
}
