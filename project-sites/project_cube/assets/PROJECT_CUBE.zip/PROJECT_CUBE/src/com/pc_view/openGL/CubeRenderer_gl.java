package com.pc_view.openGL;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.InvalidParameterException;
import java.util.ArrayList;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.GLU;

import com.pc_controller.ColorOGLMovementTranslator;
import com.pc_util.Constants;

/**
 * Die Klasse CubeRenderer sorgt f&#252;r die Darstellung des OpenGL Models.
 * 
 * @author AxP
 */
class CubeRenderer_gl implements Renderer {

  // Liste die alle Unterwuerfel beinhaltet.
  private ArrayList<Cube_gl> cubeList;
  // Liste die die aussenliegenden Ebenen beinhaltet. Dient der Farbgebung.
  private ArrayList<CubeLayer_gl> layerList;

  // Epsilon
  private float eps = 0.01f;
  // Distanz vom Ursprung bis zum Zeichenpunkt des naechsten Wuerfels.
  private float dist;

  /*
   * Array mit jedem Winkel des Wuerfels. Winkel der X-Achse von Links nach Rechts haben Index 0,1,2. Winkel der Y-Achse
   * von Oben nach Unten haben Index 3,4,5. Winkel der Z-Achse von Vorne nach Hinten haben Index 6,7,8.
   */
  private float[] angles;
  /*
   * X: coords[0] <----> coords[2] : Left <-> Right Y: coords[3] <----> coords[5] : Top <-> Bottom Z: coords[6] <---->
   * coords[8] : Front <-> Back
   * 
   * OpenGL Zeichen Koordinaten
   */
  private float[] coords;

  private static final String PAINTFACE_ERROR = "void paintFaceOnSide: Wrong Layer Parameter!";
  private static final String ROTATELAYER_ERROR = "void rotateLayerAxis: Wrong Axis Parameter!";
  private static final String ANIMANGLE_ERROR = "void setAnimAngle: Wrong Parameter!";

  private int width;
  private int height;
  private ByteBuffer cubeAt;
  
  private String filter;

  /**
   * Renderer Konstruktor. Initialisiert Zeichenkoordinaten und W&#252;rfelobjekte.
   */
  protected CubeRenderer_gl(float cubeWidth, float cubeMargin, float zTranslateBack, String filter) {
    this.filter = filter;
    
    this.angles = new float[] { 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f };
    this.coords = new float[Constants_gl.MAXFACES];

    this.dist = cubeWidth + cubeMargin;

    this.coords[1] = 0f; // X Mitte
    this.coords[0] = coords[1] - dist; // X Links
    this.coords[2] = coords[1] + dist; // X Rechts

    this.coords[4] = 0f; // Y Mitte
    this.coords[5] = coords[4] - dist; // Y Unten
    this.coords[3] = coords[4] + dist; // Y Oben

    this.coords[8] = zTranslateBack; // Z Hinten
    this.coords[7] = coords[8] + dist; // Z Mitte
    this.coords[6] = coords[8] + 2 * dist; // Z Vorne

    cubeList = new ArrayList<Cube_gl>();

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));
    cubeList.add(new Cube_gl(cubeWidth));

    // Ebenen : nur Au&#223;enseiten.
    layerList = new ArrayList<CubeLayer_gl>();

    // top
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(6), cubeList.get(15), cubeList.get(24),
        cubeList.get(7), cubeList.get(16), cubeList.get(25), cubeList.get(8), cubeList.get(17), cubeList.get(26) }));

    // btm
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(2), cubeList.get(11), cubeList.get(20),
        cubeList.get(1), cubeList.get(10), cubeList.get(19), cubeList.get(0), cubeList.get(9), cubeList.get(18) }));

    // front
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(8), cubeList.get(17), cubeList.get(26),
        cubeList.get(5), cubeList.get(14), cubeList.get(23), cubeList.get(2), cubeList.get(11), cubeList.get(20) }));

    // back
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(24), cubeList.get(15), cubeList.get(6),
        cubeList.get(21), cubeList.get(12), cubeList.get(3), cubeList.get(18), cubeList.get(9), cubeList.get(0) }));

    // right
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(26), cubeList.get(25), cubeList.get(24),
        cubeList.get(23), cubeList.get(22), cubeList.get(21), cubeList.get(20), cubeList.get(19), cubeList.get(18) }));

    // left
    layerList.add(new CubeLayer_gl(new Cube_gl[] { cubeList.get(6), cubeList.get(7), cubeList.get(8), cubeList.get(3),
        cubeList.get(4), cubeList.get(5), cubeList.get(0), cubeList.get(1), cubeList.get(2) }));

    // Einfache Farbansicht um einzelne Steine mit glReadPixels zu
    // identifizieren.
    setColorTouchControl();
  }

  /*
   * OpenGL Zeichenmethode. Die Unterw&#252;rfel werden im Raum nacheinander versetzt und gezeichnet. Rotationen und
   * Verschiebungen m&#252;ssen hier aufgerufen werden.
   * 
   * (non-Javadoc)
   * 
   * @see android.opengl.GLSurfaceView.Renderer#onDrawFrame(javax.microedition.khronos .opengles.GL10)
   */
  public void onDrawFrame(GL10 gl) throws InvalidParameterException {
    if (gl == null)
      throw new InvalidParameterException();

    // Sicht loeschen.
    gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
    gl.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

    // Zeichenbereich
    gl.glFrustumf(10, 10, 10, 10, 0, -50);

    // Nur Au�enseite mit Farbe versehen
    gl.glFrontFace(GL10.GL_CCW);
    gl.glEnable(GL10.GL_CULL_FACE);
    gl.glCullFace(GL10.GL_BACK);

    // Aktivieren von Vertex/ Farb Annahme
    gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
    gl.glEnableClientState(GL10.GL_COLOR_ARRAY);

    if (filter.equals(Constants.FILTER1)) {
      gl.glDisable(GL10.GL_LIGHTING);
      gl.glDisable(GL10.GL_CULL_FACE);
      gl.glDisable(GL10.GL_DEPTH_BUFFER_BIT);
      gl.glDisable(GL10.GL_DEPTH_TEST);
      gl.glEnable(GL10.GL_DITHER);
      gl.glShadeModel(GL10.GL_SMOOTH);
      gl.glEnable(GL10.GL_BLEND);
      gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE);
    }

    // for-Schleifen := Koordinatensystem.
    int count = 0;
    for (float x = coords[0]; x <= coords[2]; x += dist) {
      for (float y = coords[5]; y <= coords[3]; y += dist) {
        for (float z = coords[8]; z <= coords[6]; z += dist) {
          // Identitaetsmatrix
          gl.glLoadIdentity();

          // Positionierung des Objekts.
          gl.glTranslatef(x, y, z);

          // Rotieren des ganzen Wuerfels.
          rotateCubeX(gl, 30f, x, y, z);
          rotateCubeY(gl, 45f, x, y, z);

          // Ebene Links
          if (angles[0] != 0)
            rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_ONE, angles[0], x, y, z);

          // Ebene Mitte x
          if (angles[1] != 0)
            rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_TWO, angles[1], x, y, z);

          // Ebene Rechts
          if (angles[2] != 0)
            rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_THREE, angles[2], x, y, z);

          // Ebene Oben
          if (angles[3] != 0)
            rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_ONE, angles[3], x, y, z);

          // Ebene Mitte y
          if (angles[4] != 0)
            rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_TWO, angles[4], x, y, z);

          // Ebene Unten
          if (angles[5] != 0)
            rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_THREE, angles[5], x, y, z);

          // Ebene Vorne
          if (angles[6] != 0)
            rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_ONE, angles[6], x, y, z);

          // Ebene Mitte z
          if (angles[7] != 0)
            rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_TWO, angles[7], x, y, z);

          // Ebene Hinten
          if (angles[8] != 0)
            rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_THREE, angles[8], x, y, z);

          // Wuerfel Zeichnungsoperation
          cubeList.get(count).draw(gl);
          count++;
        }
      }
    }

    // Annahme beenden.
    gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
    gl.glDisableClientState(GL10.GL_COLOR_ARRAY);

    // Culling beenden.
    gl.glDisable(GL10.GL_CULL_FACE);

    // An Display weitergeben.
    gl.glFinish();
  }

  /*
   * OpenGL Zeichenmethode. Die Unterw&#252;rfel werden im Raum nacheinander versetzt und gezeichnet. Rotationen und
   * Verschiebungen m&#252;ssen hier aufgerufen werden. DIESE ZWEITE METHODE DIENT DER TOUCHSTEUERUNG.
   * 
   * (non-Javadoc)
   * 
   * @see android.opengl.GLSurfaceView.Renderer#onDrawFrame(javax.microedition.khronos .opengles.GL10)
   */
  public void drawFrameTouchControl(GL10 gl) throws InvalidParameterException {
    if (gl == null)
      throw new InvalidParameterException();

    gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
    gl.glFrustumf(10, 10, 10, 10, 0, -50);

    gl.glFrontFace(GL10.GL_CCW);
    gl.glEnable(GL10.GL_CULL_FACE);
    gl.glCullFace(GL10.GL_BACK);

    gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
    gl.glEnableClientState(GL10.GL_COLOR_ARRAY);

    int count = 0;
    for (float x = coords[0]; x <= coords[2]; x += dist) {
      for (float y = coords[5]; y <= coords[3]; y += dist) {
        for (float z = coords[8]; z <= coords[6]; z += dist) {
          gl.glLoadIdentity();
          // Positionierung des Objekts.
          gl.glTranslatef(x, y, z);

          rotateCubeX(gl, 30f, x, y, z);
          rotateCubeY(gl, 45f, x, y, z);

          // Wuerfel Zeichnungsoperation
          cubeList.get(count).drawMask(gl);
          count++;
        }
      }
    }
    gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
    gl.glDisableClientState(GL10.GL_COLOR_ARRAY);
    gl.glDisable(GL10.GL_CULL_FACE);

    gl.glFinish();

    {
      // Beachte: Aufzurufen nachdem die Daten an den Schirm weitergegeben
      // wurden. (finish)
      gl.glReadPixels(0, 0, width, height, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, cubeAt);
      ColorOGLMovementTranslator.setCubeAt(cubeAt);
    }
  }

  /*
   * Sobald das Display ge&#228;ndert wird, wird diese Methode aufgerufen.
   * 
   * (non-Javadoc)
   * 
   * @see android.opengl.GLSurfaceView.Renderer#onSurfaceChanged(javax.microedition .khronos.opengles.GL10, int, int)
   */
  public void onSurfaceChanged(GL10 gl, int width, int height) throws InvalidParameterException {
    if (gl == null || width < 0 || height < 0)
      throw new InvalidParameterException();

    // TouchControl
    {
      this.width = width;
      this.height = height;

      cubeAt = ByteBuffer.allocate(width * height * 4);
      cubeAt.order(ByteOrder.nativeOrder());
      setColorTouchControl();
    }

    // Standard Aufrufe.
    {
      gl.glViewport(0, 0, width, height);
      gl.glFrustumf(10, 10, 10, 10, 0, -50);
      gl.glMatrixMode(GL10.GL_PROJECTION);
      gl.glLoadIdentity();
      GLU.gluPerspective(gl, 45.0f, (float) width / (float) height, 1f, 50.0f);
      gl.glMatrixMode(GL10.GL_MODELVIEW);
      gl.glLoadIdentity();
      drawFrameTouchControl(gl);
    }
  }

  /*
   * Diese Methode wird aufgerufen, sobald das Sichtfenster erstellt wurde.
   * 
   * (non-Javadoc)
   * 
   * @see android.opengl.GLSurfaceView.Renderer#onSurfaceCreated(javax.microedition .khronos.opengles.GL10,
   * javax.microedition.khronos.egl.EGLConfig)
   */
  public void onSurfaceCreated(GL10 gl, EGLConfig config) throws InvalidParameterException {
    if (gl == null || config == null)
      throw new InvalidParameterException();

    /*
     * Hintergrundfarbe !!darf nicht (x,0,0,1);(0,x,0,1);(0,0,x,1) (x!=0) sein, da sie sonst als Flaeche erkannt wird.!!
     */
    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Hintergrundfarbe
    gl.glShadeModel(GL10.GL_SMOOTH);
    gl.glClearDepthf(1.0f);
    gl.glEnable(GL10.GL_DEPTH_TEST);
    gl.glDepthFunc(GL10.GL_LEQUAL);
    gl.glEnable(GL10.GL_POINT_SMOOTH | GL10.GL_LINE_SMOOTH);
    gl.glEnable(GL10.GL_PERSPECTIVE_CORRECTION_HINT | GL10.GL_NICEST);

    {
      cubeAt = ByteBuffer.allocate(width * height * 4);
      cubeAt.order(ByteOrder.nativeOrder());
      setColorTouchControl();
      drawFrameTouchControl(gl);
    }
  }

  /*
   * Diese Methode setzt einfachste Farbwerte auf die drei vorderen, sichtbaren Seiten um die Touchsteuerung damit so
   * exakt wie moeglich zu machen. Die Farbwerte werden danach mit glReadPixels ausgelesen.
   */
  protected void setColorTouchControl() {
    float x = 0.1f;

    for (int i = 0; i < Constants_gl.MAXFACES; i++) {
      paintFaceOnSideSimple(Constants.UP, i, new CubeColor_gl(0f, 0f, x, 1.0f));
      paintFaceOnSideSimple(Constants.FRONT, i, new CubeColor_gl(0f, x, 0f, 1.0f));
      paintFaceOnSideSimple(Constants.LEFT, i, new CubeColor_gl(x, 0f, 0f, 1.0f));

      x += 0.1f;
    }

    int[] size = { width, height };
    ColorOGLMovementTranslator.setDisplaySize(size);
  }

  /*
   * Diese Methode setzt den Farbwert einer Unterwuerfelseite.
   */
  protected void paintFaceOnSide(int layerID, int faceID, CubeColor_gl color) throws InvalidParameterException {
    if (layerList != null) {
      if (faceID > layerList.get(0).size || faceID < 0)
        throw new InvalidParameterException(PAINTFACE_ERROR);

      switch (layerID) {
      case Constants.UP:
        layerList.get(Constants.UP).layer.get(faceID).setColor(Constants.UP, color);
        break;

      case Constants.DOWN:
        layerList.get(Constants.DOWN).layer.get(faceID).setColor(Constants.DOWN, color);
        break;

      case Constants.FRONT:
        layerList.get(Constants.FRONT).layer.get(faceID).setColor(Constants.FRONT, color);
        break;

      case Constants.BACK:
        layerList.get(Constants.BACK).layer.get(faceID).setColor(Constants.BACK, color);
        break;

      case Constants.RIGHT:
        layerList.get(Constants.RIGHT).layer.get(faceID).setColor(Constants.RIGHT, color);
        break;

      case Constants.LEFT:
        layerList.get(Constants.LEFT).layer.get(faceID).setColor(Constants.LEFT, color);
        break;

      default:
        throw new InvalidParameterException(PAINTFACE_ERROR);
      }
    }
  }

  /*
   * Diese Methode setzt den Farbwert einer Unterwuerfelseite. SETZT FARBE FUER TOUCH CONTROL. Geaendert ist die
   * Farbverarbeitung in Face.
   */
  protected void paintFaceOnSideSimple(int layerID, int faceID, CubeColor_gl color) throws InvalidParameterException {
    if (layerList != null) {
      if (faceID > layerList.get(0).size || faceID < 0)
        throw new InvalidParameterException(PAINTFACE_ERROR);

      switch (layerID) {
      case Constants.UP:
        layerList.get(Constants.UP).layer.get(faceID).setColorSimple(Constants.UP, color);
        break;

      case Constants.DOWN:
        layerList.get(Constants.DOWN).layer.get(faceID).setColorSimple(Constants.DOWN, color);
        break;

      case Constants.FRONT:
        layerList.get(Constants.FRONT).layer.get(faceID).setColorSimple(Constants.FRONT, color);
        break;

      case Constants.BACK:
        layerList.get(Constants.BACK).layer.get(faceID).setColorSimple(Constants.BACK, color);
        break;

      case Constants.RIGHT:
        layerList.get(Constants.RIGHT).layer.get(faceID).setColorSimple(Constants.RIGHT, color);
        break;

      case Constants.LEFT:
        layerList.get(Constants.LEFT).layer.get(faceID).setColorSimple(Constants.LEFT, color);
        break;

      default:
        throw new InvalidParameterException(PAINTFACE_ERROR);
      }
    }
  }

  /*
   * Diese Methode setzt den entsprechenden Winkel fuer eine bestimmte Ebene.
   */
  protected void setAnimAngle(int axis, int layerCount, float angle) throws InvalidParameterException {
    switch (axis) {

    // X Achse
    case Constants_gl.XAXIS:
      switch (layerCount) {
      case Constants_gl.LAYER_ONE:
        angles[0] = angle;
        break;

      case Constants_gl.LAYER_TWO:
        angles[1] = angle;
        break;

      case Constants_gl.LAYER_THREE:
        angles[2] = angle;
        break;

      default:
        throw new InvalidParameterException(ANIMANGLE_ERROR);
      }
      break;

    // Y Achse
    case Constants_gl.YAXIS:
      switch (layerCount) {
      case Constants_gl.LAYER_ONE:
        angles[3] = angle;
        break;

      case Constants_gl.LAYER_TWO:
        angles[4] = angle;
        break;

      case Constants_gl.LAYER_THREE:
        angles[5] = angle;
        break;

      default:
        throw new InvalidParameterException(ANIMANGLE_ERROR);
      }
      break;

    // Z Achse
    case Constants_gl.ZAXIS:
      switch (layerCount) {
      case Constants_gl.LAYER_ONE:
        angles[6] = angle;
        break;

      case Constants_gl.LAYER_TWO:
        angles[7] = angle;
        break;

      case Constants_gl.LAYER_THREE:
        angles[8] = angle;
        break;

      default:
        throw new InvalidParameterException(ANIMANGLE_ERROR);
      }
      break;

    default:
      throw new InvalidParameterException(ANIMANGLE_ERROR);
    }
  }

  /*
   * Hilfsmethode um den ganzen Wuerfel um die X Achse zu rotieren.
   */
  private void rotateCubeX(GL10 gl, float angle, float x, float y, float z) {
    rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_ONE, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_TWO, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.XAXIS, Constants_gl.LAYER_THREE, angle, x, y, z);
  }

  /*
   * Hilfsmethode um den ganzen Wuerfel um die Y Achse zu rotieren.
   */
  private void rotateCubeY(GL10 gl, float angle, float x, float y, float z) {
    rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_ONE, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_TWO, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.YAXIS, Constants_gl.LAYER_THREE, angle, x, y, z);
  }

  /*
   * Hilfsmethode um den ganzen Wuerfel um die Z Achse zu rotieren.
   */
  @SuppressWarnings("unused")
  private void rotateCubeZ(GL10 gl, float angle, float x, float y, float z) {
    rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_ONE, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_TWO, angle, x, y, z);
    rotateLayerOnAxis(gl, Constants_gl.ZAXIS, Constants_gl.LAYER_THREE, angle, x, y, z);
  }

  /*
   * Hilfsmethode um eine Ebene um eine bestimmte Achse zu rotieren. Anzugeben sind Achse und die Ebenen ID.
   */
  private void rotateLayerOnAxis(GL10 gl, int axis, int layerID, float angle, float x, float y, float z) {
    switch (axis) {
    case Constants_gl.XAXIS:
      float layerX = coords[Constants_gl.XAXIS * 3 + layerID];

      /*
       * Ab hier steht Code der die Ebene x (Left, Middle, Right) rotiert, in Standartansicht von vorne vertikal drehend
       * zu sehen. Die y und z Koordinaten werden dazu ersteinmal wieder zur&#252;ckgesetzt und danach rotiert. Dann
       * wird der W&#252;rfel wieder zur&#252;ckbewegt.
       */
      // Top Front
      if (isEqual(x, layerX, eps) && isEqual(y, coords[3], eps) && isEqual(z, coords[6], eps)) {
        helpRotate(0, -dist, -dist, angle, gl, Constants_gl.XAXIS);

        // Top Mid
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[3], eps) && isEqual(z, coords[7], eps)) {
        helpRotate(0, -dist, 0, angle, gl, Constants_gl.XAXIS);

        // Top Back
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[3], eps) && isEqual(z, coords[8], eps)) {
        helpRotate(0, -dist, dist, angle, gl, Constants_gl.XAXIS);

        // Mid Front
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[4], eps) && isEqual(z, coords[6], eps)) {
        helpRotate(0, 0, -dist, angle, gl, Constants_gl.XAXIS);

        // Mid Mid
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[4], eps) && isEqual(z, coords[7], eps)) {
        helpRotate(0, 0, 0, angle, gl, Constants_gl.XAXIS);

        // Mid Back
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[4], eps) && isEqual(z, coords[8], eps)) {
        helpRotate(0, 0, dist, angle, gl, Constants_gl.XAXIS);

        // Bottom Front
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[5], eps) && isEqual(z, coords[6], eps)) {
        helpRotate(0, dist, -dist, angle, gl, Constants_gl.XAXIS);

        // Bottom Mid
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[5], eps) && isEqual(z, coords[7], eps)) {
        helpRotate(0, dist, 0, angle, gl, Constants_gl.XAXIS);

        // Bottom Back
      } else if (isEqual(x, layerX, eps) && isEqual(y, coords[5], eps) && isEqual(z, coords[8], eps)) {
        helpRotate(0, dist, dist, angle, gl, Constants_gl.XAXIS);
      }
      break;

    case Constants_gl.YAXIS:
      float layerY = coords[Constants_gl.YAXIS * 3 + layerID];

      /*
       * Ab hier steht Code der die Ebene y(Top, Middle, Bottom) rotiert, in Standartansicht von vorne waagerecht
       * drehend zu sehen. Die x und z Koordinaten werden dazu ersteinmal wieder zur&#252;ckgesetzt und danach rotiert.
       * Dann wird der W&#252;rfel wieder zur&#252;ckbewegt.
       */

      // Left Front
      if (isEqual(x, coords[0], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[6], eps)) {
        helpRotate(dist, 0, -dist, angle, gl, Constants_gl.YAXIS);

        // Mid Front
      } else if (isEqual(x, coords[1], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[6], eps)) {
        helpRotate(0, 0, -dist, angle, gl, Constants_gl.YAXIS);

        // Right Front
      } else if (isEqual(x, coords[2], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[6], eps)) {
        helpRotate(-dist, 0, -dist, angle, gl, Constants_gl.YAXIS);

        // Left Mid
      } else if (isEqual(x, coords[0], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[7], eps)) {
        helpRotate(dist, 0, 0, angle, gl, Constants_gl.YAXIS);

        // Mid Mid
      } else if (isEqual(x, coords[1], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[7], eps)) {
        helpRotate(0, 0, 0, angle, gl, Constants_gl.YAXIS);

        // Right Mid
      } else if (isEqual(x, coords[2], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[7], eps)) {
        helpRotate(-dist, 0, 0, angle, gl, Constants_gl.YAXIS);

        // Left Back
      } else if (isEqual(x, coords[0], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[8], eps)) {
        helpRotate(dist, 0, dist, angle, gl, Constants_gl.YAXIS);

        // Mid Back
      } else if (isEqual(x, coords[1], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[8], eps)) {
        helpRotate(0, 0, dist, angle, gl, Constants_gl.YAXIS);

        // Right Back
      } else if (isEqual(x, coords[2], eps) && isEqual(y, layerY, eps) && isEqual(z, coords[8], eps)) {
        helpRotate(-dist, 0, dist, angle, gl, Constants_gl.YAXIS);
      }
      break;

    case Constants_gl.ZAXIS:
      float layerZ = coords[Constants_gl.ZAXIS * 3 + layerID];

      /*
       * Ab hier steht Code der die Ebene z(Front, Middle, Back) rotiert, in Standartansicht frontal zu sehen. Die x und
       * y Koordinaten werden dazu ersteinmal wieder zur&#252;ckgesetzt und danach rotiert. Dann wird der W&#252;rfel
       * wieder zur&#252;ckbewegt.
       */

      // Up Left
      if (isEqual(x, coords[0], eps) && isEqual(y, coords[3], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(dist, -dist, 0, angle, gl, Constants_gl.ZAXIS);

        // Up Mid
      } else if (isEqual(x, coords[1], eps) && isEqual(y, coords[3], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(0, -dist, 0, angle, gl, Constants_gl.ZAXIS);

        // Up Right
      } else if (isEqual(x, coords[2], eps) && isEqual(y, coords[3], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(-dist, -dist, 0, angle, gl, Constants_gl.ZAXIS);

        // Mid Left
      } else if (isEqual(x, coords[0], eps) && isEqual(y, coords[4], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(dist, 0, 0, angle, gl, Constants_gl.ZAXIS);

        // Mid Mid
      } else if (isEqual(x, coords[1], eps) && isEqual(y, coords[4], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(0, 0, 0, angle, gl, Constants_gl.ZAXIS);

        // Mid Right
      } else if (isEqual(x, coords[2], eps) && isEqual(y, coords[4], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(-dist, 0, 0, angle, gl, Constants_gl.ZAXIS);

        // Bottom Left
      } else if (isEqual(x, coords[0], eps) && isEqual(y, coords[5], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(dist, dist, 0, angle, gl, Constants_gl.ZAXIS);

        // Bottom Mid
      } else if (isEqual(x, coords[1], eps) && isEqual(y, coords[5], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(0, dist, 0, angle, gl, Constants_gl.ZAXIS);

        // Bottom Right
      } else if (isEqual(x, coords[2], eps) && isEqual(y, coords[5], eps) && isEqual(z, layerZ, eps)) {
        helpRotate(-dist, dist, 0, angle, gl, Constants_gl.ZAXIS);
      }
      break;

    default:
      throw new InvalidParameterException(ROTATELAYER_ERROR);
    }
  }

  /*
   * Vergleichsmethode fuer floats.
   */
  private boolean isEqual(float a, float b, float epsilon) {
    return (Math.abs(a - b) < epsilon);
  }

  /*
   * Hilfsmethode die die OpenGL Methoden enthaelt, die die Rotation ausfuehren.
   */
  private void helpRotate(float xDist, float yDist, float zDist, float angle, GL10 gl, int axis) {
    switch (axis) {
    case Constants_gl.XAXIS:
      gl.glTranslatef(xDist, yDist, zDist);
      gl.glRotatef(angle, 1, 0, 0);
      gl.glTranslatef((-1) * xDist, (-1) * yDist, (-1) * zDist);
      break;

    case Constants_gl.YAXIS:
      gl.glTranslatef(xDist, yDist, zDist);
      gl.glRotatef(angle, 0, 1, 0);
      gl.glTranslatef((-1) * xDist, (-1) * yDist, (-1) * zDist);
      break;

    case Constants_gl.ZAXIS:
      gl.glTranslatef(xDist, yDist, zDist);
      gl.glRotatef(angle, 0, 0, 1);
      gl.glTranslatef((-1) * xDist, (-1) * yDist, (-1) * zDist);
      break;

    default:
      throw new InvalidParameterException(ROTATELAYER_ERROR);
    }
  }
}
