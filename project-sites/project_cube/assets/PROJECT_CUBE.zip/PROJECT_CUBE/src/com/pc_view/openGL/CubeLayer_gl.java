package com.pc_view.openGL;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Diese Klasse vereinfacht das f&#228;rben bestimmter W&#252;rfelfl&#228;chen.
 * Zu einer bestimmten Ebene geh&#246;rige W&#252;rfel werden hier gespeichert
 * und k&#246;nnen leicht abgerufen werden. Die Klasse ist auf 3x3x3 W&#252;rfel
 * zugeschnitten.
 * 
 * @author AxP
 * 
 */
final class CubeLayer_gl {
  /**
   * Liste mit allen W&#252;rfelseiten.
   */
  protected ArrayList<Cube_gl> layer;
  /**
   * W&#252;rfelgr&#246;&#223;e
   */
  protected int size;

  // Ein Ebenenkonstruktor der f&#252;r 3x3x3 W&#252;rfelebenen konzipiert ist.
  /**
   * @param cubes
   */
  protected CubeLayer_gl(Cube_gl[] cubes) {
    if (cubes == null || cubes.length == 0)
      throw new InvalidParameterException();

    this.layer = new ArrayList<Cube_gl>(Arrays.asList(cubes));
    this.size = layer.size();
  }

  @Override
  public String toString() {
    String ret = "CubeLayer_gl: Size: " + size + " ";
    return ret;
  }
}
