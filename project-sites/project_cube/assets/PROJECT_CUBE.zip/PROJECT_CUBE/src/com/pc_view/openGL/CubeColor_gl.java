package com.pc_view.openGL;

import java.security.InvalidParameterException;

/*
 * Klasse die das &#252;bergeben von Farbwerten vereinfacht.
 */
/**
 * @author AxP
 *
 */
final class CubeColor_gl {

  /**
   * Rotwert
   */
  protected float red;
  /**
   * Gr&#252;nwert
   */
  protected float green;
  /**
   * Blauwert
   */
  protected float blue;
  /**
   * Alphawert
   */
  protected float alpha;

  private String COLOR_ERROR = "Farbwert in CubeColor falsch!";

  /*
   * Konstruktor der die Grundfarben und einen Transparenzwert &#252;bernimmt. Die
   * Werte m&#252;ssen zwischen 0 und 1 liegen.
   */
  public CubeColor_gl(float red, float green, float blue, float alpha) {
    if (red >= 0 && red <= 1 && green >= 0 && green <= 1 && blue >= 0 && blue <= 1 && alpha >= 0 && alpha <= 1) {
      this.red = red;
      this.green = green;
      this.blue = blue;
      this.alpha = alpha;

    } else {
      throw new InvalidParameterException(COLOR_ERROR);
    }
  }
  
  @Override
  public String toString() {
    String ret = "Colors: Red(" + red + "); Green(" + green + "); Blue(" + blue + "); Alpha(" + alpha + ")";
    return ret;
  }
}
