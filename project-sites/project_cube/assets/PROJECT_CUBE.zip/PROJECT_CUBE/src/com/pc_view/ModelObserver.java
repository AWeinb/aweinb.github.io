package com.pc_view;

import java.security.InvalidParameterException;
import java.util.ArrayList;

import android.graphics.Color;

import com.pc_controller.PCAct_Game;
import com.pc_model.Cube;
import com.pc_model.CubeObserver;
import com.pc_model.GraphicCube;
import com.pc_model.Options;
import com.pc_util.Constants;
import com.pc_util.Constants.Colour;
import com.pc_view.openGL.Constants_gl;
import com.pc_view.openGL.MainCube_gl;

/**
 * Implementierung des Observers der Model und View verbindet.
 * 
 * @author AxP
 * 
 */
public class ModelObserver implements CubeObserver {

  private ArrayList<Colour[][]> colorsEnums;
  private ArrayList<float[][][]> colorsFloat;
  private int[] colors;

  private static final String UPDATE_ERROR = "c == null oder c.getFace(Constants.UP) == null";

  /**
   * Konstruktor der ModelObserver Klasse.
   */
  public ModelObserver() {
    this.colorsEnums = new ArrayList<Constants.Colour[][]>();
    this.colorsFloat = new ArrayList<float[][][]>();
    this.colors = Options.getOptionsInstance().getColours();
  }

  /**
   * Diese Update Methode ver&#228;ndert die Winkel des OpenGL Models. Nach einer 85 Grad Drehung m&#252;ssen die Farben
   * entsprechend ge&#228;ndert werden, da der W&#252;rfel ansonsten wie vor der Rotation aussieht. Das OpenGL Model hat
   * kein Ged&#228;chtnis.
   * 
   * @param Das
   *          W&#252;rfel Model aus dem die entsprechenden Winkel gelesen werden k&#246;nnen.
   */
  public void update(GraphicCube c) {
    if (c == null)
      throw new InvalidParameterException(UPDATE_ERROR);

    try {
      MainCube_gl.rotateLayerOnAxis(Constants_gl.XAXIS, Constants_gl.LAYER_ONE,
          c.getAngle(Constants_gl.XAXIS, Constants_gl.LAYER_ONE));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.XAXIS, Constants_gl.LAYER_TWO,
          c.getAngle(Constants_gl.XAXIS, Constants_gl.LAYER_TWO));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.XAXIS, Constants_gl.LAYER_THREE,
          c.getAngle(Constants_gl.XAXIS, Constants_gl.LAYER_THREE));

      MainCube_gl.rotateLayerOnAxis(Constants_gl.YAXIS, Constants_gl.LAYER_ONE,
          (-1) * c.getAngle(Constants_gl.YAXIS, Constants_gl.LAYER_ONE));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.YAXIS, Constants_gl.LAYER_TWO,
          (-1) * c.getAngle(Constants_gl.YAXIS, Constants_gl.LAYER_TWO));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.YAXIS, Constants_gl.LAYER_THREE,
          (-1) * c.getAngle(Constants_gl.YAXIS, Constants_gl.LAYER_THREE));

      MainCube_gl.rotateLayerOnAxis(Constants_gl.ZAXIS, Constants_gl.LAYER_ONE,
          (-1) * c.getAngle(Constants_gl.ZAXIS, Constants_gl.LAYER_ONE));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.ZAXIS, Constants_gl.LAYER_TWO,
          (-1) * c.getAngle(Constants_gl.ZAXIS, Constants_gl.LAYER_TWO));
      MainCube_gl.rotateLayerOnAxis(Constants_gl.ZAXIS, Constants_gl.LAYER_THREE,
          (-1) * c.getAngle(Constants_gl.ZAXIS, Constants_gl.LAYER_THREE));

      MainCube_gl.requestRender();

    } catch (IllegalStateException e) {
      PCAct_Game.requestRendererUpdate();
      e.printStackTrace();
    }
  }

  /**
   * Diese Update Methode aktualisiert die Farben der Unterfl&#228;chen.
   * 
   * @param Das
   *          Model das die Farbzuweisung enth&#228;lt.
   */
  public void update(Cube c) {
    if (c == null || c.getFace(0) == null)
      throw new InvalidParameterException(UPDATE_ERROR);

    try {

      // Fuer jede Seite gibt es eine Permutation, die zur besseren
      // Verarbeitung
      // in eine Liste geschrieben werden.
      if (colorsEnums.size() < Constants_gl.MAXSIDES) {
        colorsEnums.add(c.getFace(Constants.UP).getPermut());
        colorsEnums.add(c.getFace(Constants.DOWN).getPermut());
        colorsEnums.add(c.getFace(Constants.FRONT).getPermut());
        colorsEnums.add(c.getFace(Constants.BACK).getPermut());
        colorsEnums.add(c.getFace(Constants.RIGHT).getPermut());
        colorsEnums.add(c.getFace(Constants.LEFT).getPermut());

      } else {
        colorsEnums.set(0, c.getFace(Constants.UP).getPermut());
        colorsEnums.set(1, c.getFace(Constants.DOWN).getPermut());
        colorsEnums.set(2, c.getFace(Constants.FRONT).getPermut());
        colorsEnums.set(3, c.getFace(Constants.BACK).getPermut());
        colorsEnums.set(4, c.getFace(Constants.RIGHT).getPermut());
        colorsEnums.set(5, c.getFace(Constants.LEFT).getPermut());
      }

      /*
       * Fuer alle moeglichen Farben (Seiten) wird ein Array mit Farbwerten besetzt, dass die Groesse einer Wuerfelseite
       * hat.
       */
      int length = colorsEnums.get(0).length;

      if (colorsFloat.size() < 1) {
        int numColor = 4;// RGBA := 4 Werte
        for (int h = 0; h <= Constants_gl.MAXSIDES; h++) {
          colorsFloat.add(new float[length][length][numColor]);
        }
      }

      for (int h = 0; h < Constants_gl.MAXSIDES; h++) {
        for (int i = 0; i < length; i++) {
          for (int j = 0; j < length; j++) {
            Colour tmp = colorsEnums.get(h)[i][j];

            /*
             * colors wurde aus Options ausgelesen und enthaelt die zu verwendenden Farben. Diese haben die Form
             * 0xff00ff00. colors [0 bis 5] enthaelt die unterschiedlichen Farben.
             */

            int side;
            switch (tmp) {
            case WHI:
              side = Constants.UP;
              break;

            case YEL:
              side = Constants.DOWN;
              break;

            case BLU:
              side = Constants.FRONT;
              break;

            case GRE:
              side = Constants.BACK;
              break;

            case ORA:
              side = Constants.RIGHT;
              break;

            case RED:
              side = Constants.LEFT;
              break;

            default:
              throw new InvalidParameterException();
            }

            colorsFloat.get(h)[i][j][0] = (float) (Math.round(((Color.red(colors[side]) / 255f) * 100f))) / 100f;
            colorsFloat.get(h)[i][j][1] = (float) (Math.round(((Color.green(colors[side]) / 255f) * 100f))) / 100f;
            colorsFloat.get(h)[i][j][2] = (float) (Math.round(((Color.blue(colors[side]) / 255f) * 100f))) / 100f;
            colorsFloat.get(h)[i][j][3] = (float) (Math.round(((Color.alpha(colors[side]) / 255f) * 100f))) / 100f;
          }
        }
      }

      int indexRed = 0;
      int indexGreen = 1;
      int indexBlue = 2;
      int indexAlpha = 3;

      for (int i = 0; i < length; i++) {
        for (int j = 0; j < length; j++) {

          for (int x = Constants.UP; x < Constants_gl.MAXSIDES; x++) {
            float red = colorsFloat.get(x)[i][j][indexRed];
            float green = colorsFloat.get(x)[i][j][indexGreen];
            float blue = colorsFloat.get(x)[i][j][indexBlue];
            float alpha = colorsFloat.get(x)[i][j][indexAlpha];

            MainCube_gl.setColorOnFaceOfSide(x, i * 3 + j, red, green, blue, alpha);
          }
        }
      }

      MainCube_gl.requestRender();

    } catch (IllegalStateException e) {
      PCAct_Game.requestRendererUpdate();
      e.printStackTrace();
    }
  }
}
