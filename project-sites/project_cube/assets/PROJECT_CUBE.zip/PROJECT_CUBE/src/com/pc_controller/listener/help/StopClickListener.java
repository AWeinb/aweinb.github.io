package com.pc_controller.listener.help;

import com.pc_controller.PCAct_Game;

import android.view.View;
import android.view.View.OnClickListener;

/**
 * Diese KLasse implementiert einen OnClickListener. Er hoert den "Stop"-Button im Hilfemodus ab. Im Fall eines Klicks
 * wird die automatische Loesung des Wuerfels abgebrochen und es wird zum normalen Spielmodus zurueck gekehrt.
 */
public class StopClickListener implements OnClickListener {

  /* Verweis auf die aufrufende Activity. */
  private PCAct_Game lnk;

  /**
   * Erstellt einen OnClickListener, der den "Stop"-Button im Hilfemodus abhoert. Im Fall eines Klicks wird das
   * automatische Loesen des Wuerfels abgebrochen und zum normalen Spiel zurueck gekehrt.
   * 
   * @param lnk
   *          die aufrufende Activity
   */
  public StopClickListener(PCAct_Game lnk) {
    this.lnk = lnk;
  }

  /**
   * Hoert den "Stop"-Button im Hilfemodus ab. Im Fall eines Klicks wird das automatische Loesen des Wuerfels abgebrochen
   * und zum normalen Spiel zurueckgekehrt.
   * 
   * @param v
   *          das geklickte Viewelement.
   */
  public void onClick(View v) {
    lnk.stopSolver();

  }

}
