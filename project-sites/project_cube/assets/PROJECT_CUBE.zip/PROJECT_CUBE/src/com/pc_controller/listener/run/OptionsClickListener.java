package com.pc_controller.listener.run;

import com.pc_controller.PCAct_Run;

import android.view.View;

/**
 * OnClickListerner, der das Optionenmenue aufrufen kann.
 * */
public class OptionsClickListener implements View.OnClickListener {

  private PCAct_Run lnkPcAct_Run;

  /**
   * Erstellt einen OnClickListener, der das Optionenmenue aufrufen kann.
   * 
   * @param lnkPcAct_Game
   *          die aufrufende Activity
   */
  public OptionsClickListener(PCAct_Run lnkPcAct_Run) {
    this.lnkPcAct_Run = lnkPcAct_Run;
  }

  /**
   * Ruft das Optionenmenue auf.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Run.openOptions();
  }
}
