package com.pc_controller;

import android.os.Handler;

/**
 * Diese Klasse implementiert den Timer der nach einer Zeitspanne _delay die Run
 * Methode des Hauptthreads aufruft. Im Kontext dieses Programmes wird das nur
 * einmal geschehen.
 * 
 * @author AxP
 * 
 */
public class LayoutSwitcher implements Runnable {
  private boolean _running = true;
  private Handler _handler;
  private Runnable _runnable;
  private int _delay;

  /**
   * Konstruktor der Switcher Klasse.
   * 
   * @param runnable
   *          Das Runnable Objekt, beinhaltet die zu aufrufende Run Methode.
   * @param handler
   *          Ein Handler Objekt.
   */
  public LayoutSwitcher(Runnable runnable, Handler handler) {
    this._runnable = runnable;
    this._handler = handler;
    this._delay = 500;
  }

  /**
   * Schalter der Klasse. Bei false wird nichts mehr aufgerufen.
   * 
   * @param running
   */
  public void setRunning(boolean running) {
    this._running = running;
  }

  /**
   * Run Methode. Setzt das Delay und ruft Run Methode des Hauptthreads auf.
   */
  public void run() {
    while (_running) {
      try {
        Thread.sleep(_delay);

      } catch (InterruptedException ex) {
        ex.printStackTrace();
      }

      if (_running)
        _handler.post(_runnable);
    }
  }
}