package com.pc_controller;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.pc_model.Highscores;
import com.pc_model.ModelFacade;
import com.pc_model.Options;
import com.pc_util.Constants;
import com.pc_util.FontChangeHelper;
import com.pc_util.LanguageChangeHelper;
import com.pc_view.ContentViewHandler;

/**
 * Startmen&#252; des Zauberw&#252;rfelspiels Project_Cube. Es stellt dem
 * Spieler die M&#246;glichkeit, das Spiel zu laden und damit einen neuen oder
 * einen alten W&#252;rfel zu laden, oder das Optionenmen&#252; aufzurufen. Des
 * Weiteren bietet es M&#246;glichkeiten, um die Highscoreliste und die
 * Anleitung einzusehen.
 * 
 * Es stellt den zentralen Startpunkt der App dar.
 * 
 */
public class PCAct_Run extends Activity implements Runnable {

  private boolean scoreShown;
  private boolean aboutShown;

  private Thread logoThread;
  private LayoutSwitcher switcher;
  private boolean showIntroView;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    FileHandler.setAct(this);

    // StandartContentView aktiv
    scoreShown = false;
    aboutShown = false;

    super.onCreate(savedInstanceState);

    /*
     * Block initialisiert die Run View, je nach dem ob das erste Mal gestartet
     * wurde oder nicht.
     */
    {
      showIntroView = getIntent().getBooleanExtra(Constants.INTENT_FIRSTSTARTUP, true);

      if (showIntroView) {
        setContentView(ContentViewHandler.getIntroLayout());
        Handler handler = new Handler();
        switcher = new LayoutSwitcher(this, handler);
        logoThread = new Thread(switcher);
        logoThread.start();

      } else {
        setContentView(ContentViewHandler.getMainLayout());
      }
    }

    Log.v("PROJECTCUBE", "ONCREATE()");
  }

  @Override
  protected void onResume() {
    FileHandler.setAct(this);
    if (!scoreShown && !aboutShown && !showIntroView)
      setContentView(ContentViewHandler.getMainLayout());
    super.onResume();
  }

  /**
   * &#252;berschrieben um Sprache und Schriftart entsprechend zu
   * ver&#228;ndern.
   */
  @Override
  public void setContentView(int layoutResID) {
    LanguageChangeHelper.setLanguage(this, Options.getOptionsInstance().getLanguage());
    super.setContentView(layoutResID);

    if (layoutResID == ContentViewHandler.getMainLayout()) {
      FontChangeHelper.changeFonts(this, null, Options.getOptionsInstance(), (ViewGroup) findViewById(ContentViewHandler.getMainLayoutRootNode()), null);
      setListener();

    } else if (layoutResID == ContentViewHandler.getInfoLayout()) {
      FontChangeHelper.changeFonts(this, null, Options.getOptionsInstance(), (ViewGroup) findViewById(ContentViewHandler.getInfoLayoutRootNode()), null);
      setAboutListener();
    }
  }

  /**
   * Diese Methode &#252;berschreibt die Hardwaretasten des Smartphones.
   * 
   * @see android.app.Activity#onKeyDown(int, android.view.KeyEvent)
   * 
   */
  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    boolean success = false;

    if (keyCode == KeyEvent.KEYCODE_BACK) {
      if (!scoreShown && !aboutShown) {
        finish();
        onStop();
        success = true;

      } else if (aboutShown) {
        quitAbout();
        success = true;
      }

    } else if (keyCode == KeyEvent.KEYCODE_MENU) {
      if (!scoreShown && !aboutShown) {
        openOptions();
        success = true;

      } else if (aboutShown) {
        quitAbout();
        success = true;
      }
    }
    return success;
  }

  /**
   * Dient dem Darstellen des Titels in der ersten Sekunde des Programmes.
   */
  public void run() {
    if (showIntroView) {
      setContentView(ContentViewHandler.getIntroLayout());
      showIntroView = false;

    } else {
      setContentView(ContentViewHandler.getMainLayout());
      switcher.setRunning(false);

      try {
        logoThread.join();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }

  /******************************** Methoden, die von Listenern aufgerufen werden. ***********************************/

  /** Zeigt die Highscoreliste in einem Dialog an. */
  public void showHighscore() {
    DialogManager.showHighscore(this, Highscores.getInstance().getScores()).show();
  }

  /**
   * Erzeugt eine Game Activity. Diese bewirkt das Wechseln des Layouts zum
   * eigentlichen Spiel. Erzeugt einen neuen W&#252;rfel.
   */
  public void intentGame() {
    Intent game = new Intent(PCAct_Run.this, PCAct_Game.class);
    game.putExtra(Constants.INTENT_NEWGAME, true);
    game.putExtra(Constants.INTENT_TOURNAMENT, false);
    startActivity(game);
  }

  /**
   * Erzeugt eine GameActivity. Bewirkt das Wechseln des Layouts zum Spiel.
   * Versucht einen alten Spielstand zu laden. Ist keiner vorhanden, wird ein
   * neues Spiel aufgerufen.
   */
  public void loadGame() {
    if (new ModelFacade().loadGame(true)) {
      Intent game = new Intent(PCAct_Run.this, PCAct_Game.class);
      game.putExtra(Constants.INTENT_NEWGAME, false);
      game.putExtra(Constants.INTENT_TOURNAMENT, false);
      startActivity(game);

    } else {
      DialogManager.showNoSaveGameDialog(this).show();
    }
  }

  /**
   * Ruft das Spiel im Tournamentmode auf. Dieser bewirkt das Nichtspeichern
   * w&#228;hrend des Aufrufen des Men&#252;s und keine Hilfefunktion.
   */
  public void tournament() {
    Intent game = new Intent(PCAct_Run.this, PCAct_Game.class);
    game.putExtra(Constants.INTENT_NEWGAME, true);
    game.putExtra(Constants.INTENT_TOURNAMENT, true);
    startActivity(game);
  }

  /**
   * Erzeugt eine Optionsactivity. Bewirkt das Wechseln des Layouts zum
   * Optionenmen&#252;.
   */
  public void openOptions() {
    Intent options = new Intent(PCAct_Run.this, PCAct_Options.class);
    options.putExtra(Constants.INTENT_FROMRUN, true);
    startActivity(options);
  }

  /**
   * 
   */
  public void showAbout() {
    aboutShown = true;
    setContentView(ContentViewHandler.getInfoLayout());
  }

  /**
   * 
   */
  public void quitAbout() {
    aboutShown = false;
    setContentView(ContentViewHandler.getMainLayout());
  }

  /******************************************** private Methoden ****************************************************/

  /* Initialisert die Widgets und deren Listener f&#252;r das Hauptmen&#252;. */
  private void setListener() {

    // neues Spiel
    Button new_btn = (Button) findViewById(R.id.m_new);
    new_btn.setOnClickListener(new com.pc_controller.listener.run.NewGameClickListener(this));

    // altes Spiel Laden
    Button load_btn = (Button) findViewById(R.id.m_resume);
    load_btn.setOnClickListener(new com.pc_controller.listener.run.LoadClickListener(this));

    // Optionen
    ImageButton opt_btn = (ImageButton) findViewById(R.id.m_options);
    opt_btn.setOnClickListener(new com.pc_controller.listener.run.OptionsClickListener(this));

    // Wettbewerbsmodus
    Button tourn_btn = (Button) findViewById(R.id.m_tournament);
    tourn_btn.setOnClickListener(new com.pc_controller.listener.run.TournamentClickListener(this));

    // Highscore
    ImageButton highscore_btn = (ImageButton) findViewById(R.id.m_highscore);
    highscore_btn.setOnClickListener(new com.pc_controller.listener.run.HighscoreClickListener(this));

    // Aboutinfo
    ImageButton info_btn = (ImageButton) findViewById(R.id.m_info);
    info_btn.setOnClickListener(new com.pc_controller.listener.run.InfoClickListener(this));
  }

  /*
   * Hilfsmethode die die Actionlistener des Infomen&#252;s initialisiert.
   */
  private void setAboutListener() {
    ImageButton iB_kit = (ImageButton) findViewById(R.id.i_kit_logo);
    iB_kit.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        Uri uriUrl = Uri.parse(Constants.KIT_URL);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
      }
    });

    ImageButton iB_android = (ImageButton) findViewById(R.id.i_android_logo);
    iB_android.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        Uri uriUrl = Uri.parse(Constants.ANDROID_URL);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
      }
    });
  }
}