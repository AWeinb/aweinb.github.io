package com.pc_controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.pc_model.Options;
import com.pc_util.Constants;

import android.app.Activity;
import android.content.Context;

/**
 * Stellt eine Dateiverwaltungsschnittstelle bereit. Speichert den Standartpfad,
 * sodass andere Programmkomponenten nichts &#252;ber die Lage der Dateien auf der
 * Platte wissen m&#252;ssen.
 **/
public class FileHandler {

  /* Name der Spieldatei */
  private final static String LAST_GAME = "LAST_GAME";
  /* Name des letzten Protokolls*/
  private final static String LAST_PROTOCOL = "LAST_PROTOCOL";
  /* Name der Options-Datei */
  private final static String OPTIONS = "OPTIONS";
  /* Name der HighScores-Datei */
  private final static String HIGHSCORES_NAMES = "HIGHSCORES_NAMES";
  
  private final static String HIGHSCORES_MOVES = "HIGHSCORES_MOVES";
  
  private final static String HIGHSCORES_TIMES = "HIGHSCORES_TIMES";
  /* Allgemeiner Fehlerbegriff um Lesefehler zu kennzeichen */
  private final static String ERROR = "ERROR";
  /*
   * Errorstrings, Methodenname ist klein geschrieben.
   */

  private static final String FH_FNFEXC_loadString = "FileHandler: Daten nicht gefunden: ";
  private static final String FH_IOEXC_loadString = "FileHandler: Fehler beim Lesen von: ";
  private static final String FH_FNFEXC_saveString = "FileHandler: Fehler beim Erstellen von: ";
  private static final String FH_IOEXC_saveString = "FileHandler: Fehler beim Schreiben von: ";
  private static final String FH_NULEXC_loadString = "FileHandler: NullPointer beim Laden eines Strings";

  private static Activity currentAct;
  
  private FileHandler() {
  }
  

  public static void setAct(Activity act) {
    currentAct = act;
  }

  /**
   * Ruft den aktuellen Spielstand ab und speichert diesen als Dateien.
   * 
   */
  public static void saveGame(String cubeStatusString, String protocolString) {
	 
    saveString(LAST_GAME, cubeStatusString);
    saveString(LAST_PROTOCOL, protocolString);
  }

  /**
   * Laedt einen gespeichertes Spiel als String-Repaesentation aus dem internen
   * Speicher und gibt diese als 2-stelliges Array zurueck. Dabei enthaelt die
   * erste Stelle die String-Repraesentation des Wuerfels und die 2.Stelle die
   * des Protokolls. Ist kein Spiel vorhanden oder ist ein Fehler beim Laden
   * passiert, erhaelt man 2mal den String "NO_GAME".
   * 
   * @return gew&#252;nschten Spielstand, NO_GAME, wenn keines gefunden
   **/
  public static String[] loadGame() {
    String[] myData = new String[2];
    String theGame = loadString(LAST_GAME);
    String theProtocol = loadString(LAST_PROTOCOL);

    if (theGame.equals(ERROR) || theGame.equals(ERROR)) {
      myData[0] = "NO_GAME";
      myData[1] = "NO_GAME";

    } else {
      myData[0] = theGame;
      myData[1] = theProtocol;
    }

    return myData;
  }

  /** L&#246;scht den Inhalt aus der Bestenliste. */
  public static void resetHighscore() {
    storeHighScore(Constants.DUMMY);
  }

  /**
   * Laedt die aktuelle Bestenliste und speichert sie als String-Array. Wir
   * keine Bestenliste gefunden, so erhaelt man einen Dummy mit "MaxMustermann",
   * "999" und "99:99".
   * 
   * @return die aktuelle Bestenliste als String[][]. Dabei steht in score[0][0]
   *         der Spielername auf dem ersten Platz, in scores[0][1] dessen
   *         Zuganzahl und in scores[0][2] dessen Zeit. Bei Fehlen oder Fehler
   *         erhaelt man einen Dummy.
   **/
  public static String[][] loadHighScore() {
    String scoreDataNames = loadString(HIGHSCORES_NAMES);
    String scoreDataMoves = loadString(HIGHSCORES_MOVES);
    String scoreDataTimes = loadString(HIGHSCORES_TIMES);
    String[][] scores;

    if (scoreDataNames.equals(ERROR) || scoreDataMoves.equals(ERROR) || scoreDataTimes.equals(ERROR)) {
      scores = Constants.DUMMY;

    } else {

        String[] names = scoreDataNames.split(Constants.SEPARATOR);
        String[] moves = scoreDataMoves.split(Constants.SEPARATOR);
        String[] times = scoreDataTimes.split(Constants.SEPARATOR);

        if (names.length != moves.length || moves.length != times.length) {
          scores = Constants.DUMMY;

        } else {
          int length = names.length;
          scores = new String[length][3];

          for (int i = 0; i < length; i++) {
            scores[i][0] = names[i];
            scores[i][1] = moves[i];
            scores[i][2] = times[i];
          }
        }
    }
    
    return scores;
  }

  /**
   * Speichert die neue Bestenliste als Dateien im internen Speicher
   * 
   * @param scores
   *          die neue Bestenlsite
   */
  public static void storeHighScore(String[][] scores) {
    int numberOfPlayers = scores.length;
    StringBuilder names = new StringBuilder();
    StringBuilder moves = new StringBuilder();
    StringBuilder times = new StringBuilder();

    for (int i = 0; i < numberOfPlayers; i++) {
      if (i == numberOfPlayers - 1) {
        names.append(scores[i][0]);
        moves.append(scores[i][1]);
        times.append(scores[i][2]);

      } else {
        names.append(scores[i][0]);
        moves.append(scores[i][1]);
        times.append(scores[i][2]);

        names.append(Constants.SEPARATOR);
        moves.append(Constants.SEPARATOR);
        times.append(Constants.SEPARATOR);
      }
    }

    

    saveString(HIGHSCORES_NAMES, names.toString());
    saveString(HIGHSCORES_MOVES, moves.toString());
    saveString(HIGHSCORES_TIMES, times.toString());
  }

  /**
   * Greift auf das aktuelle Options-Objekt zu und speichert die aktuellen
   * Optionen in eine Datei.
   **/
  public static void storeOptions(Options o) {
    saveString(OPTIONS, optionsToString(o));
  }

  /**
   * L&#228;dt die Optionen aus der Optionendatei und speichert sie in das
   * Options-Objekt. Erstellt automatisch eine Options-Datei basierend auf den
   * in der Constants gegebenen Konstanten.
   **/
  public static String[] loadOptions() {
    String opt = loadString(OPTIONS);
    String[] ret;

    if (opt.equals(ERROR)) {
      ret = null;

    } else {
      ret = opt.split(Constants.SEPARATOR);
    }
     return ret;
  }

  // ##### ##### #### #### ### ### ### ## # PRIVATE # ## ### ### ### #### ####

  /*
   * Laedt einen gespeicherten String aus dem internen Speicher Ist kein String
   * vorhanden oder ist ein Fehler beim Laden passiert, erhaelt man den String
   * "ERROR".
   * 
   * @return gew&#252;nschten String, ERROR, wenn keiner gefunden
   */
  private static String loadString(String fileName) {
    String output = "";
    StringBuilder sb = new StringBuilder();

    try {
      FileInputStream fis = currentAct.openFileInput(fileName);
      byte[] buffer = new byte[1];

      while (fis.read(buffer) != -1) {
        sb.append(new String(buffer));
      }

      fis.close();
      output = sb.toString();

    } catch (FileNotFoundException e) {
      output = ERROR;
      System.out.println(FH_FNFEXC_loadString + fileName);

    } catch (IOException e) {
      output = ERROR;
      System.out.println(FH_IOEXC_loadString + fileName);
    } catch (NullPointerException e) {
    	output = ERROR;
    	System.out.println(FH_NULEXC_loadString);
    }

    return output;
  }

  /* Speichert einen String im internen Speicher */
  private static void saveString(String fileName, String content) {
    try {
      FileOutputStream fos = currentAct.openFileOutput(fileName, Context.MODE_PRIVATE);
      fos.write(content.getBytes());
      fos.close();

    } catch (FileNotFoundException e) {
      System.out.println(FH_FNFEXC_saveString + fileName);

    } catch (IOException e) {
      System.out.println(FH_IOEXC_saveString + fileName);
    } catch (NullPointerException e) {
    	System.out.println(FH_NULEXC_loadString);
    }
  }

  /*
   * konvertiert eine Options-Instanz in einen handlichen String
   * <size>#<animspeed>#<NumOfMoves>#(6mal colourwert)#<sound>#<language>
   */
  private static String optionsToString(Options o) {
    StringBuilder sb = new StringBuilder();

    sb.append(o.getCubeSize());
    sb.append(Constants.SEPARATOR);

    sb.append(o.getAnimationSpeed());
    sb.append(Constants.SEPARATOR);

    sb.append(o.getNumberOfMoves());
    sb.append(Constants.SEPARATOR);

    for (int i = 0; i < 6; i++) {
      sb.append(o.getColour(i));
      sb.append(Constants.SEPARATOR);
    }

    sb.append(o.getLanguage());
    sb.append(Constants.SEPARATOR);
    
    sb.append(o.getTheme());
    sb.append(Constants.SEPARATOR);

    sb.append(o.getFilter());
    sb.append(Constants.SEPARATOR);
    
    sb.append(o.getActFont());
    return sb.toString();
  }
}
