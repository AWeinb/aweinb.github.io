package com.pc_controller;

import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;

import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;

/**
 * �bersetzt eine Bewegung auf dem Display in einen Spielzug.
 * 
 * @author deathbot125
 */
public class ColorOGLMovementTranslator extends MovementTranslator {

  private PCAct_Game lnkPcAct_Game;
  /*
   * Bewegungsliste, speichert alle y-Werte der letzten Bewegung auf dem Touchscreen.
   */
  private List<Integer> lastYCoord;
  private static int width, height;
  private static ByteBuffer cubeAt;

  /*
   * Bewegungsliste, speichert alle x-Werte der letzten Bewegung auf dem Touchscreen.
   */
  private List<Integer> lastXCoord;

  /**
   * beschreibt die Position des angeklickten Feldes. Stelle 0 gibt die Seite an, Stelle 1 die Zeile und Stelle 2 die
   * Spalte.
   * */
  private int[] pos;

  /**
   * @param lnkPcAct_Game
   *          Verweis auf das aufrufende Objekt von PcAct_Game.
   */
  public ColorOGLMovementTranslator(PCAct_Game lnkPcAct_Game) {
    super(lnkPcAct_Game);
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Setzt die Matrix nach der ich die Position auf dem Wuerfel auslesen kann.
   * 
   * @param cubeByte
   *          Beinhalet die Farbwerte der Matrix.
   * 
   * */
  public static void setCubeAt(ByteBuffer cubeByte) {
    cubeAt = cubeByte;
  }

  /**
   * setzt die Displaygr��e.
   * 
   * @param size
   *          Displaygr��e
   **/
  public static void setDisplaySize(int[] size) {
    width = size[0];
    height = size[1];
  }

  /*
   * rechnet aus einem Farbwert die Zeile und Spalte aus.
   */
  private void setCollumnAndRow(int a) {
    if (a < 0) {
      a = 256 + a;
    }
    if (a == 0) {

    } else if (a < 40) {
      pos[1] = 0;
      pos[2] = 0;
    } else if (a < 60) {
      pos[1] = 0;
      pos[2] = 1;
    } else if (a < 90) {
      pos[1] = 0;
      pos[2] = 2;
    } else if (a < 115) {
      pos[1] = 1;
      pos[2] = 0;
    } else if (a < 140) {
      pos[1] = 1;
      pos[2] = 1;
    } else if (a < 165) {
      pos[1] = 1;
      pos[2] = 2;
    } else if (a < 190) {
      pos[1] = 2;
      pos[2] = 0;
    } else if (a < 210) {
      pos[1] = 2;
      pos[2] = 1;
    } else if (a < 255) {
      pos[1] = 2;
      pos[2] = 2;
    }
  }

  /**
   * {@inheritDoc}
   * */
  @Override
  public void startNewMove(int x, int y) {
    pos = new int[3];
    byte[] val = new byte[4];
    int glY = height - y;
    if (0 <= x && x < width && 0 <= glY && glY < height) {
      cubeAt.position((glY * width + x) * 4);
      cubeAt.get(val);
      // We get RGBA Tuples, Range is 0-255, since Javas "byte" type is signed, 255 corresponds to -1
      if (val[0] != 0 && val[1] == 0 && val[2] == 0) {
        // left
        pos[0] = 1;
        setCollumnAndRow(val[0]);

      } else if (val[0] == 0 && val[1] != 0 && val[2] == 0) {
        // Front
        pos[0] = 2;
        setCollumnAndRow(val[1]);

      } else if (val[0] == 0 && val[1] == 0 && val[2] != 0) {
        // top
        pos[0] = 3;
        setCollumnAndRow(val[2]);
      } else {
        System.out.println("out of Cube");
      }
    }
    lastYCoord = new LinkedList<Integer>();
    lastXCoord = new LinkedList<Integer>();
    lastYCoord.add(y);
    lastXCoord.add(x);
  }

  /**
   * {@inheritDoc}
   * */
  @Override
  public void addToMovement(int x, int y) {
    lastYCoord.add(y);
    lastXCoord.add(x);
  }

  
  /*
   * Analysiert und erkennt, welche Bewegung auf dem Wuerfel gemacht wurde und erstellt ein Turn-Objekt.
   */
  /**
   * {@inheritDoc}
   * 
   * */
  @Override
  public void finishMovement() {
    TurnType t = null;
    if (lastXCoord.size() == lastYCoord.size()) {
      /*
       * delta X um die Bewegung in x Richtung zu analysieren.
       */
      double dx = lastXCoord.get(lastXCoord.size() - 1) - lastXCoord.get(0);
      /*
       * delta Y um die Bewegung in y Richtung zu analysieren.
       */
      double dy = lastYCoord.get(lastYCoord.size() - 1) - lastYCoord.get(0);
      if (dx > 25 || dy > 25||dx < -25 || dy < -25) {

        double turnedDX, turnedDY;
        switch (pos[0]) {
        case 0:
          System.out.println("keine g�ltige Startposition");
          break;
        /* Left drehen */
        case 1:
          turnedDY = dy / 0.7;
          turnedDX = dx * 0.7;
          if (turnedDX > 0 && turnedDX > Math.abs(turnedDY)) {
            // zeile nah rechts
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.UPRIME;
              break;
            case 1:
              t = Constants.TurnType.E;
              break;
            case 2:
              t = Constants.TurnType.D;
              break;
            }
          } else if (turnedDX < 0 && (-turnedDX) > Math.abs(dy)) {
            // Zeile nach links
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.U;
              break;
            case 1:
              t = Constants.TurnType.EPRIME;
              break;
            case 2:
              t = Constants.TurnType.DPRIME;
              break;
            }

          } else if (turnedDY > 0) {
            // Spalte nach oben
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.B;
              break;
            case 1:
              t = Constants.TurnType.SPRIME;
              break;
            case 2:
              t = Constants.TurnType.FPRIME;
              break;
            }
          } else {
            // Spalte nach unten
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.BPRIME;
              break;
            case 1:
              t = Constants.TurnType.S;
              break;
            case 2:
              t = Constants.TurnType.F;
              break;
            }
          }
          break;
        /* Center drehen */
        case 2:
          turnedDY = dy * 0.7;
          turnedDX = dx / 0.7;
          if (turnedDX > 0 && turnedDX > Math.abs(turnedDY)) {
            // zeile nah rechts
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.UPRIME;
              break;
            case 1:
              t = Constants.TurnType.E;
              break;
            case 2:
              t = Constants.TurnType.D;
              break;
            }
          } else if (turnedDX < 0 && (-turnedDX) > Math.abs(dy)) {
            // Zeile nach links
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.U;
              break;
            case 1:
              t = Constants.TurnType.EPRIME;
              break;
            case 2:
              t = Constants.TurnType.DPRIME;
              break;
            }
          } else if (turnedDY > 0) {
            // Spalte nach oben
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.L;
              break;
            case 1:
              t = Constants.TurnType.M;
              break;
            case 2:
              t = Constants.TurnType.RPRIME;
              break;
            }
          } else {
            // Spalte nach unten
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.LPRIME;
              break;
            case 1:
              t = Constants.TurnType.MPRIME;
              break;
            case 2:
              t = Constants.TurnType.R;
              break;
            }
          }
          break;
        /* Top drehen */
        case 3:
          turnedDY = dy;
          turnedDX = dx;
          if (turnedDX > 0 && turnedDY < 0) {
            // zeile nah rechts
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.BPRIME;
              break;
            case 1:
              t = Constants.TurnType.S;
              break;
            case 2:
              t = Constants.TurnType.F;
              break;
            }
          } else if (turnedDX < 0 && turnedDY > 0) {
            // Zeile nach links
            switch (pos[1]) {
            case 0:
              t = Constants.TurnType.B;
              break;
            case 1:
              t = Constants.TurnType.SPRIME;
              break;
            case 2:
              t = Constants.TurnType.FPRIME;
              break;
            }
          } else if (turnedDX > 0 && turnedDY > 0) {
            // Spalte nach oben
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.L;
              break;
            case 1:
              t = Constants.TurnType.M;
              break;
            case 2:
              t = Constants.TurnType.RPRIME;
              break;
            }
          } else {
            // Spalte nach unten
            switch (pos[2]) {
            case 0:
              t = Constants.TurnType.LPRIME;
              break;
            case 1:
              t = Constants.TurnType.MPRIME;
              break;
            case 2:
              t = Constants.TurnType.R;
              break;
            }
          }
          break;
        }
      }
      if (t != null) {
        lnkPcAct_Game.manageTurn(t);
      }

    }
  }

}
