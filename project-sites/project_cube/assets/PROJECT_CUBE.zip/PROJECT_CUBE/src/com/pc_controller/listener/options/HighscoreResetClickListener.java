package com.pc_controller.listener.options;

import android.view.View;
import com.pc_controller.PCAct_Options;

/**
 * Beobachtet einen Button, der die Highscores zuruecksetzt..
 * */
public class HighscoreResetClickListener implements View.OnClickListener {

  /* Verweis auf das Objekt von pcActRun, das den Listener registriert hat. */
  private PCAct_Options lnkPcAct_Options;

  /**
   * Konstruktor. Muss einen Verweis auf die aufrufende Activity enthalten.
   * 
   * @param lnkPcAct_Options
   */
  public HighscoreResetClickListener(PCAct_Options lnkPcAct_Options) {
    this.lnkPcAct_Options = lnkPcAct_Options;
  }

  /**
   * Setzt die Highscores zurueck.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Options.resetHighscore();
  }
}
