package com.pc_controller.listener.game;

import com.pc_controller.PCAct_Game;

import android.view.View;
import android.view.View.OnClickListener;

/**
 * Diese Klasse implementiert einen OnClickListener. Er hoert den "Redo"-Button ab und veranlasst im Fall eines Klicks
 * das Wiederherstellen des letzten Wuerfelzugs..
 */
public class RedoClickListener implements OnClickListener {

  private PCAct_Game lnk;

  /**
   * Erstellt einen OnClickListener, der den "Redo"-Button abhoert und im Fall eines Klicks den letzten Wuerfelzug
   * wiederherstellt.
   * 
   * @param die
   *          aufrufende Activity
   */
  public RedoClickListener(PCAct_Game lnk) {
    this.lnk = lnk;
  }

  /**
   * Wird aufgerufen, wenn der "Redo"-Button gedrueckt wurde. Veranlasst das Wiederherstellen des letzten Wuerfelzugs.
   * 
   * @param v
   *          das Viewelement, das geklickt wurde.
   */
  public void onClick(View v) {
    lnk.redo();

  }

}
