package com.pc_controller.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.pc_controller.R;
import com.pc_model.Options;
import com.pc_util.Constants;
import com.pc_util.FontChangeHelper;
import com.pc_view.ContentViewHandler;

/**
 * Diese Klasse erstellt einen Dialog, der entsprechenden Beduerfnissen
 * angepasst wurde.
 * 
 * @author AxP
 * 
 */
public class CustomDialog extends Dialog {

  /*
   * Der Konstruktor des Dialogs.
   */
  private CustomDialog(Context context, int theme) {
    super(context, theme);
  }

  /**
   * Innere Klasse konfiguriert den Dialog. Ohne irgendeinen Aufruf einer dieser
   * Funktion macht der Dialog nicht viel Eindruck.
   * 
   * @author AxP
   * 
   */
  public static class Builder {

    private Activity context;
    private int titleId;
    private int maintextId;
    private String maintext;
    private boolean inputNameEnabled;
    private boolean inputNumberEnabled;
    private String inputText;
    private View.OnClickListener btn1Listener;
    private View.OnClickListener btn2Listener;
    private View.OnClickListener btn3Listener;
    private int btn1Name;
    private int btn2Name;
    private int btn3Name;
    private CustomDialog dialog;
    private String[][] tableEntries;

    /**
     * Builder Konstruktor. Ben�tigt eine Activity/ einen Kontext.
     * 
     * @param context Activity
     */
    public Builder(Activity context) {
      this.context = context;
      this.dialog = new CustomDialog(context, R.style.Dialog);

      titleId = 0;
      maintextId = 0;
      maintext = null;
      inputNameEnabled = false;
      inputNumberEnabled = false;
      inputText = null;
      btn1Listener = null;
      btn2Listener = null;
      btn3Listener = null;
      btn1Name = 0;
      btn2Name = 0;
      btn3Name = 0;
      tableEntries = null;
    }

    /**
     * Gibt den Dialog zurueck der zurzeit erstellt wird um auf bestimmte Views des Layouts zuzugreifen.
     * 
     * @return Aktuelle Dialog
     */
    public CustomDialog getDialog() {
      return dialog;
    }

    /**
     * Setzt den Titel.
     * 
     * @param title Id
     */
    public void setTitle(int title) {
      this.titleId = title;
    }

    /**
     * Setzt den Haupttext.
     * 
     * @param text Id
     */
    public void setMainText(int text) {
      this.maintextId = text;
    }

    /**
     * Setzt den Haupttext.
     * 
     * @param string String
     */
    public void setMainText(String string) {
      this.maintext = string;
    }

    /**
     * Texteingabe aktivieren.
     * 
     * @param inputEnabled 
     */
    public void enableNameInput(boolean inputEnabled) {
      this.inputNameEnabled = inputEnabled;
    }

    /**
     * Nummerneingabe aktivieren.
     * 
     * @param inputEnabled
     * @param text Anfangstext
     */
    public void enableNumberInput(boolean inputEnabled, String text) {
      this.inputNumberEnabled = inputEnabled;
      this.inputText = text + " ";
    }

    /**
     * Uebergibt Tabelleneintraege als String Array.
     * 
     * @param entries Die Eintraege
     */
    public void withTable(String[][] entries) {
      this.tableEntries = entries;
    }

    /**
     * Initialisiert einen Button mit Beschriftung und Listener.
     * 
     * @param name Id
     * @param listener
     */
    public void setBtn1(int name, View.OnClickListener listener) {
      this.btn1Listener = listener;
      this.btn1Name = name;
    }

    /**
     * Initialisiert einen Button mit Beschriftung und Listener.
     * 
     * @param name Id
     * @param listener
     */
    public void setBtn2(int name, View.OnClickListener listener) {
      this.btn2Listener = listener;
      this.btn2Name = name;
    }

    /**
     * Initialisiert einen Button mit Beschriftung und Listener.
     * 
     * @param name Id
     * @param listener
     */
    public void setBtn3(int name, View.OnClickListener listener) {
      this.btn3Listener = listener;
      this.btn3Name = name;
    }

    /**
     * Macht den Dialog abbrechbar.
     * 
     * @param cancelable
     */
    public void setCancelable(boolean cancelable) {
      dialog.setCancelable(cancelable);
    }

    /**
     * Erstellt den Dialog mit vorher getroffenen Einstellungen.
     * 
     * @return Der Dialog
     */
    public CustomDialog create() {
      LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      View layout = inflater.inflate(ContentViewHandler.getDialogLayout(), null);

      dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));

      // Titel
      TextView title = (TextView) layout.findViewById(R.id.dialog_title);
      if (titleId != 0) {
        title.setText(titleId);

      } else {
        title.setVisibility(View.GONE);
      }

      // Eingabefeld
      EditText inputbox;
      if (!inputNameEnabled) {
        inputbox = (EditText) layout.findViewById(R.id.dialog_inputname);
        inputbox.setVisibility(View.GONE);
      }

      // Eingabefeld
      inputbox = (EditText) layout.findViewById(R.id.dialog_inputnumber);
      if (inputNumberEnabled) {
        inputbox.setText(inputText);

      } else {
        inputbox.setVisibility(View.GONE);
      }

      // Tabelle
      boolean scoreEmpty = false;
      TableLayout table = (TableLayout) layout.findViewById(R.id.dialog_table);
      if (tableEntries != null && tableEntries[0] != null && !(tableEntries[0][0].trim()).equals(Constants.DUMMY[0][0].trim())) {
        table.setStretchAllColumns(true);
        table.setShrinkAllColumns(true);

        for (int col = 0; col < tableEntries.length; col++) {
          TableRow tableRow = new TableRow(context);

          TextView tv = new TextView(context);
          tv.setText("" + (col + 1));
          tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
          tv.setGravity(Gravity.CENTER_HORIZONTAL);
          tableRow.addView(tv);

          for (int row = 0; row < tableEntries[0].length; row++) {
            tv = new TextView(context);

            if (row == 2) {
              long time;

              try {
                time = Long.parseLong(tableEntries[col][row]);

              } catch (NumberFormatException e) {
                time = 0;
                e.printStackTrace();
              }

              long milliseconds = time;
              milliseconds /= 1000;
              byte sec = (byte) (milliseconds % 60);
              milliseconds /= 60;
              byte min = (byte) (milliseconds % 60);
              milliseconds /= 60;
              byte h = (byte) (milliseconds % 24);
              milliseconds /= 24;
              int d = (int) milliseconds;

              tv.setText((String) (d != 0 ? d + " d:" : "") + h + ":" + min + ":" + sec + " ");

            } else {
              tv.setText("" + tableEntries[col][row]);
            }

            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tv.setGravity(Gravity.CENTER_HORIZONTAL);
            tableRow.addView(tv);
          }

          table.addView(tableRow);
        }

      } else {
        ((TableLayout) layout.findViewById(R.id.dialog_table)).setVisibility(View.GONE);
        ((TextView) layout.findViewById(R.id.dialog_maintext)).setText(R.string.m_highscore_empty);
        scoreEmpty = true;
      }

      // Text
      TextView maintextfield = ((TextView) layout.findViewById(R.id.dialog_maintext));
      if (maintextId != 0) {
        maintextfield.setText(maintextId);

      } else if (maintext != null) {
        maintextfield.setText(maintext);

      } else {
        if (!scoreEmpty)
          maintextfield.setVisibility(View.GONE);
      }

      // Button 1
      Button Btn1 = (Button) layout.findViewById(R.id.dialog_ButtonLeft);
      if (btn1Listener != null && btn1Name != 0) {
        Btn1.setOnClickListener(btn1Listener);
        Btn1.setText(btn1Name);

      } else {
        Btn1.setVisibility(View.GONE);
      }

      // Button 2
      Button Btn2 = (Button) layout.findViewById(R.id.dialog_ButtonMid);
      if (btn2Listener != null && btn2Name != 0) {
        Btn2.setOnClickListener(btn2Listener);
        Btn2.setText(btn2Name);

      } else {
        Btn2.setVisibility(View.GONE);
      }

      // Button 3
      Button Btn3 = (Button) layout.findViewById(R.id.dialog_ButtonRight);
      if (btn3Listener != null && btn3Name != 0) {
        Btn3.setOnClickListener(btn3Listener);
        Btn3.setText(btn3Name);

      } else {
        Btn3.setVisibility(View.GONE);
      }

      dialog.setContentView(layout);

      FontChangeHelper.changeFonts(context, null, Options.getOptionsInstance(), (ViewGroup) layout.findViewById(R.id.dialog_root), null);

      return dialog;
    }
  }
}