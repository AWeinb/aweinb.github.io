package com.pc_controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Intent;
import android.gesture.GestureOverlayView;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.TextView;

import com.pc_controller.listener.game.CubeKeyListener;
import com.pc_controller.listener.game.CubeRotListener;
import com.pc_controller.listener.game.CubeTouchListener;
import com.pc_controller.listener.game.RedoClickListener;
import com.pc_controller.listener.game.UndoClickListener;
import com.pc_controller.listener.help.ResumeClickListener;
import com.pc_controller.listener.help.SolveAllClickListener;
import com.pc_controller.listener.help.StopClickListener;
import com.pc_controller.listener.pause.BackClickListener;
import com.pc_controller.listener.pause.MainMenuClickListener;
import com.pc_controller.listener.pause.NewCubeClickListener;
import com.pc_controller.listener.pause.OptionsClickListener;
import com.pc_controller.listener.pause.PHelpClickListener;
import com.pc_model.Cube;
import com.pc_model.GameProtocol;
import com.pc_model.Highscores;
import com.pc_model.ModelFacade;
import com.pc_model.Options;
import com.pc_model.Turn;
import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;
import com.pc_util.FontChangeHelper;
import com.pc_util.LanguageChangeHelper;
import com.pc_util.Randomizer;
import com.pc_util.SimpleRandomizer;
import com.pc_util.Solver;
import com.pc_view.ContentViewHandler;
import com.pc_view.ModelObserver;
import com.pc_view.openGL.MainCube_gl;

/**
 * Klasse um das Spiel zu verwalten. Stellt die zentrale Steuerungseinheit f&#252;r den Spielablauf dar. Steuert das
 * Erstellen eines neuen Spiels; verwaltet die Z&#252;ge und den Solver.
 * 
 * */
public class PCAct_Game extends android.app.Activity {

  /* Verweis auf den im Spiel verwendeten W&#252;rfel */
  private ModelFacade facade;
  private static GLSurfaceView glSurface;
  private Chronometer cronmtr;

  /* Zeigt an, ob das aktuelle Spiel im Tournament Mode gespielt wird. */
  private boolean tournament = false;

  // Booleans merken welche Sicht aktiv ist.
  private boolean gameShown;
  private boolean helpShown;
  private boolean pauseShown;

  // Verstrichene Millis
  private long elapsedTime = 0;

  // Timer an/aus
  private boolean timerStopped = true;
  private boolean without = false;

  // Fehler Timer
  private static final String TIMER_STOP_ERROR = "Timer Stop: View ist null!";
  private static final String TIMER_START_ERROR = "Timer Start: View ist null!";

  /**
   * Klasse erstellt ein neues Spiel und initialisiert den W&#252;rfel, je nach dem ob geladen oder neu gestartet wird.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    boolean newGame = getIntent().getBooleanExtra(Constants.INTENT_NEWGAME, true);
    boolean fromOptions = getIntent().getBooleanExtra(Constants.INTENT_FROM_OPTIONS, false);
    tournament = getIntent().getBooleanExtra(Constants.INTENT_TOURNAMENT, false);

    FileHandler.setAct(this);
    this.facade = new ModelFacade();

    if (!newGame || fromOptions) {
      loadGame(fromOptions);

    } else {
      newGame();
    }
  }

  @Override
  public void onResume() {
    FileHandler.setAct(this);
    // Wenn true wird NO_GAME gespeichert, bis wieder auf false gesetzt wurde.
    facade.clear(false);

    if (pauseShown) {
      setContentView(ContentViewHandler.getPauseMenuLayout());
    }

    super.onResume();
  }

  @Override
  public void onPause() {
    if (!without)
      facade.saveGame();
    super.onPause();
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    MainCube_gl.destroyRenderer();
  }

  @Override
  public void onLowMemory() {
    MainCube_gl.destroyRenderer();
    facade.saveGame();
    super.onLowMemory();
  }

  /**
   * &#252;berschrieben um Sprache und Schriftart entsprechend zu ver&#228;ndern.
   */
  @Override
  public void setContentView(int layoutResID) {
    LanguageChangeHelper.setLanguage(this, Options.getOptionsInstance().getLanguage());
    super.setContentView(layoutResID);

    if (layoutResID == ContentViewHandler.getPauseMenuLayout()) {
      FontChangeHelper.changeFonts(this, null, Options.getOptionsInstance(),
          (ViewGroup) findViewById(ContentViewHandler.getPauseMenuLayoutRootNode()), null);
      setPauseListener();
      stopTimer();

    } else if (layoutResID == ContentViewHandler.getGameLayout()) {
      FontChangeHelper.changeFonts(this, null, Options.getOptionsInstance(),
          (ViewGroup) findViewById(ContentViewHandler.getGameLayoutRootNode()), null);

    } else if (layoutResID == ContentViewHandler.getHelpScreenLayout()) {
      FontChangeHelper.changeFonts(this, null, Options.getOptionsInstance(),
          (ViewGroup) findViewById(ContentViewHandler.getHelpScreenLayoutRootNode()), null);
    }
  }

  /**
   * F&#252;hrt einen Zug auf dem W&#252;rfel aus.
   * 
   * @param turn
   *          Der Zug, der ausgef&#252;hrt werden soll.
   */

  public void applyTurn(TurnType turn) {
    facade.applyTurn(turn);

    if (facade.cubeIsSolved()) {
      stopTimer();
      Highscores h = Highscores.getInstance();

      if (h.check(elapsedTime, facade.getCount())) {
        DialogManager.showWinnerDialog(this).show();
      }
    }
  }

  /**
   * F&#252;hrt einen animierten Zug auf dem W&#252;rfel aus.
   * 
   * @param turn
   */
  public void manageTurn(TurnType turn) {
    TextView counter = (TextView) findViewById(R.id.g_counter);

    // nicht gesetzt in Hilfeansicht!
    if (counter != null) {
      counter.setText(getString(R.string.g_count) + " " + Integer.toString(GameProtocol.getCounter() + 1));
    }

    facade.manageTurn(new Turn(turn));
    if (facade.cubeIsSolved()) {
      stopTimer();

      if (tournament) {
        DialogManager.showScore(facade.getCount(), elapsedTime, this).show();

      } else {
        Highscores h = Highscores.getInstance();
        // Eintrag in Highscores nur, wenn Hilfe nicht benutzt wurde und Zuege
        // und Zeit klein genug sind

        if (!facade.getHelpFunctionUsed() && h.check(elapsedTime, facade.getCount())) {
          DialogManager.showWinnerDialog(this).show();
        }
      }

    }
  }

  /************************ Methoden, die von Listenern aufgerufen werden *********************************************/

  /** Speichert das Spiel und kehrt zum Hauptmen&#252; zur&#252;ck. */
  public void changeToRunActivity() {
    facade.saveGame();

    {
      Intent run = new Intent(PCAct_Game.this, PCAct_Run.class);
      run.putExtra(Constants.INTENT_FIRSTSTARTUP, false);
      startActivity(run);
    }
    onStop();
    finish();
  }

  /** Speichert das Spiel und ruft das Optionenmen&#252; auf. */
  public void changeToOptionsActivity() {
    facade.saveGame();

    {
      Intent options = new Intent(PCAct_Game.this, PCAct_Options.class);
      options.putExtra(Constants.INTENT_FROMRUN, false);
      options.putExtra(Constants.INTENT_TOURNAMENT, this.tournament);
      startActivity(options);
    }
  }

  /**
   * Erstellt ein neues Spiel, d.h. ein neues Model und eine neue View. Ruft dann einen Dialog auf, in dem dem Spieler
   * optional die M&#246;glichkeit gegeben wird einen Key einzugeben und dann das Spiel zu starten.
   */
  public void newGame() {
    // initialisiere Model, neues Spiel
    facade.newGame();
    initializeGameView();
    DialogManager.showKeyDialog(this).show();
  }

  /**
   * L&#228;dt einen alten Spielstand, falls vorhanden.
   * 
   * @param fromOptions Von Optionen aufgerufen
   * 
   * @return true, falls der alte Spielstand erfolgreich geladen wurde.
   */
  public boolean loadGame(boolean fromOptions) {
    boolean loaded = false;
    // initialisiere Model, neues Spiel
    loaded = facade.loadGame(false);

    if (loaded) {
      if (!fromOptions) {
        initializeGameView();
        startTimer();

      } else {
        showPauseMenu();
        Log.v("PROJECTCUBE", "Intent mit FROMOPTIONS true");
      }
    } else {
      quitWithoutSave();
    }

    return loaded;
  }

  /**
   * Falls Renderer null sein sollte.
   */
  public static void requestRendererUpdate() {
    try {
      if (glSurface != null)
        glSurface.setRenderer(MainCube_gl.getRenderer(glSurface, Options.getOptionsInstance().getFilter()));

    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  /** Zeigt das Pausenmenue an. */
  public void showPauseMenu() {
    this.pauseShown = true;
    this.gameShown = false;
    this.helpShown = false;

    setContentView(ContentViewHandler.getPauseMenuLayout());
    facade.saveGame();
  }

  /** Wechselt die Ansicht vom Pausenmen&#252; zur&#252;ck zum Spiel. */
  public void hidePauseMenu() {
    initializeGameView();
    startTimer();
  }

  /** Zeigt den Hilfebildschirm an */
  public void showSolver() {
    if (facade.getCubeSize() != 3) {
      DialogManager.showNoSolverDialog(this).show();

    } else {
      initializeHelpView();
    }
  }

  /** Beendet ohne speichern */
  public void quitWithoutSave() {
    without = true;
    Intent run = new Intent(PCAct_Game.this, PCAct_Run.class);
    run.putExtra(Constants.INTENT_FIRSTSTARTUP, false);
    finish();
    startActivity(run);
  }

  /** Beendet mit Speicherreset */
  public void quitWithSaveReset() {
    facade.clear(true);
    facade.saveGame();

    Intent run = new Intent(PCAct_Game.this, PCAct_Run.class);
    run.putExtra(Constants.INTENT_FIRSTSTARTUP, false);
    finish();
    startActivity(run);
  }

  /**
   * Erstellt eine W&#252;rfelkopie und l&#228;sst den L&#246;sungsalgorithmus darauf eine g&#252;ltige Zugfolge
   * berechnen, die zur vollst&#228;ndigen L&#246;sung des W&#252;rfels f&#252;hrt. F&#252;hrt die L&#246;sung dann auf
   * dem echten W&#252;rfel aus. Ist f&#252;r die aktuelle W&#252;rfelgr&#246;&#223;e kein L&#246;sungsalgorithmus
   * vorhanden, wird ein entsprechender Dialog angezeigt.
   */
  public void startSolver(boolean solveAll) {
    int count = 0;
    boolean stop = false;

    ArrayList<Turn> solution = new ArrayList<Turn>();
    Cube cubecopy = facade.cloneCube();

    solution = Solver.solveNextStep(cubecopy);

    /*
     * forschleife laeuft durch, solange noch Turns in der Liste sind UND der Pause-button nicht gedrueckt wurde.
     */
    if (solution != null) {
      for (Iterator<Turn> i = solution.iterator(); i.hasNext();) {
        Turn turn = i.next();
        facade.manageTurn(turn);
        count++;
      }
    }

    if (facade.cubeIsSolved()) {
      stop = true;
      
      facade.clear(true);
      DialogManager.showSolverEndedDialog(this).show();
    }
    
    if (solveAll && count > 0 && !stop) {
      startSolver(true);
    }
  }

  /**
   * Beendet die automatische W&#252;rfell&#246;sung, schliesst den Hilfe-Modus und kehrt zum normalen Spiellayout
   * zur&#252;ck.
   */
  public void stopSolver() { // Das Loesen des Wuerfels sollte
                             // angehalten werden.
    initializeGameView();
    cronmtr = (Chronometer) findViewById(R.id.g_timer);
    long additionalMillis = facade.getElapsedTime();
    cronmtr.setBase(SystemClock.elapsedRealtime() - additionalMillis);
  }

  /**
   * Wiederholt den letzten r&#252;ckg&#228;ngig gemachten Turn, so einer existiert.
   */
  public void redo() {
    facade.redo();
  }

  /**
   * Macht den zuletzt ausgef&#252;hrten Turn r&#252;ckg&#228;ngig, so einer existiert.
   */
  public void undo() {
    facade.undo();
  }

  /********************** private Methoden ****************************************************************************/

  /*
   * Initialisiert das GameLayout und die dazugeh&#246;rigen View-Komponenten und Listener.
   */
  private void initializeGameView() {
    this.pauseShown = false;
    this.gameShown = true;
    this.helpShown = false;

    setContentView(ContentViewHandler.getGameLayout());

    // initialisiere sichtbaren Wuerfel (View) mit Listenern
    glSurface = (GLSurfaceView) findViewById(R.id.g_glSurfaceView);
    glSurface.setRenderer(MainCube_gl.getRenderer(glSurface, Options.getOptionsInstance().getFilter()));
    glSurface.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

    MovementTranslator mt = new ColorOGLMovementTranslator(this);
    CubeTouchListener tl = new CubeTouchListener(mt);
    glSurface.setOnTouchListener(tl);
    glSurface.setOnKeyListener(new CubeKeyListener(this));
    glSurface.setFocusable(true);
    glSurface.setFocusableInTouchMode(true);
    facade.addListener(new ModelObserver());

    ((TextView) findViewById(R.id.g_counter)).setText(getString(R.string.g_count) + " "
        + Integer.toString(GameProtocol.getCounter()));

    // initialisiere Buttons undo, redo, menu
    setListener();
  }

  /*
   * Initialisert das Layout f&#252;r den Hilfe-Modus und die dazugeh&#246;rigen View-Komponenten und Listener.
   */
  private void initializeHelpView() {
    this.pauseShown = false;
    this.gameShown = false;
    this.helpShown = true;

    setContentView(ContentViewHandler.getHelpScreenLayout());

    Button solveAll = (Button) findViewById(R.id.g_h_solveAll);
    solveAll.setOnClickListener(new SolveAllClickListener(this));

    ImageButton stop = (ImageButton) findViewById(R.id.g_h_stop);
    stop.setOnClickListener(new StopClickListener(this));

    Button next = (Button) findViewById(R.id.g_h_resume);
    next.setOnClickListener(new ResumeClickListener(this));

    GLSurfaceView glSurface = (GLSurfaceView) findViewById(R.id.g_glSurfaceView);
    glSurface.setRenderer(MainCube_gl.getRenderer(glSurface, Options.getOptionsInstance().getFilter()));

    MovementTranslator mt = new ColorOGLMovementTranslator(this);
    CubeTouchListener tl = new CubeTouchListener(mt);
    glSurface.setOnTouchListener(tl);
    glSurface.setOnKeyListener(new CubeKeyListener(this));
    glSurface.setFocusable(true);
    glSurface.setFocusableInTouchMode(true);
    // facade.addListener(new ModelObserver());
    facade.setHelpFunctionUsed();
  }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    boolean success = false;

    if (gameShown || helpShown) {
      if (keyCode == KeyEvent.KEYCODE_BACK) {
        showPauseMenu();
        success = true;

      } else if (keyCode == KeyEvent.KEYCODE_MENU) {
        showPauseMenu();
        success = true;
      }

    } else if (pauseShown) {
      if (keyCode == KeyEvent.KEYCODE_BACK) {
        changeToRunActivity();
        success = true;

      } else if (keyCode == KeyEvent.KEYCODE_MENU) {
        hidePauseMenu();
        success = true;
      }

    }
    return success;
  }

  /*
   * Initialisiert die Buttons und die Scrollbars f&#252;r das Spiel und setzt die passenden Listener.
   */
  private void setListener() {
    ImageButton undo = (ImageButton) findViewById(R.id.g_undo);
    undo.setOnClickListener(new UndoClickListener(this));

    ImageButton redo = (ImageButton) findViewById(R.id.g_redo);
    redo.setOnClickListener(new RedoClickListener(this));
    
    // Rotation
    //X
    GestureOverlayView rotx = (GestureOverlayView) findViewById(R.id.rotx);
    rotx.setOnClickListener(new CubeRotListener(this));
    GestureOverlayView rotxp = (GestureOverlayView) findViewById(R.id.rotxp);
    rotxp.setOnClickListener(new CubeRotListener(this));
    //Y
    GestureOverlayView roty = (GestureOverlayView) findViewById(R.id.roty);
    roty.setOnClickListener(new CubeRotListener(this));
    GestureOverlayView rotyp = (GestureOverlayView) findViewById(R.id.rotyp);
    rotyp.setOnClickListener(new CubeRotListener(this));
    // Z
    GestureOverlayView rotz = (GestureOverlayView) findViewById(R.id.rotz);
    rotz.setOnClickListener(new CubeRotListener(this));
    GestureOverlayView rotzp = (GestureOverlayView) findViewById(R.id.rotzp);
    rotzp.setOnClickListener(new CubeRotListener(this));
  }

  /*
   * Initialisiert die Buttons fuer das Pausenmenue und setzt die dazugehoerigen Listener.
   */
  private void setPauseListener() {
    Button help = (Button) findViewById(R.id.p_help);

    if (tournament) {
      help.setEnabled(false);
      help.setVisibility(View.INVISIBLE);

    } else {
      help.setEnabled(true);
      help.setOnClickListener(new PHelpClickListener(this));
    }

    Button options = (Button) findViewById(R.id.p_options);
    options.setOnClickListener(new OptionsClickListener(this));

    Button cube = (Button) findViewById(R.id.p_newcube);
    cube.setOnClickListener(new NewCubeClickListener(this));

    Button main = (Button) findViewById(R.id.p_mainmenu);
    main.setOnClickListener(new MainMenuClickListener(this));

    Button back = (Button) findViewById(R.id.p_resume);
    back.setOnClickListener(new BackClickListener(this));
  }

  /**
   * Nimmt einen Key und versucht anhand dessen den Wuerfel zu verdrehen. Ist der Key nicht valid, wird der Benutzer
   * aufgefordert einen neuen einzugeben.
   * 
   * @param trykey
   *          der Key, mit dem versucht wird, der Wuerfel zu verdrehen.,
   * @return true wenn alles geklappt hat.
   */
  public boolean shuffle(String trykey) {
    long key = 0;
    Randomizer random = new SimpleRandomizer();
    boolean valid = false;

    try {
      key = Long.parseLong(trykey);
      valid = random.testKey(key);

    } catch (IllegalArgumentException e) {
      valid = false;
    }

    if (valid) {
      List<Turn> apply = random.generateTurns(key, Constants.NUMBER_OF_MOVES);

      for (Iterator<Turn> i = apply.iterator(); i.hasNext();) {
        facade.applyTurn(i.next().getValue());
      }

      facade.setKey(key);
      startTimer();
    }

    return valid;
  }

  // Timer starten
  private void startTimer() {
    if (timerStopped) {
      timerStopped = false;
      cronmtr = (Chronometer) findViewById(R.id.g_timer);

      if (cronmtr != null) {
        long additionalMillis = facade.getElapsedTime();
        cronmtr.setBase(SystemClock.elapsedRealtime() - additionalMillis);
        cronmtr.start();

      } else {
        System.out.println(TIMER_START_ERROR);
      }
    }
  }

  // Timer beenden
  private void stopTimer() {
    if (!timerStopped) {
      timerStopped = true;

      if (cronmtr != null) {
        long elapsedMillis = SystemClock.elapsedRealtime() - cronmtr.getBase();
        cronmtr.stop();
        this.elapsedTime = elapsedMillis;
        facade.setElapsedTime(elapsedMillis);
      } else {
        System.out.println(TIMER_STOP_ERROR);
      }
    }
  }
}
