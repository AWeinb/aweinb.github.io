package com.pc_controller.listener.run;

import com.pc_controller.PCAct_Run;

import android.view.View;

/**
 * Ein OnClickListener, der das Spiel im Tournament Mode aufruft.
 * */
public class TournamentClickListener implements View.OnClickListener {

  /* Verweis auf die aufrufende Activity. */
  private PCAct_Run lnkPcAct_Run;

  /**
   * Ein OnClickListener, der das Spiel im Tournament Mode aufrufen kann.
   * 
   * @param lnkPcAct
   *          die aufrufende Activity
   */
  public TournamentClickListener(PCAct_Run lnkPcAct_Run) {
    this.lnkPcAct_Run = lnkPcAct_Run;
  }

  /**
   * Ruft das Spiel im Tournament Mode auf.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Run.tournament();
  }
}
