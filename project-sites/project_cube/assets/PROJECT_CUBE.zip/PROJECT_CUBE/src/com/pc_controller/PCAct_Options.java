package com.pc_controller;

import java.util.ArrayList;
import java.util.Arrays;

import yuku.ambilwarna.AmbilWarnaDialog;
import yuku.ambilwarna.AmbilWarnaDialog.OnAmbilWarnaListener;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.pc_controller.listener.options.AnimSpeedListener;
import com.pc_controller.listener.options.FilterItemListener;
import com.pc_controller.listener.options.FontItemListener;
import com.pc_controller.listener.options.LanguageItemListener;
import com.pc_controller.listener.options.ResetScoresClickListener;
import com.pc_controller.listener.options.ThemeItemListener;
import com.pc_model.ModelFacade;
import com.pc_model.Options;
import com.pc_util.Constants;
import com.pc_util.FontChangeHelper;
import com.pc_util.LanguageChangeHelper;
import com.pc_view.ContentViewHandler;
import com.pc_view.openGL.MainCube_gl;

/**
 * Stellt das Optionenmen&#252; dar. Die Activity legt das Layout des Men&#252;s fest und verwaltet Benutzereingaben und
 * aenderungen der Optionen. Zu den Optionen gehoeren der Sound, die Animationsgeschwindigkeit, die Farben, die Sprache
 * und das Reseten der Highscoreliste.
 */

public class PCAct_Options extends Activity {

  private boolean calledfromRun = false;
  private boolean tournament = false;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    FileHandler.setAct(this);
    this.calledfromRun = getIntent().getBooleanExtra(Constants.INTENT_FROMRUN, false);

    if (!calledfromRun) {
      tournament = getIntent().getBooleanExtra(Constants.INTENT_TOURNAMENT, false);
    }

    setContentView(ContentViewHandler.getOptionsLayout(), null);
    super.onCreate(savedInstanceState);
  }

  @Override
  public void onResume() {
    FileHandler.setAct(this);
    super.onResume();
  }

  @Override
  public void onPause() {
    super.onPause();
  }

  @Override
  public void onStop() {
    ModelFacade.storeOptions(Options.getOptionsInstance());
    super.onStop();
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
  }

  @Override
  public void onLowMemory() {
    ModelFacade.storeOptions(Options.getOptionsInstance());
    Toast.makeText(this, R.string.o_lowmemory, Toast.LENGTH_LONG).show();
    finish();
    super.onLowMemory();
  }

  @Override
  public void finish() {
    super.finish();
  }

  /**
   * &#252;berschrieben um Sprache und Schriftart entsprechend zu veraendern.
   */
  public void setContentView(int layoutResID, String font) {
    LanguageChangeHelper.setLanguage(this, Options.getOptionsInstance().getLanguage());
    super.setContentView(layoutResID);

    if (layoutResID == ContentViewHandler.getOptionsLayout()) {
      FontChangeHelper.changeFonts(this, font, Options.getOptionsInstance(),
          (ViewGroup) findViewById(ContentViewHandler.getOptionsLayoutRootNode()), null);
      setListener();
    }
  }

  /**
   * Methode fasst wichtige Aufrufe fuer Intent Run zusammen.
   */
  public void returnToRun() {
    {
      Intent intent = new Intent(PCAct_Options.this, PCAct_Run.class);
      intent.putExtra(Constants.INTENT_FIRSTSTARTUP, false);
      startActivity(intent);
    }
    onDestroy();
    finish();
  }

  /**
   * Methode fasst wichtige Aufrufe fuer Intent Game zusammen.
   */
  public void returnToGame() {
    {
      Intent intent = new Intent(PCAct_Options.this, PCAct_Game.class);
      intent.putExtra(Constants.INTENT_FROM_OPTIONS, true);
      intent.putExtra(Constants.INTENT_TOURNAMENT, this.tournament);
      startActivity(intent);
    }
    onDestroy();
    finish();
  }

  /**
   * Diese Methode &#252;berschreibt die Hardware Tastenbelegung.
   * 
   * @see android.app.Activity#onKeyDown(int, android.view.KeyEvent)
   */
  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    boolean success = false;

    if (keyCode == KeyEvent.KEYCODE_BACK) {
      if (calledfromRun) {
        returnToRun();

      } else {
        returnToGame();
      }
      success = true;

    } else if (keyCode == KeyEvent.KEYCODE_MENU) {
      if (calledfromRun) {
        returnToRun();

      } else {
        returnToGame();
      }
      success = true;

    }
    return success;
  }

  /*************** hier fangen die von Listenern aufgerufenen Methoden an. ********************************************/

  /**
   * Setzt die Animationsgeschwindigkeit des W&#252;rfels neu.
   * 
   * @param speed
   *          eine ganze Zahl zwischen 0 und 100.
   */
  public void setAnimSpeed(int speed) {
    Options.getOptionsInstance().setAnimationSpeed(speed);
  }

  /** Setzt den Highscore zur&#252;ck und leert die Liste. */
  public void resetHighscore() {
    ModelFacade.resetHighScore();
  }

  /**
   * Setzt die Sprache neu.
   * 
   * @param language
   *          der Name der Sprache aus values/Strings.xml, der f&#252;r die Sprache steht.
   */
  public void setLanguage(String language) {
    LanguageChangeHelper.setNewLanguage(this, Options.getOptionsInstance(), language);

    if (language.equalsIgnoreCase((String) getText(R.string.o_specialLang)))
      Options.getOptionsInstance().setFont(Constants.FONT_NOFONT);

    setContentView(ContentViewHandler.getOptionsLayout(), null);
    setListener();
  }

  /**
   * Setzt das Farbthema in den Optionen.
   * 
   * @param theme
   *          Farbthema String
   */
  public void setTheme(String theme) {
    Options options = Options.getOptionsInstance();
    options.setTheme(theme);

    final Button white = (Button) findViewById(R.id.t_white);
    final Button yellow = (Button) findViewById(R.id.t_yellow);
    final Button blue = (Button) findViewById(R.id.t_blue);
    final Button green = (Button) findViewById(R.id.t_green);
    final Button red = (Button) findViewById(R.id.t_red);
    final Button orange = (Button) findViewById(R.id.t_orange);

    if (theme.equals(Constants.NOTHEME)) {
      setStandartColors(green, red, white, orange, yellow, blue);

    } else if (theme.equals(Constants.THEME1)) {
      white.setBackgroundColor(Constants.THEME1_TOP);
      options.setColour(Constants.THEME1_TOP, Constants.UP);

      yellow.setBackgroundColor(Constants.THEME1_BTM);
      options.setColour(Constants.THEME1_BTM, Constants.DOWN);

      blue.setBackgroundColor(Constants.THEME1_FRO);
      options.setColour(Constants.THEME1_FRO, Constants.FRONT);

      green.setBackgroundColor(Constants.THEME1_BAC);
      options.setColour(Constants.THEME1_BAC, Constants.BACK);

      orange.setBackgroundColor(Constants.THEME1_RIG);
      options.setColour(Constants.THEME1_RIG, Constants.RIGHT);

      red.setBackgroundColor(Constants.THEME1_LEF);
      options.setColour(Constants.THEME1_LEF, Constants.LEFT);

    } else if (theme.equals(Constants.THEME2)) {
      white.setBackgroundColor(Constants.THEME2_TOP);
      options.setColour(Constants.THEME2_TOP, Constants.UP);

      yellow.setBackgroundColor(Constants.THEME2_BTM);
      options.setColour(Constants.THEME2_BTM, Constants.DOWN);

      blue.setBackgroundColor(Constants.THEME2_FRO);
      options.setColour(Constants.THEME2_FRO, Constants.FRONT);

      green.setBackgroundColor(Constants.THEME2_BAC);
      options.setColour(Constants.THEME2_BAC, Constants.BACK);

      orange.setBackgroundColor(Constants.THEME2_RIG);
      options.setColour(Constants.THEME2_RIG, Constants.RIGHT);

      red.setBackgroundColor(Constants.THEME2_LEF);
      options.setColour(Constants.THEME2_LEF, Constants.LEFT);
    }
  }

  /**
   * Setzt den Filter in den Optionen.
   * 
   * @param filter
   *          Filter String
   */
  public void setFilter(String filter) {
    Options.getOptionsInstance().setFilter(filter);
    MainCube_gl.destroyRenderer();
  }

  /**
   * Setzt den Font komplett neu. Benoetigt den String Namen des Fonts. Wird von Listener aufgerufen.
   * 
   * @param font
   *          String Font
   */
  public void setFont(String font) {
    setContentView(ContentViewHandler.getOptionsLayout(), font);
  }

  /*
   * Erstellt die Widgets und setzt die dazugehoerigen Listener fuer das Optionenfenster.
   */
  protected void setListener() {
    {
      SeekBar animspeed = (SeekBar) findViewById(R.id.o_seekBar_animspeed);
      animspeed.setOnSeekBarChangeListener(new AnimSpeedListener(this));
      animspeed.setMax(Constants.ANIM_SPEED_MAX);
      animspeed.setProgress(Options.getOptionsInstance().getAnimationSpeed());
      /*
       * Bemerkung: Standart-Range der SeekBar liegt zwischen 0 und 100. Muss geaendert werden mit setMax, falls der
       * Animationsgeschwindigkeits-Range geaendert wird.
       */
    }
    {
      Spinner language = (Spinner) findViewById(R.id.o_spinner_language);
      ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.o_language_array,
          android.R.layout.simple_spinner_item);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      language.setAdapter(adapter);
      // aktuelle Sprache setzen
      language.setSelection(adapter.getPosition(Options.getOptionsInstance().getLanguage()));
      language.setOnItemSelectedListener(new LanguageItemListener(this));
    }
    {
      // Farb-Einstellungs-Buttons
      final Button green = (Button) findViewById(R.id.t_green);
      setColor(green);
      green.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(green);
        }
      });
      final Button red = (Button) findViewById(R.id.t_red);
      setColor(red);
      red.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(red);
        }
      });
      final Button white = (Button) findViewById(R.id.t_white);
      setColor(white);
      white.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(white);
        }
      });
      final Button orange = (Button) findViewById(R.id.t_orange);
      setColor(orange);
      orange.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(orange);
        }
      });
      final Button yellow = (Button) findViewById(R.id.t_yellow);
      setColor(yellow);
      yellow.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(yellow);
        }
      });
      final Button blue = (Button) findViewById(R.id.t_blue);
      setColor(blue);
      blue.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          showColorPicker(blue);
        }
      });

      // "aenderungen zuruecksetzen" Btn
      Button reset = (Button) findViewById(R.id.t_reset);
      reset.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          setStandartColors(green, red, white, orange, yellow, blue);
        }
      });
    }

    {
      Spinner theme = (Spinner) findViewById(R.id.o_spinner_theme);
      ArrayList<String> themes = new ArrayList<String>(Arrays.asList(Constants.THEME_ARRAY));
      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, themes);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      theme.setAdapter(adapter);
      theme.setSelection(adapter.getPosition(Options.getOptionsInstance().getTheme()));
      theme.setOnItemSelectedListener(new ThemeItemListener(this));
    }

    {
      Spinner theme = (Spinner) findViewById(R.id.o_spinner_filter);
      ArrayList<String> filters = new ArrayList<String>(Arrays.asList(Constants.FILTER_ARRAY));
      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, filters);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      theme.setAdapter(adapter);
      theme.setSelection(adapter.getPosition(Options.getOptionsInstance().getFilter()));
      theme.setOnItemSelectedListener(new FilterItemListener(this));
    }

    {
      Spinner font = (Spinner) findViewById(R.id.o_spinner_font);
      ArrayList<String> fonts = new ArrayList<String>(Arrays.asList(Constants.FONTS_ARRAY));
      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, fonts);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      font.setAdapter(adapter);
      // aktuelle Sprache setzen
      font.setSelection(adapter.getPosition(Options.getOptionsInstance().getActFont()));
      font.setOnItemSelectedListener(new FontItemListener(this));
    }
    {
      // Reset Scores Btn
      Button resetScores = (Button) findViewById(R.id.o_reset_highscore);
      resetScores.setOnClickListener(new ResetScoresClickListener(this));

      // Back Btn
      Button back = (Button) findViewById(R.id.o_back);
      back.setOnClickListener(new OnClickListener() {

        public void onClick(View v) {
          if (calledfromRun) {
            returnToRun();

          } else {
            returnToGame();
          }
        }
      });
    }
  }

  /*
   * Setzt die Hintergrundfarbe eines Buttons.
   */
  private void setColor(Button b) {
    Options options = Options.getOptionsInstance();

    if (options != null) {
      switch (b.getId()) {
      case R.id.t_white:
        b.setBackgroundColor(options.getColour(Constants.UP));
        break;
      case R.id.t_yellow:
        b.setBackgroundColor(options.getColour(Constants.DOWN));
        break;
      case R.id.t_blue:
        b.setBackgroundColor(options.getColour(Constants.FRONT));
        break;
      case R.id.t_green:
        b.setBackgroundColor(options.getColour(Constants.BACK));
        break;
      case R.id.t_orange:
        b.setBackgroundColor(options.getColour(Constants.RIGHT));
        break;
      case R.id.t_red:
        b.setBackgroundColor(options.getColour(Constants.LEFT));
        break;
      default:
        System.out.println("Falsche Button Id: " + b.getId());
      }
    }
  }

  /*
   * Setzt die Standartfarben des Zauberwuerfels auf die dazugehoerige Flaeche und speichert dies auch in den Optionen.
   * Die Standartfarben sind Gruen, Rot, Weiss, Orange, Gelb, Blau. Verwendet wird die Android interne ARGB Notation.
   * 
   * @param green der Button fuer die Farbe gruen
   * 
   * @param red der Button fuer die Farbe rot
   * 
   * @param white der Button fuer die Farbe weiss
   * 
   * @param orange der Button fuer die Farbe orange
   * 
   * @param yellow der Button fuer die Farbe gelb
   * 
   * @param blue der Button fuer die Farbe blau
   */
  private void setStandartColors(Button green, Button red, Button white, Button orange, Button yellow, Button blue) {
    Options options = Options.getOptionsInstance();

    if (options != null) {
      white.setBackgroundColor(Color.WHITE);
      options.setColour(Color.WHITE, Constants.UP);

      yellow.setBackgroundColor(Color.YELLOW);
      options.setColour(Color.YELLOW, Constants.DOWN);

      blue.setBackgroundColor(Color.BLUE);
      options.setColour(Color.BLUE, Constants.FRONT);

      green.setBackgroundColor(Color.GREEN);
      options.setColour(Color.GREEN, Constants.BACK);

      int orangeColor = Color.rgb(255, 140, 0);
      orange.setBackgroundColor(orangeColor);
      options.setColour(orangeColor, Constants.RIGHT);

      red.setBackgroundColor(Color.RED);
      options.setColour(Color.RED, Constants.LEFT);

    }
  }

  /*
   * Zeigt eine Farbpalette an. Wird eine Farbe angeklickt, wird sie auf den Button und in die Optionen uebernommen. Der
   * verwendete ColorPicker stammt aus den Android Samples und ist von Android Lizenziert.
   * 
   * @param b der Button, dessen Farbe gesetzt werden soll.
   */
  private void showColorPicker(final Button b) {
    // Dieser Dialog steht unter der Apache 2.0 Lizenz
    
    int c = 0xffffffff;
    Options options = Options.getOptionsInstance();
    options.setTheme(Constants.NOTHEME);
    Spinner theme = (Spinner) findViewById(R.id.o_spinner_theme);
    ArrayList<String> themes = new ArrayList<String>(Arrays.asList(Constants.THEME_ARRAY));
    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, themes);
    theme.setSelection(adapter.getPosition(Options.getOptionsInstance().getTheme()));
    
    switch (b.getId()) {
    case R.id.t_white:
      c = options.getColour(Constants.UP);
      break;
    case R.id.t_yellow:
      c = options.getColour(Constants.DOWN);
      break;
    case R.id.t_blue:
      c = options.getColour(Constants.FRONT);
      break;
    case R.id.t_green:
      c = options.getColour(Constants.BACK);
      break;
    case R.id.t_orange:
      c = options.getColour(Constants.RIGHT);
      break;
    case R.id.t_red:
      c = options.getColour(Constants.LEFT);
      break;
    }
    
    AmbilWarnaDialog colorPicker = new AmbilWarnaDialog(this, c, new OnAmbilWarnaListener() {

      public void onCancel(AmbilWarnaDialog dialog) {
      }

      public void onOk(AmbilWarnaDialog dialog, int color) {
        Options options = Options.getOptionsInstance();

        if (options != null) {
          switch (b.getId()) {
          case R.id.t_white:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.UP);
            break;
          case R.id.t_yellow:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.DOWN);
            break;
          case R.id.t_blue:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.FRONT);
            break;
          case R.id.t_green:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.BACK);
            break;
          case R.id.t_orange:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.RIGHT);
            break;
          case R.id.t_red:
            b.setBackgroundColor(color);
            options.setColour(color, Constants.LEFT);
            break;
          default:
            System.out.println("Falsche Button Id: " + b.getId());
          }
        }
      }
    });
    colorPicker.show();
  }
}
