package com.pc_controller;

/**
 * &#252;bersetzt die Bewegung auf dem Android Touchpad in eine Bewegung auf dem Zauberw&#252;rfel-Model.
 * */
public abstract class MovementTranslator {

  @SuppressWarnings("unused")
  private PCAct_Game lnkPcAct_Game;

  /**
   * Erstellt einen Bewegungs&#252;bersetzer, der x und y Koordinaten des Android Touchscreens in logische
   * Zauberw&#252;rfel-Operationen &#252;bersetzen kann. Ben&#246;tigt einen Link auf die ausf&#252;hrende Steuerungseinheit/ Activity.
   * 
   * @param lnkPcAct_Game
   *          ein Link auf die ausf&#252;hrende Activity.
   */
  public MovementTranslator(PCAct_Game lnkPcAct_Game) {
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Wird aufgerufen, wenn der Benutzer eine neue Bewegung auf dem Touchscreen ausf&#252;hrt. F&#252;gt die Koordinaten des
   * Startpunkts der Bewegung in die Bewegungsliste ein.
   * 
   * @param x
   *          Anfangswert auf der X-Achse
   * @param y
   *          Anfangswert auf der Y-Achse
   * */
  public void startNewMove(int x, int y) {
  }

  /**
   * F&#252;gt einen 2 dimensionalen Punkt zur bereits ausgef&#252;hrten Bewegung hinzu.
   * 
   * @param x
   *          Wert auf der X-Achse
   * @param y
   *          Wert auf der Y-Achse
   * 
   * */
  public void addToMovement(int x, int y) {
 }

  /**
   * Wird aufgerufen, wenn der Benutzer seine Bewegung beendet (Den Finger vom Display nimmt). Beendet die Bewegung und
   * berechnet anhand der Bewegungsliste, ob ein g&#252;ltiger Zug ausgef&#252;hrt wurde. Falls ja wird der Zug ausgef&#252;hrt, falls
   * nein, wird die Bewegung r&#252;ckg&#228;ngig gemacht.
   * 
   * */
  public void finishMovement() {
 }


}
