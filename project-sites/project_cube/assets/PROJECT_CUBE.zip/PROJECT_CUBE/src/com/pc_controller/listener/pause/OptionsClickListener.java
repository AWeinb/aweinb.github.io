package com.pc_controller.listener.pause;

import com.pc_controller.PCAct_Game;

import android.view.View;

/**
 * Beobachtet einen Button im Pausenmenue, der das Optionenmenue aufrufen kann.
 * */
public class OptionsClickListener implements View.OnClickListener {
  /**
   * Verweis auf das Objekt von pcAct_Game, das den Listener registriert hat.
   */
  private PCAct_Game lnkPcAct_Game;

  /**
   * Konstruktor. Benoetigt eine aufrufende Activity.
   * 
   * @param lnkPcAct_Game
   */
  public OptionsClickListener(PCAct_Game lnkPcAct_Game) {
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Ruft das Optionenmenue auf.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Game.changeToOptionsActivity();
  }
}
