package com.pc_controller.listener.options;

import android.view.View;
import com.pc_controller.PCAct_Options;

/**
 * Beobachtet einen Button im Optionenmenue, der die Highscores zuruecksetzt.
 * */
public class ResetScoresClickListener implements View.OnClickListener {
  /*Verweis auf das Objekt von pcActRun, das den Listener registriert hat.*/
  private PCAct_Options lnkPcAct_Options;

  /**
   * Konstruktor. Muss einen Verweis auf die aufrufende Activity enthalten.
   * @param lnkPcAct_Options
   */
  public ResetScoresClickListener(PCAct_Options lnkPcAct_Options) {
    this.lnkPcAct_Options = lnkPcAct_Options;
  }

  /**
   * Bewirkt das Reseten der Highscores.
   * 
   * @param view
   *          android.View um das Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Options.resetHighscore();
  }
}
