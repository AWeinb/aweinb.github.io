package com.pc_controller;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

import com.pc_controller.dialogs.CustomDialog;
import com.pc_model.Highscores;
import com.pc_util.Constants;
import com.pc_util.Randomizer;
import com.pc_util.SimpleRandomizer;

/**
 * Diese Klasse behandelt alle Dialoge, die Project_Cube braucht. Die Klasse
 * lagert vor allem Code aus der pcAct_game aus. Da Dialogs zum builden meist
 * ein Context brauchen, wird immer eine aufrufende Activity ben&#246;tigt.
 */
public class DialogManager {

  /*
   * Erstellt ein Objekt, das Dialoge anzeigen kann. Muss nicht public sein, da
   * alle Methoden statisch sein sollten.
   */
  private DialogManager() {
  }

  /**
   * Zeigt die Highscoreliste als Dialog an. Braucht zum Erstellen eine
   * Activity.
   * 
   * @param act
   *          die aufrufende Activity.
   */
  public static CustomDialog showHighscore(Activity act, String[][] scores) {
    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.m_highscore_title);
    builder.withTable(scores);
    builder.setBtn1(R.string.dialog_back, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }

  /**
   * Zeigt einen Dialog an, der einen Key ausgeben bzw einlesen kann.
   * Ben&#246;tigt die aufrufende Activity vom Typ pc_ActGame und einen Boolean,
   * der angibt, ob der zuletzt angezeigte Key valid war. Der Default ist true.
   * 
   * @param act
   *          die aufrufende pcAct_Game
   * @param keyvalid
   *          ob der zuletzt angezeigte Key valid war. Default true.
   */
  public static CustomDialog showKeyDialog(final PCAct_Game act) {
    final Randomizer random = new SimpleRandomizer();
    final String key = "" + random.generateKey();

    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setCancelable(false);
    builder.setTitle(R.string.g_keytitle);
    builder.setMainText(R.string.g_keytext);
    builder.enableNumberInput(true, key.trim());
    
    builder.setBtn1(R.string.g_keyquit, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
        act.quitWithoutSave();
      }
    });

    builder.setBtn2(R.string.g_keygen, new OnClickListener() {

      public void onClick(View v) {
        String key = "" + random.generateKey();
        ((EditText) builder.getDialog().findViewById(R.id.dialog_inputnumber)).setText(key.trim());
      }
    });

    builder.setBtn3(R.string.g_keyok, new OnClickListener() {

      public void onClick(View v) {
        boolean valid = act.shuffle(((EditText) builder.getDialog().findViewById(R.id.dialog_inputnumber)).getText().toString().trim());

        if (valid) {
          builder.getDialog().cancel();

        } else {
          ((TextView) builder.getDialog().findViewById(R.id.dialog_title)).setText(R.string.g_keyfailure);
          ((TextView) builder.getDialog().findViewById(R.id.dialog_maintext)).setText(R.string.g_keytextFail);
        }
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          act.quitWithoutSave();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }

  /**
   * Zeigt einen Dialog an, falls f&#252;r die aktuelle
   * W&#252;rfelgr&#246;&#223;e kein L&#246;sungsalgorithmus zur Verf&#252;gung
   * steht. Braucht eine aufrufende Activity
   * 
   * @param act
   *          die aufrufende Activity
   */
  public static CustomDialog showNoSolverDialog(Activity act) {
    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.g_nosolver_title);
    builder.setMainText(R.string.g_nosolver_text);

    builder.setBtn1(R.string.dialog_ok, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }
  
  public static CustomDialog showSolverEndedDialog(final PCAct_Game act) {
    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.g_solverEnd_title);
    builder.setMainText(R.string.g_solverEnd_text);

    builder.setBtn1(R.string.dialog_ok, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
        act.stopSolver();
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          act.stopSolver();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }

  /**
   * Zeigt einen Dialog an, der den Namen des Spielers einlesen und in die
   * Bestenliste speichern kann. Ben&#246;tigt eine aufrufende Activity.
   * 
   * @param act
   *          die aufrufende Activity
   */
  public static CustomDialog showWinnerDialog(final PCAct_Game act) {
    final Highscores h = Highscores.getInstance();

    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.g_nameinput_title);
    builder.setMainText(R.string.g_nameinput_text);
    builder.enableNameInput(true);
    builder.setCancelable(false);

    builder.setBtn1(R.string.dialog_ok, new OnClickListener() {

      public void onClick(View v) {
        EditText inputbox = (EditText) builder.getDialog().findViewById(R.id.dialog_inputname);
        String name = inputbox.getText().toString().trim();

        if (name.contains(Constants.SEPARATOR) || name.contains(Constants.TURNSEPERATOR) || name.length() > Constants.NAMELENGTH) {
          String t = act.getResources().getString(R.string.g_nameinput_text_fail1);
          t += " " + Constants.NAMELENGTH + " ";
          t += act.getResources().getString(R.string.g_nameinput_text_fail2);

          TextView tv = (TextView) builder.getDialog().findViewById(R.id.dialog_maintext);
          tv.setText(t + " " + Constants.SEPARATOR + " " + Constants.TURNSEPERATOR);
          inputbox.setTextColor(Color.RED);

        } else {
          if (name.equals("")) {
            name = Constants.STANDARDNAME;
          }

          h.sign(name);
          builder.getDialog().cancel();
          act.quitWithSaveReset();
        }
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          EditText inputbox = (EditText) builder.getDialog().findViewById(R.id.dialog_inputname);
          String name = inputbox.getText().toString().trim();

          if (name.contains(Constants.SEPARATOR) || name.contains(Constants.TURNSEPERATOR) || name.length() > Constants.NAMELENGTH) {
            String t = act.getResources().getString(R.string.g_nameinput_text_fail1);
            t += " " + Constants.NAMELENGTH + " ";
            t += act.getResources().getString(R.string.g_nameinput_text_fail2);

            TextView tv = (TextView) builder.getDialog().findViewById(R.id.dialog_maintext);
            tv.setText(t + " " + Constants.SEPARATOR + " " + Constants.TURNSEPERATOR);
            inputbox.setTextColor(Color.RED);

          } else {
            if (name.equals("")) {
              name = Constants.STANDARDNAME;
            }

            h.sign(name);
            builder.getDialog().cancel();
            act.quitWithSaveReset();

            ret = true;
          }
        }

        return ret;
      }
    });

    return builder.create();
  }

  /**
   * Zeigt einen Dialog, der dem Benutzer mitteilt, dass kein alter Spielstand
   * zur Verf&#252;gung steht. Ben&#246;tigt eine aufrufende Activity vom Typ
   * pcAct_Game.
   * 
   * @param act
   *          die aufrufende Activity
   */
  public static CustomDialog showNoSaveGameDialog(final Activity act) {
    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.m_nosave_title);
    builder.setMainText(R.string.m_nosave_text);

    builder.setBtn1(R.string.dialog_ok, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }

  /**
   * Zeigt im TournamentMode dem Gewinner die Zeit und die Z&#252;ge an.
   * 
   * @param count
   *          die Z&#252;ge
   * @param time
   *          die Zeit
   * @param act
   *          die aufrufende Activity
   */
  public static CustomDialog showScore(int moves, long time, final PCAct_Game act) {
    final CustomDialog.Builder builder = new CustomDialog.Builder(act);
    builder.setTitle(R.string.g_win_title);

    long milliseconds = time;
    milliseconds /= 1000;
    byte sec = (byte) (milliseconds % 60);
    milliseconds /= 60;
    byte min = (byte) (milliseconds % 60);
    milliseconds /= 60;
    byte h = (byte) (milliseconds % 24);
    milliseconds /= 24;
    int d = (int) milliseconds;

    String timeString = (String) (d != 0 ? d + " d:" : "") + h + ":" + min + ":" + sec + " ";

    String t1 = act.getResources().getString(R.string.g_win_text);
    String t2 = act.getResources().getString(R.string.g_win_text_moves);
    String t3 = act.getResources().getString(R.string.g_win_text_time);
    builder.setMainText(t1 + "\n" + t2 + " " + moves + "\n" + t3 + " " + timeString);

    builder.setBtn1(R.string.dialog_ok, new OnClickListener() {

      public void onClick(View v) {
        builder.getDialog().cancel();
        act.quitWithSaveReset();
      }
    });

    builder.getDialog().setOnKeyListener(new OnKeyListener() {

      public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        boolean ret = false;
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
          builder.getDialog().cancel();
          act.quitWithSaveReset();
          ret = true;
        }

        return ret;
      }
    });

    return builder.create();
  }

}
