package com.pc_controller.listener.help;

import com.pc_controller.PCAct_Game;

import android.view.View;
import android.view.View.OnClickListener;

/**
 * Diese KLasse implementiert einen OnClickListener. Er hoert den "Pause"-Button im Hilfemodus ab. Im Fall eines Klicks
 * wird das automatische Loesen des Wuerfels unterbrochen, kann aber spaeter fortgesetzt werden.
 */
public class SolveAllClickListener implements OnClickListener {

  /* Verweis auf die aufrufende Activity. */
  private PCAct_Game lnk;

  /**
   * Erstellt einen OnClickListener, der den "Pause"-Button im Hilfemodus abhoert. Im Fall eines Klicks wird das
   * automatische Loesen des Wuerfels unterbrochen.
   * 
   * @param lnk
   *          die aufrufende Activity
   */
  public SolveAllClickListener(PCAct_Game lnk) {
    this.lnk = lnk;
  }

  /**
   * Hoert den "Pause"-Button im Hilfemodus ab. Im Fall eines Klicks wird das automatische Loesen des Wuerfels unterbrochen.
   * 
   * @param v
   *          das geklickte Viewelement.
   */
  public void onClick(View v) {
    lnk.startSolver(true);
    lnk.showSolver();
  }

}
