package com.pc_controller.listener.pause;

import android.view.View;
import com.pc_controller.PCAct_Game;

/**
 * Beobachtet einen Button im Optionenmenue, der das Pausenmenue schliesst.
 * */
public class BackClickListener implements View.OnClickListener {
  /**
   * Verweis auf die aufrufende Activity.
   */
  private PCAct_Game lnkPcAct_Game;

  /**
   * Konstruktor. Muss einen Verweis auf die aufrufende Activity enthalten.
   * @param lnkPcAct_Options
   */
  public BackClickListener(PCAct_Game lnkPcAct_Game) {
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Schliesst das Pausenmenue.
   * 
   * @param view
   *          android.View um das Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    this.lnkPcAct_Game.hidePauseMenu();
  }
}
