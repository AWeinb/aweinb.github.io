package com.pc_controller.listener.run;

import com.pc_controller.PCAct_Run;

import android.view.View;

/**
 * OnClickListener, der ein neues Spiel laden kann.
 * */
public class LoadClickListener implements View.OnClickListener {

  /**
   * Verweis auf das Objekt von pcAct_Run, an dem der Listener registriert ist.
   */
  private PCAct_Run lnkPcAct_Run;

  /**
   * Konstruktor. Benoetigt eine aufrufende Activity.
   * 
   * @param lnkPcAct_Run
   *          die aufrufende Activity.
   */
  public LoadClickListener(PCAct_Run lnkPcAct_Run) {
    this.lnkPcAct_Run = lnkPcAct_Run;
  }

  /**
   * Startet das Spiel mit einem alten Spielstand.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Run.loadGame();
  }
}
