package com.pc_controller.listener.game;

import com.pc_controller.PCAct_Game;
import com.pc_util.Constants;
import com.pc_util.Constants.TurnType;

import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;

/**
 * Diese Klasse implementiert einen OnKeyListener. Er hoert die physikalische
 * Tastatur (nicht die Softwaretastatur!) ab und entscheidet aufgrund der
 * gedrueckten Taste, was zu tun ist. Je nach Taste wird der Zauberwuerfel um den
 * der Taste zugeordneten Zug gedreht.
 */
public class CubeKeyListener implements OnKeyListener {

  /* Verweis auf die aufrufende Activity */
  private PCAct_Game lnk;

  /**
   * Erstellt einen OnKeyListener, der je nach Tasteneingabe einen Zug auf dem
   * Zauberwuerfel ausfuehrt.
   * 
   * @param lnk
   *          die aufrufende Activity
   */
  public CubeKeyListener(PCAct_Game lnk) {
    this.lnk = lnk;
  }

  /**
   * Hoert die Tastatur ab. Fuehrt je nach Taste einen Zug auf dem Wuerfel aus.
   * Gibt true zurueck, wenn die Taste mit einem Zug belegt ist.
   * 
   * @param v
   *          die View, die das KeyEvent ausloest
   * @param keyCode
   *          der Code der Taste
   * @param KeyEvent
   *          das ausgeloeste KeyEvent mit weiteren Informationen
   * @see android.view.View.OnKeyListener;
   */
  public boolean onKey(View v, int keyCode, KeyEvent e) {
    System.out.println("Key Pressed" + e.getAction());

    TurnType t = null;
    boolean validKey = false;

    if (e.getAction() == KeyEvent.ACTION_DOWN) {
      switch (keyCode) {
        case KeyEvent.KEYCODE_F:
          t = Constants.TurnType.F;
          break;
        case KeyEvent.KEYCODE_G:
          t = Constants.TurnType.FPRIME;
          break;
        case KeyEvent.KEYCODE_L:
          t = Constants.TurnType.L;
          break;
        case KeyEvent.KEYCODE_K:
          t = Constants.TurnType.LPRIME;
          break;
        case KeyEvent.KEYCODE_R:
          t = Constants.TurnType.R;
          break;
        case KeyEvent.KEYCODE_T:
          t = Constants.TurnType.RPRIME;
          break;
        case KeyEvent.KEYCODE_B:
          t = Constants.TurnType.B;
          break;
        case KeyEvent.KEYCODE_V:
          t = Constants.TurnType.BPRIME;
          break;
        case KeyEvent.KEYCODE_U:
          t = Constants.TurnType.U;
          break;
        case KeyEvent.KEYCODE_I:
          t = Constants.TurnType.UPRIME;
          break;
        case KeyEvent.KEYCODE_D:
          t = Constants.TurnType.D;
          break;
        case KeyEvent.KEYCODE_C:
          t = Constants.TurnType.DPRIME;
          break;
        case KeyEvent.KEYCODE_M:
          t = Constants.TurnType.M;
          break;
        case KeyEvent.KEYCODE_N:
          t = Constants.TurnType.MPRIME;
          break;
        case KeyEvent.KEYCODE_E:
          t = Constants.TurnType.E;
          break;
        case KeyEvent.KEYCODE_W:
          t = Constants.TurnType.EPRIME;
          break;
        case KeyEvent.KEYCODE_S:
          t = Constants.TurnType.S;
          break;
        case KeyEvent.KEYCODE_A:
          t = Constants.TurnType.SPRIME;
          break;
        case KeyEvent.KEYCODE_1:
          t = Constants.TurnType.ROTY;
          break;
        case KeyEvent.KEYCODE_2:
          t = Constants.TurnType.ROTYPRIME;
          break;
        case KeyEvent.KEYCODE_3:
          t = Constants.TurnType.ROTX;
          break;
        case KeyEvent.KEYCODE_4:
          t = Constants.TurnType.ROTXPRIME;
          break;
        case KeyEvent.KEYCODE_5:
          t = Constants.TurnType.ROTZ;
          break;
        case KeyEvent.KEYCODE_6:
          t = Constants.TurnType.ROTZPRIME;
          break;
        default:
          System.out.println("keycode: " + keyCode);
          return false;
      }

      if (t != null) {
        this.lnk.manageTurn(t);
        validKey = true;
      }
    }
    return validKey;
  }

}
