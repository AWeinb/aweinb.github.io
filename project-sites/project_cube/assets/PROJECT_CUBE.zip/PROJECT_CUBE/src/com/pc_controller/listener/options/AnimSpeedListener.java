package com.pc_controller.listener.options;

import com.pc_controller.PCAct_Options;

import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.SeekBar;

/**
 * Diese Klasse implementiert einen OnSeekBarChangeListener, der die Anzeige der Animationsgeschwindigkeit im
 * Optionenmenue abhoert. Er wird aktiv, sobald der Regler der abgehoerten Seekbar verschoben wird.
 */
public class AnimSpeedListener implements OnSeekBarChangeListener {

  /* Verweis auf die aufrufende Activity. */
  private PCAct_Options lnk;

  /**
   * Erstellt einen Listener, der die Animationsgeschwindigkeits-Seekbar abhoert.
   * 
   * @param lnk
   *          Verweis auf die aufrufende Activity.
   */
  public AnimSpeedListener(PCAct_Options lnk) {
    this.lnk = lnk;
  }

  /**
   * Bewirkt das Setzen der neu eingestellten Animationsgeschwindigkeit in den Optionen.
   * 
   * @param seekBar
   *          die Seekbar, deren Wert geaendert wurde
   * @param progress
   *          der neue Wert
   * @param fromUser
   *          ob der Wert vom User geaendert wurde
   */
  public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
    this.lnk.setAnimSpeed(progress);
  }

  /**{@inheritDoc}*/
  public void onStartTrackingTouch(SeekBar seekBar) {
    //do nothing
  }

  /**{@inheritDoc}*/
  public void onStopTrackingTouch(SeekBar seekBar) {
    //do nothing
  }
}
