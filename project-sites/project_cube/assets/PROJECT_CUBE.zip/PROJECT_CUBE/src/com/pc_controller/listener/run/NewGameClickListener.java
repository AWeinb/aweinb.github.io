package com.pc_controller.listener.run;

import android.view.View;

/**
 * OnClicklistener, der ein neues Spiel aufrufen kann.
 * */
public class NewGameClickListener implements View.OnClickListener {

  /**
   * Verweis auf die Activity, die diesen Listener registriert hat.
   */
  private com.pc_controller.PCAct_Run lnkPcAct_Run;

  /**
   * Konstruktor. Benoetigt eine aufrufende Activity.
   * @param lnkPc
   * */
  public NewGameClickListener(com.pc_controller.PCAct_Run lnkPcAct_Run) {
    this.lnkPcAct_Run = lnkPcAct_Run;
  }

  /**
   * Erzeugt eine Game Activity und startet ein neues Spiel.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Run.intentGame();
  }
}
