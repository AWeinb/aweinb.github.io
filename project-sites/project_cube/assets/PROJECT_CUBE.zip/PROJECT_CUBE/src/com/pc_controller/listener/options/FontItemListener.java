package com.pc_controller.listener.options;

import com.pc_controller.PCAct_Options;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

/**
 * Registriert Schriftart aenderungsbefehle des Benutzers.
 * 
 * 
 * @author AxP
 *
 */
public class FontItemListener implements OnItemSelectedListener {

  /* Verweis auf die aufrufende Activity. */
  private PCAct_Options lnkPcAct_Options;
  private boolean first;

  /** Beobachtet einen Spinner mit mehreren Auswahlelementen. */
  public FontItemListener(PCAct_Options lnkPcAct_Options) {
    this.lnkPcAct_Options = lnkPcAct_Options;
    this.first = true;
  }

  /**
   * Setzt die ausgewaehlte Schriftart in den Optionen.
   * 
   * @see android.widget.AdapterView.OnItemSelectedListener
   * 
   * @param parent
   *          The AdapterView where the selection happened
   * @param view
   *          The view within the AdapterView that was clicked
   * @param position
   *          The position of the view in the adapter
   * @param id
   *          The row id of the item that is selected
   */
  public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    if (!first) {
      lnkPcAct_Options.setFont(parent.getItemAtPosition(position).toString());
      
    } else {
      first = false;
    }
  }

  /**
   * @see android.widget.AdapterView.OnItemSelectedListener
   */
  public void onNothingSelected(AdapterView<?> parent) {
  }
}
