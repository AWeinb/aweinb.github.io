package com.pc_controller.listener.pause;

import com.pc_controller.PCAct_Game;

import android.view.View;

/**
 * Beobachtet einen Button im Optionenmenue, der das Hauptmenue oeffnet.
 * */
public class MainMenuClickListener implements View.OnClickListener {
  /**
   * Verweis auf das Objekt von pcAct_Game, das diesen Listener registriert hat.
   * */
  private PCAct_Game lnkPcAct_Game;

  /**
   * Konstruktor. Benoetigt eine aufrufende Activity.
   * 
   * @param lnkPcAct_Game
   *          die aufrufende Activity
   */
  public MainMenuClickListener(PCAct_Game lnkPcAct_Game) {
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Ruft das Hauptmenue auf.
   * 
   * @param view
   *          android.View um den Event zuordnen zu koennen.
   * */
  public void onClick(View view) {
    lnkPcAct_Game.changeToRunActivity();
    lnkPcAct_Game.finish();
  }
}
