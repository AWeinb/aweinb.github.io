package com.pc_controller.listener.game;

import com.pc_controller.PCAct_Game;
import com.pc_controller.R;
import com.pc_util.Constants;

import android.view.View;
import android.view.View.OnClickListener;

public class CubeRotListener implements OnClickListener {

  private PCAct_Game lnk;

  public CubeRotListener(PCAct_Game lnk) {
    this.lnk = lnk;
  }

  public void onClick(View v) {
    switch (v.getId()) {
    case R.id.rotx:
      lnk.manageTurn(Constants.TurnType.ROTX);
      break;
    case R.id.rotxp:
      lnk.manageTurn(Constants.TurnType.ROTXPRIME);
      break;
    case R.id.roty:
      lnk.manageTurn(Constants.TurnType.ROTY);
      break;
    case R.id.rotyp:
      lnk.manageTurn(Constants.TurnType.ROTYPRIME);
      break;
    case R.id.rotz:
      lnk.manageTurn(Constants.TurnType.ROTZ);
      break;
    case R.id.rotzp:
      lnk.manageTurn(Constants.TurnType.ROTZPRIME);
      break;
    default: // do nothing
    }

  }

}
