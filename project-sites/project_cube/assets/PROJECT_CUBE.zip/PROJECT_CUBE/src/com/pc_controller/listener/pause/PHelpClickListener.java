package com.pc_controller.listener.pause;

import android.view.View;
import com.pc_controller.PCAct_Game;

/** Diese Klasse beaobachtet den Hilfe-Button im Pausenmenue. */
public class PHelpClickListener implements View.OnClickListener {

  /**
   * Verweis auf das Objekt von pcActRun, das den Listener registriert hat.
   */
  private PCAct_Game lnkPcAct_Game;

  /** Konstruktor. Muss einen Verweis auf die aufrufende Activity enthalten. */
  public PHelpClickListener(PCAct_Game lnkPcAct_Game) {
    this.lnkPcAct_Game = lnkPcAct_Game;
  }

  /**
   * Ruft die Hilfefunktion auf.
   * 
   * @param v
   *          das View-Objekt, das die Methode aufruft.
   */
  public void onClick(View v) {
    lnkPcAct_Game.showSolver();
  }

}
