package com.pc_controller.listener.game;

import com.pc_controller.MovementTranslator;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/**
 * Diese Klasse enthaelt einen OnTouchListener, der den Touchscreen auf MotionEvents abhoeren kann. Die Koordinaten dieser
 * werden an einen MovementTranslator uebergeben, der sie in einen Zug umsetzt, sofern es sich bei der Eingabe um eine
 * gueltige Bewegung handelte.
 */
public class CubeTouchListener implements OnTouchListener {

  /* Ein MovementTranslator, an den Koordinaten uebergeben werden koennen. */
  private MovementTranslator mt;

  /**
   * Erstellt einen OnTouchListener, der die Bewegungen auf auf dem Touchscreen abhoeren kann und deren Koordinaten auf
   * einen MovementTranslator uebergeben kann.
   * 
   * @param mt
   *          den MovementTranslator, an den Koordinaten uebergeben werden koennen.
   */
  public CubeTouchListener(MovementTranslator mt) {
    this.mt = mt;
  }

  /**
   * Beobachtet den Touchscreen und faengt Motionevents ab. Handelt es sich dabei um eine Bewegung, wird die
   * entsprechende Methode auf dem MotionTranslator ausgefuehrt.
   * 
   * @param v
   *          Die View, auf welcher das Motionevent ausgefuehrt wurde.
   * @param me
   *          Das MotionEvent object, welches alle Informationen ueber das Event enthaelt.
   * @return Wahr, wenn der Listener das Event verarbeiten konnte, falsch sonst.
   * 
   */
  public boolean onTouch(View v, MotionEvent me) {
    boolean done = false;
    int x = (int) me.getX();
    int y = (int) me.getY();
    switch (me.getAction()) {
    case MotionEvent.ACTION_MOVE:
      mt.addToMovement(x, y);
      done = true;
      break;
    case MotionEvent.ACTION_DOWN:

      mt.startNewMove(x, y);
      done = true;
      break;
    case MotionEvent.ACTION_UP:
      mt.finishMovement();
      done = true;
      break;
    default:
      System.out.println("CubeTouchListener: Was falsches erhalten. Action: " + me.getAction());
    }

    return done;
  }
}
